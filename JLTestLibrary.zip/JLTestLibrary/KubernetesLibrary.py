import copy
import datetime
import json
import os
import re
import time
import traceback
from datetime import datetime, timedelta, timezone
from tkinter.font import names
from typing import List
from urllib.parse import urlparse

import pytz
from kubernetes import client
from kubernetes.client import Configuration, rest
from kubernetes.client.exceptions import ApiException
from kubernetes.client.models import V1ServicePort
from kubernetes.stream import stream
from robot.api.deco import keyword

from . import log, UtilsLibrary

# kubectl describe secrets -n kube-system admin-user-token-n2w64
clusters = {
    'dev': {
        'host': 'https://172.20.6.6:6443',
        'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IktDc3dsU29OYnh3NGFSQkRUWjBlcm14YW5sbHpCU01EWTFLUDJKZGlTS2sifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLXRqYmxqIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI1ZTFlMTM3Zi1hY2ExLTRkY2YtYTdhMy0yZTgxZTFiOTNmNzUiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZS1zeXN0ZW06YWRtaW4tdXNlciJ9.AbTXwkzsBfjTgrbigU1JpWnWPN2nGbYFXwdXjYSv0tXmZhsixrfzE38Tzp9eekBCXX3BLHQTobOqiPNio4ak7gFTElAGuUe43Ekd0OoyJkSUmoJhCkmvo8VHFrGd86P6CO_1W-i78zwSl54J2kxo20-fbT0X_OsnGjRsXWSa22f0YN_ItJyAQEHx9pqFu3JrRMmMelx_7zHgf_ENYoGyDRb_7Qb0SnHxkIqjK1mrIRXEMqOMawjvRsmo7OBMgpS79bLPTyB1NAlNMsgebz0Xvm391IniVniK2zi0qe4O9XVjWC3cPU9fxD4MEVXKGsk1c_D-d3g8sZkmsS7y3xepmA',
    },
    'fat': {
        'host': 'https://autotest-fat.jlpay.com:6443',
        'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjVxWndDSHA0RnZMR2hvR2VZT3VyUWotM05VRC1PdHNOVFlYZ1Vtc2paWUUifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi11c2VyLXRva2VuLW4ydzY0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQubmFtZSI6ImFkbWluLXVzZXIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiI4MTRkMTg2NS1lZGI2LTQzZmUtODA2Zi03MWIzYTMwMjBkZjAiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6a3ViZS1zeXN0ZW06YWRtaW4tdXNlciJ9.h2M9AWE9cxNxUqGl0nEmK3fJbGUJxAsEVephmgDcrOTYpMsvp0y5FfR6VwaX48blh8ASuB6Kn04V-guqvIeKC8hHd3O-tm_D3eaV3pqSP-t5Rz9U97T00iUsZQ-yFniJBJAZv19AA4BiSfH4yos2ImIc1MVFTvJyZbN5HYQnJV9tyOZeOSvjkY_aaMhiakGZ6zpPftd_7OeXE5HUaWEdzWTDuvsxkn2otEDcUbmxF8yCfe5-6vah68KZSaMzaGvEmqH6ClFqPPRA7n7-3dTXxbbSjFIhIXn8cqnwlMgMvG3EfpyFG2U_fLtlKPj5s7SCPQRWxzFkqx1sO9qSVoNDkg',
    },
    'uat': {
        'host': 'https://172.20.4.2:6443',
        # viewer-user
        # 'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IlhpaDZIQ3VTczJIYWdUVjNpWEgzQWRMSV9DYl9NTTJVY2ZBSDhiMnhyNVkifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJ2aWV3ZXItdXNlci10b2tlbi00d3ZsNSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJ2aWV3ZXItdXNlciIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6Ijk3NmMzM2M0LWZhZWEtNDJiMi04MWIxLTUzNmEwMDY0Y2JkOCIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDprdWJlLXN5c3RlbTp2aWV3ZXItdXNlciJ9.H24icvdzisoZj-LKvun-uZgrXgAFQxfnNMb9-QlAtbBbJuF8Y-aEZ7KRp5sEjjM8IcKIwzz95jGxcD4TOg9fJuSVLjZwdqiv1_mB9rx8uWm4s7ehTAP4hSbJBfF0vQ5o02s0kn1Uw3RW5KjWd3QScL6kvAi5mDkRzRKcBb2Qa958HfKwE69ErEA1nx0QSl5OBPQKpf1mLbyoO0_EnLtQ5qZ6p8Un8_pVnXyqlgMc7pmEOBp1_SEAs7qqFVDoieSnQbNkYiXk5QMSZ_pSqhof5WnzYqGnfflLoBveCo01xygIV2q6Sqwc4T1cNn1Gg0dmmDaIJbxQ5sXw8ZIgmOYSLg',
        # kubesphere-cluster-admin
        'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IlhpaDZIQ3VTczJIYWdUVjNpWEgzQWRMSV9DYl9NTTJVY2ZBSDhiMnhyNVkifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlc3BoZXJlLWNvbnRyb2xzLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJrdWJlc3BoZXJlLWNsdXN0ZXItYWRtaW4tdG9rZW4tZ3RsNmIiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoia3ViZXNwaGVyZS1jbHVzdGVyLWFkbWluIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiZmNlMmU3MjUtNTk5NS00Y2ExLTlhNDctZDExMWJjMzhlMTU1Iiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50Omt1YmVzcGhlcmUtY29udHJvbHMtc3lzdGVtOmt1YmVzcGhlcmUtY2x1c3Rlci1hZG1pbiJ9.liH9S0YQnq3nslXVj_f_UdgGtHYZsOpIZrJAz9SINdtz75EwTjdHV7MOWxbiOyVxBUVUB5XoEdAhSuvTeGKhd0LZx46RmxHWGyMY_RGM6NSmkSm9oGFpKjUFDhcWn3v74EtLfF3e8RO3jhcLSY2yFPAdmAk6rXVMs-tDAsAZXr3HKcRjqGYaTb5ucgTHf7C568loo3UBWRG6IW8-f0LwXymA-z6vjaqi_X3KzeA7p4dLO1ye3bnjS3g0Cyzc_fI_62ktL_WV2kFu-HcWpgWbSvJKXo6rtxn71sxJZTfHjIPbHH0ItmHlgreilITY_dv04SMxsBrdcWR5CRDq_6awyA',
    },
    'ali-dev': {
        'host': 'https://120.79.17.203:6443',
        'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IkR6T2M0NVhZOEg0RTJYQTR1RTlZSzhhdGhIMzBhejZVc3loQzNKa2x5VzQifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi10b2tlbi1qc3I2YyIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJhZG1pbiIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6ImZjYTliMDJhLTg4OWQtNDE5My1hYjdiLWVjZDE4MjgxYjdmYSIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDprdWJlLXN5c3RlbTphZG1pbiJ9.LNX4nZlt8paBHhfDH4OUSYuU83r-b44UpqZVxkntOt6Uze6sJUPX2gyKnmOV0QOOFIAQM1uAy0G0nEVdnEVfI5UD0mifodXvsia0yRZyNnTHqxkmUUj-MYNNd4Tt_ikqVkKW7Z-XBPUdYEjCg5pCwogBAdDHauESM0CqEBb6EkEAYfs5l0L3S49witPmpfmlBdW7EoJ2oyDlw-505ZNyvIMyo9hellxxww6cHlw2mDhV2xGpoIiy6qBMn4uzuJodB8xXp2qWu-etKe98OtT7gKECys6g3nUpcIbfb_hu4a8Um8cQUBbxpQ795CksyBru94EB5tpjRMJ9ftK8nB6ZOg',
    },
    'pts': {
        'host': 'https://172.20.16.8:6443',
        'token': 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjBUeFRoV3NsSVl6aG5QWnJFbERpNDdlYk5WLVpnQ3ZyVWJEN0V4X19DSUUifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJhZG1pbi10b2tlbi0ycTlnbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJhZG1pbiIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6ImQ1NWE5M2NjLWZiZjctNDE2OS1hYWZlLWE1OTQyMTM4ZWIwNyIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDprdWJlLXN5c3RlbTphZG1pbiJ9.ZEh9hrJMqtwDbZjZt4aKWxZJ8vOanoFYq0NNd49tVyf5XHi1Z04LlaNACXa9htvPAVoWRKUXDvIuvK3ToNAdlJPEiIhLt1chpYU478mPzIq9wCNpcZ18DmaaxWyfortRuhNr3tKNWpF31xGCkBwcq4BDwc-WWu34MSyAGrKWJGMplxxyzw7hXmoP-kN9tQwHRvDRRzMgteEgl6C_0PNW5Lpw0B6rgfJX24ez3k_c__FmjrAFfF8bHdMG7qALT6Bgj6iRkPLKjI0wrPE10s16CYpJ2xlVFrGY5ZL_OYHDr07iFvBNQUdsxduKCete0phqsYb_HCwNUvU5rtJd8ebdVg',
    },
}


def get_api_client(cluster="fat"):
    cluster = clusters[cluster]
    conf = Configuration()
    conf.host = cluster['host']
    conf.verify_ssl = False
    conf.api_key = {"authorization": "Bearer " + cluster['token']}
    return conf


class KubernetesLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self, cluster="fat"):
        # 默认fat
        self.conf = get_api_client(cluster)
        self.client = client.ApiClient(self.conf)
        self.k8s_core_v1_api = client.CoreV1Api(self.client)
        self.k8s_apps_v1_api = client.AppsV1Api(self.client)
        self.k8s_extensions_v1_beta1_api = client.ExtensionsV1beta1Api(self.client)

    @keyword
    def k8s_cluster(self, cluster="fat"):
        """切换k8s api对应的集群
        不调用该方法时, 默认为fat集群. 调用后，会影响后续所有的操作

        - cluster: 支持参数: dev, fat, uat, ali-dev, pts
        - raises ValueError: _description_
        """
        names = clusters.keys()
        log.info(f'切换到 {cluster} 集群')
        if cluster not in names:
            raise ValueError(f"Cluster '{cluster}' not found in {names}")

        self.conf = get_api_client(cluster)
        self.client = client.ApiClient(self.conf)
        self.k8s_core_v1_api = client.CoreV1Api(self.client)
        self.k8s_apps_v1_api = client.AppsV1Api(self.client)
        self.k8s_extensions_v1_beta1_api = client.ExtensionsV1beta1Api(self.client)

    def __fuzzy_query_pod(self, namespace, pod_name, pods):
        ret = self.k8s_core_v1_api.list_namespaced_pod(namespace)
        for i in ret.items:
            pod = i.metadata.name
            if pod_name in pod:
                pods.append(pod)
        log.info(f"默认开启模糊查询，查询到以下pod {pods}")

    @keyword
    def k8s_list_pods(self, namespace=None):
        log.info("Listing pods with their IPs:")
        if namespace:
            ret = self.k8s_core_v1_api.list_namespaced_pod(namespace, watch=False)
        else:
            ret = self.k8s_core_v1_api.list_pod_for_all_namespaces(watch=False)
        for i in ret.items:
            log.info("%s\t%s\t%s\t%s" % (i.status.pod_ip, i.metadata.namespace, i.metadata.name, i.metadata.labels))

    @keyword
    def k8s_exec_command(self, namespace, pod_name, command, fuzzy_query=True):
        pods = []
        if fuzzy_query:
            self.__fuzzy_query_pod(namespace, pod_name, pods)
        else:
            pods.append(pod_name)
        commands = ["/bin/sh", "-c", command]
        log.info(f"命令内容: {command}")
        result = []
        for pod in pods:
            try:
                resp = stream(
                    self.k8s_core_v1_api.connect_post_namespaced_pod_exec,
                    pod,
                    namespace,
                    command=commands,
                    stderr=True,
                    stdin=False,
                    stdout=True,
                    tty=False,
                )
                log.info(f"{pod}返回内容:\n{resp}")
                result.append(resp)
            except rest.ApiException as e:
                # pod is Terminaling will 500
                if e.status == 0 and e.reason == "Handshake status 500 Internal Server Error":
                    log.warn(f"{pod}状态可能正在终止中...对该pod执行命令失败")
                else:
                    log.warn(f"{pod}执行命令失败", str(e))
        return result

    @keyword
    def k8s_delete_pod(self, namespace, pod_name, fuzzy_query=True):
        pods = []
        if fuzzy_query:
            self.__fuzzy_query_pod(namespace, pod_name, pods)
        else:
            pods.append(pod_name)
        for pod in pods:
            log.info("正在等待pod删除成功")
            ret = self.k8s_core_v1_api.delete_namespaced_pod(pod, namespace)
            log.info(ret.status)

    @keyword
    def k8s_modify_apollo_for_deployment(self, namespace, deploy_name, apollo_meta, wait=480):
        self.return_ = """
        deployment更新后，增加检查pod启动状态
        - namespace:
        - deploy_name:
        - apollo_meta:
        - wait:
        - return:
        """
        old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
        env_list = copy.deepcopy(old_config.spec.template.spec.containers[0].env)
        for env in env_list:
            if env.name == "APOLLO_META":
                env.value = apollo_meta
        old_config.spec.template.spec.containers[0].env = env_list
        log.info(env_list)
        log.info("正在修改deployment环境变量...")
        self.k8s_apps_v1_api.replace_namespaced_deployment(deploy_name, namespace, body=old_config)
        if isinstance(wait, str):
            wait = int(wait)
        if wait != 0:
            self.k8s_health_check(namespace, deploy_name, wait)
        else:
            time.sleep(3)
            log.info("跳过等待")

    @keyword
    def k8s_health_check(self, namespace, deploy_name, timeout=480):
        success_count = 0
        start_ms = time.time() * 1000.0
        if isinstance(timeout, str):
            timeout = int(timeout)
        stop_ms = start_ms + (timeout * 1000.0)
        pre_status = False
        for _ in range(int(timeout * 10)):
            if success_count + 1 == 3:
                return True
            time.sleep(3)
            old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            status = old_config.status.replicas == old_config.status.available_replicas
            log.info(
                f"total: {old_config.status.replicas}, available: {old_config.status.available_replicas}, {status}"
            )
            if status:
                if pre_status:
                    success_count += 1
                pre_status = status
            else:
                pre_status = status
                success_count = 0
            now_ms = time.time() * 1000.0
            if now_ms >= stop_ms:
                break
        raise RuntimeError(f"{namespace} {deploy_name} {timeout}s后仍未完成启动")

    @keyword
    def k8s_get_svc_node_port(self, namespace, deploy_name):
        ret = self.k8s_core_v1_api.read_namespaced_service(deploy_name, namespace)
        log.info(str(ret.metadata.creation_timestamp.astimezone()), ret.spec.ports[0].name, ret.spec.ports[0].node_port)

    @keyword
    def k8s_modify_trace_for_deployment(self, namespace, deploy_name, wait=0):
        """
        deployment更新后，增加检查pod启动状态
        - namespace:
        - deploy_name:
        - wait:
        - return:
        """
        if "," in deploy_name:
            deploy_names = deploy_name
            for deploy_name in deploy_names.split(","):
                self.k8s_modify_trace_for_deployment(namespace, deploy_name, wait=wait)
        else:
            log.info(namespace, deploy_name)
            old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            annotations = copy.deepcopy(old_config.spec.template.metadata.annotations)
            log.info(annotations)
            if annotations:
                annotations["instrumentation.opentelemetry.io/inject-java"] = "true"
            else:
                annotations = {"instrumentation.opentelemetry.io/inject-java": "true"}
            log.info(annotations)
            old_config.spec.template.metadata.annotations = annotations
            commands = copy.deepcopy(old_config.spec.template.spec.containers[0].command)
            log.info(commands)
            commands[-1] = re.sub("sed(.*)mkdir", "mkdir", commands[-1])
            commands[-1] = (
                    "sed -i 's/\[%X{X-B3-TraceId:-}\]/trace_id=%X{trace_id}/g' config/logback-spring.xml ;" + commands[
                -1]
            )
            log.info(commands)
            old_config.spec.template.spec.containers[0].command = commands
            log.info("开始修改deployment环境变量...")
            self.k8s_apps_v1_api.replace_namespaced_deployment(deploy_name, namespace, body=old_config)
            if isinstance(wait, str):
                wait = int(wait)
            if wait != 0:
                self.k8s_health_check(namespace, deploy_name, wait)
            else:
                log.info("跳过等待")

    @keyword
    def k8s_delete_trace_for_deployment(self, namespace, deploy_name, wait=0):
        """
        deployment更新后，增加检查pod启动状态
        - namespace:
        - deploy_name:
        - wait:
        - return:
        """
        if "," in deploy_name:
            deploy_names = deploy_name
            for deploy_name in deploy_names.split(","):
                self.k8s_delete_trace_for_deployment(namespace, deploy_name, wait=wait)
        else:
            log.info(namespace, deploy_name)
            old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            annotations = copy.deepcopy(old_config.spec.template.metadata.annotations)
            log.info(annotations)
            if annotations and "instrumentation.opentelemetry.io/inject-java" in annotations:
                annotations.pop("instrumentation.opentelemetry.io/inject-java")
            old_config.spec.template.metadata.annotations = annotations
            commands = copy.deepcopy(old_config.spec.template.spec.containers[0].command)
            log.info(commands)
            commands[-1] = re.sub("sed(.*)mkdir", "mkdir", commands[-1])
            log.info(commands)
            old_config.spec.template.spec.containers[0].command = commands
            log.info("开始修改deployment环境变量...")
            self.k8s_apps_v1_api.replace_namespaced_deployment(deploy_name, namespace, body=old_config)
            if isinstance(wait, str):
                wait = int(wait)
            if wait != 0:
                self.k8s_health_check(namespace, deploy_name, wait)
            else:
                log.info("跳过等待")

    @keyword
    def k8s_delete_terminating_pod(self):
        ret = self.k8s_core_v1_api.list_pod_for_all_namespaces()
        for i in ret.items:
            pod = i.metadata.name
            # print(i.status)
            status = i.status.phase
            print(pod, status)

    @keyword
    def k8s_copy_for_deployment(self, namespace, deploy_name, new_namespace, need_mock=False):
        """
        deployment更新后，增加检查pod启动状态
        - namespace:
        - deploy_name:
        - wait:
        - return:
        """
        if "," in deploy_name:
            deploy_names = deploy_name
            for deploy_name in deploy_names.split(","):
                self.k8s_copy_for_deployment(namespace, deploy_name, new_namespace, need_mock=need_mock)
        else:
            log.info(deploy_name)
            old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            old_namespace = old_config.metadata.namespace
            old_config.metadata.namespace = new_namespace
            old_config.metadata.resource_version = None
            old_config.metadata.uid = None
            log.info(f"{old_namespace} => {new_namespace}")
            if need_mock:
                env_list = copy.deepcopy(old_config.spec.template.spec.containers[0].env)
                for env in env_list:
                    if env.name == "APOLLO_META":
                        old_value = env.value
                        new_value = "http://apollo-service-fat-apollo-configservice.apollo:8080"
                        env.value = new_value
                        log.info(f"{old_value} => {new_value}")
                old_config.spec.template.spec.containers[0].env = env_list
            try:
                self.k8s_apps_v1_api.create_namespaced_deployment(new_namespace, old_config)
            except ApiException as e:
                if e.status == 409:
                    try:
                        self.k8s_apps_v1_api.patch_namespaced_deployment(deploy_name, new_namespace, old_config)
                    except ApiException as e:
                        log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
                else:
                    log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
            svc_name = deploy_name + "-svc"
            log.info(svc_name)
            old_service = self.k8s_core_v1_api.read_namespaced_service(svc_name, namespace)
            old_namespace = old_service.metadata.namespace
            old_service.metadata.namespace = new_namespace
            old_service.metadata.resource_version = None
            old_service.metadata.uid = None
            log.info(f"{old_namespace} => {new_namespace}")
            old_service.spec.cluster_ip = None
            port_list = copy.deepcopy(old_service.spec.ports)
            old_port = None
            for port in port_list:
                old_port = port.node_port
                port.node_port = None
            old_service.spec.ports = port_list
            try:
                ret = self.k8s_core_v1_api.create_namespaced_service(new_namespace, old_service)
                log.info(f"{old_port} => {ret.spec.ports[0].node_port}")
            except ApiException as e:
                if e.status == 409:
                    try:
                        ret = self.k8s_core_v1_api.patch_namespaced_service(svc_name, new_namespace, old_service)
                        log.info(f"{old_port} => {ret.spec.ports[0].node_port}")
                    except ApiException as e:
                        log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
                else:
                    log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))

    @keyword
    def k8s_double_for_deployment(self, namespace, deploy_name, new_deploy_name, need_mock=False):
        """
        deployment更新后，增加检查pod启动状态
        - namespace:
        - deploy_name:
        - wait:
        - return:
        """
        if "," in deploy_name:
            deploy_names = deploy_name
            for deploy_name in deploy_names.split(","):
                self.k8s_copy_for_deployment(namespace, deploy_name, namespace, need_mock=need_mock)
        else:
            log.info(deploy_name)
            old_config = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            old_namespace = old_config.metadata.namespace
            old_config.metadata.namespace = namespace
            old_config.metadata.name = new_deploy_name
            old_config.metadata.resource_version = None
            old_config.metadata.uid = None
            old_config.metadata.labels["app"] = new_deploy_name
            old_config.metadata.labels["name"] = new_deploy_name
            print(old_config.spec.selector.match_labels)
            old_config.spec.template.metadata.labels["app"] = new_deploy_name
            old_config.spec.template.metadata.labels["name"] = new_deploy_name
            old_config.spec.selector.match_labels["app"] = new_deploy_name
            old_config.spec.selector.match_labels["name"] = new_deploy_name
            log.info(f"{old_namespace} => {namespace}")
            if need_mock:
                env_list = copy.deepcopy(old_config.spec.template.spec.containers[0].env)
                for env in env_list:
                    if env.name == "APOLLO_META":
                        old_value = env.value
                        new_value = "http://apollo-service-fat-apollo-configservice.apollo:8080"
                        env.value = new_value
                        log.info(f"{old_value} => {new_value}")
                old_config.spec.template.spec.containers[0].env = env_list
            try:
                self.k8s_apps_v1_api.create_namespaced_deployment(namespace, old_config)
            except ApiException as e:
                if e.status == 409:
                    try:
                        self.k8s_apps_v1_api.patch_namespaced_deployment(new_deploy_name, namespace, old_config)
                    except ApiException as e:
                        log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
                else:
                    log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
            svc_name = deploy_name + "-svc"
            log.info(svc_name)
            old_service = self.k8s_core_v1_api.read_namespaced_service(svc_name, namespace)
            old_namespace = old_service.metadata.namespace
            old_service.metadata.name = new_deploy_name + "-svc"
            old_service.metadata.namespace = namespace
            old_service.metadata.resource_version = None
            old_service.metadata.uid = None
            old_service.metadata.uid = None
            log.info(f"{old_namespace} => {namespace}")
            old_service.spec.cluster_ip = None
            old_service.spec.selector["app"] = new_deploy_name
            old_service.spec.selector["name"] = new_deploy_name
            port_list = copy.deepcopy(old_service.spec.ports)
            old_port = None
            for port in port_list:
                old_port = port.node_port
                port.node_port = None
            old_service.spec.ports = port_list
            try:
                ret = self.k8s_core_v1_api.create_namespaced_service(namespace, old_service)
                log.info(f"{old_port} => {ret.spec.ports[0].node_port}")
            except ApiException as e:
                if e.status == 409:
                    try:
                        ret = self.k8s_core_v1_api.replace_namespaced_service(svc_name, namespace, old_service)
                        log.info(f"{old_port} => {ret.spec.ports[0].node_port}")
                    except ApiException as e:
                        log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))
                else:
                    log.info("resp：", e.status, e.reason, json.loads(e.body).get("message"))

    @keyword
    def k8s_modify_trace_ns(self, namespace):
        if "," in namespace:
            namespaces = namespace
            for namespace in namespaces.split(","):
                self.k8s_modify_trace_ns(namespace)
        else:
            # log.info(namespace)
            log.info(f"kubectl apply -f instrumentation.yaml -n {namespace}")
            old_config = self.k8s_core_v1_api.read_namespace(namespace)
            # if not old_config.metadata.labels:
            #     old_config.metadata.labels = {"skywalking-injection": "false"}
            if not old_config.metadata.annotations:
                old_config.metadata.annotations = {"instrumentation.opentelemetry.io/inject-java": "true"}
            else:
                old_config.metadata.annotations["instrumentation.opentelemetry.io/inject-java"] = "true"
            if old_config.metadata.labels and "skywalking-injection" in old_config.metadata.labels:
                old_config.metadata.labels["skywalking-injection"] = "false"
            # print(old_config.metadata.labels)
            # print(old_config.metadata.annotations)
            self.k8s_core_v1_api.replace_namespace(namespace, body=old_config)

    def _get_port_item(self, ports: List[V1ServicePort], port: int):
        """查询 svc 中对应 port"""
        return [port_item for port_item in ports if port_item.port == port]

    @keyword
    def k8s_modify_service(self, svc_name: str, namespace: str, expect_port: int, port_name: str = 'TCP'):
        # 可能会找不到，找不到时这里会直接抛异常 Reason: Not Found
        svc_type: str = 'NodePort'
        service = self.k8s_core_v1_api.read_namespaced_service(svc_name, namespace)
        port_item = self._get_port_item(service.spec.ports, expect_port)
        if port_item and service.spec.type == svc_type:
            # 如果是NodePort类型，获取对应nodeport并返回
            return port_item[0].node_port

        # 修改为NodePort
        service.spec.type = svc_type
        if not port_item:
            new_port = V1ServicePort(name=port_name, port=expect_port, target_port=expect_port, protocol='TCP')
            service.spec.ports.append(new_port)
        try:
            # 存在的话，才更新service type
            service = self.k8s_core_v1_api.patch_namespaced_service(svc_name, namespace, service)
            port_item = self._get_port_item(service.spec.ports, expect_port)
            # 此时一定会存在
            # 等待3秒
            log.info('等待kubeproxy负载生效')
            time.sleep(3)
            return port_item[0].node_port
        except ApiException as e:
            log.error("resp：", e.status, e.reason, json.loads(e.body).get("message"))
        return 0

    @keyword
    def k8s_node_port_url(self, svc_url) -> str:
        """通过k8s svc域名, 查询得到nodeport 请求地址, 便于外部调用

        - svc_url: http://{svc_name}.{namespace}:{port}{path}, 例如http://crypto-hsm-svc.utils:8080/api/v1/keys
        - return: 例如http://172.20.20.32:20101/api/v1/keys
        """
        parsed_result = urlparse(svc_url)
        if not parsed_result:
            raise ValueError(f'Invalid svc_url: {svc_url}')
        last_donet = parsed_result.hostname.rindex('.')
        scheme = parsed_result.scheme
        svc_name, namespace = parsed_result.hostname[:last_donet], parsed_result.hostname[last_donet + 1:]
        port: int = parsed_result.port
        path = parsed_result.path
        log.info(f'解析svc域名: {[svc_name, namespace, port, path]}')
        node_port = self.k8s_modify_service(svc_name, namespace, port, scheme)
        node_ip = urlparse(self.conf.host).hostname
        http_url = f'{scheme}://{node_ip}:{node_port}{path}'
        log.info(f'转换nodeport地址: {http_url}')
        return http_url

    @keyword
    def k8s_service_port_url(self, svc_url) -> str:
        parsed_result = urlparse(svc_url)
        if not parsed_result:
            raise ValueError(f'Invalid svc_url: {svc_url}')
        last_donet = parsed_result.hostname.rindex('.')
        scheme = parsed_result.scheme
        svc_name, namespace = parsed_result.hostname[:last_donet], parsed_result.hostname[last_donet + 1:]
        port: int = parsed_result.port
        path = parsed_result.path
        log.info(f'解析svc域名: {[svc_name, namespace, port, path]}')
        service = self.k8s_core_v1_api.read_namespaced_service(name=svc_name, namespace=namespace)
        cluster_ip = service.spec.cluster_ip
        http_url = f'{scheme}://{cluster_ip}:{port}{path}'
        log.info(f'转换service地址: {http_url}')
        return http_url

    @keyword
    def k8s_restart_deployment(self, namespace, deploy_name, wait=60):
        """
        - namespace:
        - deploy_name:
        - wait:
        - return:

        # 重启大数据服务,taskmanager不会重启

        | K8s Cluster | uat |
        | K8s Restart Deployment | flink-session-cluster | flink-xdata-dws-pay-group |
        """
        if "," in deploy_name:
            deploy_names = deploy_name
            for deploy_name in deploy_names.split(","):
                self.k8s_restart_deployment(namespace, deploy_name, wait=wait)
        else:
            log.info(namespace, deploy_name)
            deployment = self.k8s_apps_v1_api.read_namespaced_deployment(deploy_name, namespace)
            deployment.spec.template.metadata.annotations = {
                "kubectl.kubernetes.io/restartedAt": datetime.datetime.now().isoformat()
            }
            # patch the deployment
            try:
                resp = self.k8s_apps_v1_api.patch_namespaced_deployment(
                    name=deploy_name, namespace=namespace, body=deployment
                )
                log.info(resp)
            except Exception:
                log.warn(traceback.format_exc())
            if isinstance(wait, str):
                wait = int(wait)
            if wait != 0:
                self.k8s_health_check(namespace, deploy_name, wait)
            else:
                log.info("跳过等待")

    def k8s_pts_edit_describe_pods(self):
        # 获取所有的命令空间
        nss = self.k8s_core_v1_api.list_namespace()
        # 获取该命名空间下的svc信息，只对task目录下的内容进行处理
        namespaces = []
        for ns in nss.items:
            name = ns.metadata.name
            if "task" in name:
                namespaces.append(name)
        # log.info(f"Namespace Name: {namespaces}")

        ##获取当前已部署pod的资源信息
        lns_all = self.k8s_core_v1_api.list_pod_for_all_namespaces(watch=False)
        namespaces_new = []
        for i in lns_all.items:
            if "task" in i.metadata.namespace:
                namespaces_new.append(i.metadata.namespace)
        namespaces_new = set(namespaces_new)
        # log.info(f"Namespaces new: {namespaces_new}")

        ##比较list，命名空间不存在任务的，进行删除操作
        diff = [item for item in namespaces if item not in namespaces_new]
        # log.info(len(namespaces),len(namespaces_new),len(diff),diff)
        for di in diff:
            log.info(f"正在清理没有使用的命令空间: {di}")
            self.k8s_core_v1_api.delete_namespace(di)
            time.sleep(20)

        ##循环遍历该控件下的内容
        for ns in namespaces:
            lns = self.k8s_core_v1_api.list_namespaced_service(ns)
            # log.info("namespaces",len(lns.items()))

            ##设置超过N天就删除操作
            days_to_add = 60

            ##获取当前时间处理
            local_date_now = datetime.now()
            local_date_now_str = local_date_now.strftime('%Y-%m-%d')
            ldns = datetime.strptime(local_date_now_str, '%Y-%m-%d')

            for svc in lns.items:
                # print(
                #     f"Service Name: {svc.metadata.name} Namespace: {svc.metadata.namespace} Cluster IP: {svc.metadata.creation_timestamp} Selector: {svc.spec.selector.get('app')}")
                svc_createtime = svc.metadata.creation_timestamp
                svc_selector = svc.spec.selector.get('app')
                svc_namespace = svc.metadata.namespace

                ##获取pod的创建时间
                svc_createtime = svc_createtime + timedelta(days=days_to_add)
                svc_create_time_new = svc_createtime.strftime('%Y-%m-%d')
                sctn = datetime.strptime(svc_create_time_new, '%Y-%m-%d')

                # 检查加上天数后的时间是否小于当前时间
                if sctn < ldns:
                    log.info(f"需要处理的服务列表：", svc_selector, svc_namespace)
                    self.pts_describe_replicas(svc_selector, svc_namespace, 0)

    def pts_describe_replicas(self, deployment_name, namespace, replicas):
        deployment = self.k8s_apps_v1_api.read_namespaced_deployment(name=deployment_name, namespace=namespace)
        deployment.spec.replicas = replicas
        self.k8s_apps_v1_api.replace_namespaced_deployment(name=deployment_name, namespace=namespace, body=deployment)
        log.info("处理结束。。。")
        time.sleep(20)
