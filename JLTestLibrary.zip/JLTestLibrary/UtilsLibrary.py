import base64
import binascii
import datetime
import hashlib
import io
import json
import os
import random
import socket
import string
import sys
import time
import uuid
from functools import wraps
from typing import Dict, Union

import pyotp
import qrcode
from gmssl.sm3 import sm3_hash
from robot.api.deco import keyword
from robot.libraries.DateTime import convert_date

from . import log

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET


class UtilsLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @staticmethod
    @keyword
    def get_split_str(split_str: str, key: str = "|", n: int = -1) -> str:
        """通过指定分隔符对字符串进行切片，默认返回最后一个分片"""
        if isinstance(split_str, str):
            return split_str.split(key)[n]
        else:
            return "None"

    @staticmethod
    @keyword
    def get_uuid():
        return uuid.uuid4()

    @staticmethod
    @keyword
    def get_date_time(date_time_format: str = "%Y-%m-%d %H:%M:%S"):
        return datetime.datetime.strftime(datetime.datetime.now(), date_time_format)

    @staticmethod
    @keyword
    def get_nonce():
        return str(uuid.uuid4()).replace("-", "")

    @staticmethod
    @keyword
    def get_trans_year():
        """获取年"""
        return datetime.datetime.now().year

    @staticmethod
    @keyword
    def get_trans_month(format: bool = True):
        """获取月

        默认获取月份, 如07
        format=False时, 返回7
        """
        if format:
            inputtime = time.strftime("%m", time.localtime())
        else:
            inputtime = datetime.datetime.now().month
        return inputtime

    @staticmethod
    @keyword
    def get_trans_ym():
        return time.strftime("%Y%m", time.localtime())

    @staticmethod
    @keyword
    def get_trans_ymd():
        return time.strftime("%Y%m%d", time.localtime())

    @staticmethod
    @keyword
    def get_trans_day():
        inputtime = time.strftime("%d", time.localtime())
        return inputtime

    @staticmethod
    @keyword
    def get_trans_time():
        """生成时间戳,生成时间为：2019-08-27 20:34:56"""
        ct = time.time()
        local_time = time.localtime(ct)
        data_head = time.strftime("%Y-%m-%d %H:%M:%S", local_time)
        # print(data_head)
        return data_head

    @staticmethod
    @keyword
    def get_trans_time_not_space():
        """
        生成时间戳,生成时间为：2019-08-27 20:34:56
        生成时间戳,生成时间为：20190827203456
        """
        ct = time.time()
        local_time = time.localtime(ct)
        data_head = time.strftime("%Y-%m-%d %H:%M:%S", local_time)
        data_head_no_space = time.strftime("%Y%m%d%H%M%S", local_time)
        # print(data_head)
        return data_head, data_head_no_space

    @staticmethod
    @keyword
    def get_time_d_m_y():
        # 生成时间戳,生成时间为： 27-08-2019
        data_head = time.strftime("%d-%m-%Y")
        # print(data_head)
        return data_head

    @staticmethod
    @keyword
    def trans_time_ct():
        # 生成时间戳,生成时间为：  20191015 16:36:16
        ct = time.time()
        local_time = time.localtime(ct)
        data_head = time.strftime("%Y%m%d %H:%M:%S", local_time)
        # print(data_head)
        return data_head

    @staticmethod
    @keyword
    def time_strft():
        return datetime.datetime.now().strftime("%Y%m%d %H:%M:%S.%f")[:-3]

    @staticmethod
    @keyword
    def time_se():
        # 生成时间戳,生成时间为：  20191015 16:36:16
        ct = time.time()
        local_time = time.localtime(ct)
        data_head = time.strftime("%Y%m%d %H:%M:%S", local_time)
        # print(data_head)
        return data_head

    @staticmethod
    @keyword
    def trans_time_not_space():
        # 生成时间戳,生成时间为：20190827203456
        ct = time.time()
        local_time = time.localtime(ct)
        data_head = time.strftime("%Y%m%d%H%M%S", local_time)
        # print(data_head)
        return data_head

    @staticmethod
    @keyword
    def format_string_time_to_beijing_time(original_string, _format='%Y%m%d%H%M%S'):
        """ 20240108143908 ----> 2024-01-08 14:39:08 """
        date_time_obj = datetime.datetime.strptime(original_string, _format)
        formatted_string = date_time_obj.strftime("%Y-%m-%d %H:%M:%S")
        return formatted_string

    @staticmethod
    @keyword
    def format_beijing_time_to_timestamp(local_time=None, _format='%Y-%m-%d %H:%M:%S'):
        """北京时间转换为时间戳，如 2024-01-08 15:01:42 ----> 1704697302"""
        now_time = datetime.datetime.now().strftime(_format) if not local_time else local_time
        time_stamp = int(datetime.datetime.strptime(now_time, _format).timestamp())
        return str(time_stamp)

    @staticmethod
    @keyword
    def format_timestamp_to_beijing_time(timestamp=None, _format='%Y-%m-%d %H:%M:%S'):
        """将时间戳转换为北京时间，如 1704697302 ---> 2024-01-08 15:01:42"""
        now_time = time.time() if not timestamp else timestamp
        return datetime.datetime.fromtimestamp(now_time).strftime(_format)

    @staticmethod
    @keyword
    def format_beijing_time_to_string_time(beijing_time=None, _format='%Y-%m-%d %H:%M:%S'):
        """ 2024-01-08 14:39:08 ----> 20240108143908 """
        now_time = datetime.datetime.now().strftime(_format) if not beijing_time else beijing_time
        date_time_obj = datetime.datetime.strptime(now_time, _format)
        formatted_str = date_time_obj.strftime('%Y%m%d%H%M%S')
        return formatted_str

    @staticmethod
    @keyword
    def format_min_beijing_time_to_string_time():
        """将今天的零点北京时间转换为字符串格式"""
        today = datetime.datetime.now().date()
        midnight = datetime.datetime.combine(today, datetime.datetime.min.time())
        formatted_time = midnight.strftime("%Y%m%d%H%M%S")
        return formatted_time

    @staticmethod
    @keyword
    def format_max_beijing_time_to_string_time():
        """将今天的23:59:59北京时间转换为字符串格式"""
        today = datetime.datetime.now().date()
        midnight = datetime.datetime.combine(today, datetime.datetime.max.time())
        formatted_time = midnight.strftime("%Y%m%d%H%M%S")
        return formatted_time

    @staticmethod
    @keyword
    def get_order_id(busi_type, busi_sub_type):
        # 根据大类+小类，生成订单号
        trans_time = UtilsLibrary.trans_time_not_space()
        orderid = busi_type + "" + busi_sub_type + "" + trans_time + "" + str(random.randint(100000, 200000))
        return orderid

    @staticmethod
    @keyword
    def trans_time_not_space_random():
        # 生成时间戳,生成时间为：20190827203456
        trans_time_random = str(UtilsLibrary.trans_time_not_space()) + "" + str(UtilsLibrary.order_random())
        return trans_time_random

    @staticmethod
    @keyword
    def order_random():
        # 默认生成10位数的返回值
        return random.randint(10000000000, 999999999999)

    @staticmethod
    @keyword
    def trans_time_not_space_ms():
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

    @staticmethod
    @keyword
    def order_random_len(number):
        # 根据传入的数值，来生成返回数据的长度
        # 输入长度不能大于32
        if isinstance(number, int):
            if number <= 32:
                start, end = UtilsLibrary.random_generator(number)
                return random.randint(int(start), int(end))
            else:
                raise Exception("number length <= 32 !")
        else:
            raise Exception("order_random method afferent int type!")

    @staticmethod
    @keyword
    def random_generator(number):
        # 生成遍历随机值
        num_0 = "1"
        num_9 = "9"
        for i in range(1, number):
            num_0 = num_0 + "0"
        for i in range(1, number):
            num_9 = num_9 + "9"
        return num_0, num_9

    @staticmethod
    @keyword
    def unicode_to_str(value):
        if isinstance(value, str):
            return str(value)

    @staticmethod
    @keyword
    def get_remote_ip():
        """获取主机IP地址"""
        hostname = socket.gethostname()
        ipList = socket.gethostbyname_ex(hostname)
        remote_ip = ipList[len(ipList) - 1]
        # if len(remote_ip)>1:
        #     remote_ip = remote_ip[1]
        # else:
        #     remote_ip = remote_ip[0]
        remote_ip = remote_ip[0]
        return remote_ip

    @staticmethod
    @keyword
    def dict_to_xml(data):
        """dict转xml"""

        def to_xml(data):
            xx = []
            for k, v in data.items():
                if isinstance(v, dict):
                    aa = to_xml(v)
                    s = "<{key}>{value}</{key}>".format(key=k, value=aa)
                else:
                    s = "<{key}>{value}</{key}>".format(key=k, value=v)
                xx.append(s)
            return "".join(xx)

        return '<?xml version="1.0" encoding="UTF-8" standalone="no"?><xml>' + to_xml(data) + "</xml>"

    @staticmethod
    @keyword
    def xml_to_dict(xml_str):
        """xml转dict"""
        msg = {}
        root_elem = ET.fromstring(xml_str)
        if root_elem.tag.lower() == "xml" or root_elem.tag.lower() == "root":
            for ch in root_elem:
                msg[ch.tag] = ch.text
        return msg

    @staticmethod
    @keyword
    def Get_NTime():
        """获取当前时间戳，%Y%m%d"""
        inputtime = time.strftime("%Y%m%d", time.localtime())
        return inputtime

    #
    @staticmethod
    @keyword
    def get_date_YYYYMMDD():
        """获取当前时间戳，Y-%m-%d"""
        inputtime = time.strftime("%Y-%m-%d", time.localtime())
        return inputtime

    @staticmethod
    @keyword
    def Get_riqi():
        """获取当天是几号 ,比如当月11号"""
        inputtime = time.strftime("%d", time.localtime())
        return inputtime

    @staticmethod
    @keyword
    def Get_nianyue():
        """获取当天年月，比如当天是2020年02月"""
        inputtime = time.strftime("%Y%m", time.localtime())
        return inputtime

    @staticmethod
    @keyword
    def kill_python_process():
        """kill python"""
        try:
            input_system = "ps aux|grep python|grep -v grep|cut -c 9-15|xargs kill -15"
            # os.system(input_system)
            UtilsLibrary.sys_platform_command(input_system)
        except Exception as err:
            err.args = err.args + ("kill python process is faild!",)
            raise err

    #
    @staticmethod
    @keyword
    def sys_platform_command(command):
        """根据操作系统来执行命令
        linux2 标识linux
        win32 标识windows
        """
        if UtilsLibrary.sys_platform() == "linux2":
            os.system(command)
        else:
            pass

    @staticmethod
    @keyword
    def sys_platform():
        """获取当前操作系统标识"""
        return sys.platform

    @staticmethod
    def _get_func_params(func, *args, **kwargs):
        """获取方法的入参"""
        dict_param = {}
        if len(args) > 0:
            var_names = func.__code__.co_varnames
            for i in range(len(args)):
                if var_names[i] == "self":
                    continue
                dict_param.update({var_names[i]: args[i]})

        if len(kwargs) > 0:
            dict_param.update(kwargs.items())

        return dict_param

    @staticmethod
    def _method_logging(func):
        """装饰器，打印方法入参和出参"""

        @wraps(func)
        def wrapper(*args, **kwargs):
            func_name = func.__name__
            func_params = UtilsLibrary._get_func_params(func, *args, **kwargs)
            log.info(f"[{func_name}][Params] ==> {str(func_params)}")
            result = func(*args, **kwargs)
            log.info(f"[{func_name}][Return] <== {result}")
            return result

        return wrapper

    @staticmethod
    def _get_order_id_version(v: str) -> Dict[str, int]:
        """"""
        version_1 = {"version": "1", "timestamp_start": "2020-01-01 00:00:00:000", "timestamp": 0}
        version_2 = {"version": "2", "timestamp_start": "2049-10-01 00:00:00:000", "timestamp": 0}
        version_3 = {"version": "3", "timestamp_start": "2077-01-01 00:00:00:000", "timestamp": 0}
        versions = [version_1, version_2, version_3]
        timestamp = 0
        for ver in versions:
            if v == ver["version"]:
                timestamp = int(time.mktime(time.strptime(ver["timestamp_start"], "%Y-%m-%d %H:%M:%S:%f"))) * 1000
        return {"timestamp": timestamp}

    @staticmethod
    @keyword
    def get_hash_code(s):
        """
        Java hashcode function
        - s:
        - return:
        """
        h = 0
        n = len(s)
        for i, c in enumerate(s):
            h = h + ord(c) * 31 ** (n - 1 - i)
        bits = 4 * 8
        return (h + 2 ** (bits - 1)) % 2 ** bits - 2 ** (bits - 1)

    @staticmethod
    @keyword
    def get_date_from_order_id(order_id: str):
        """从订单系统的24位订单号，解析出其中的时间"""
        hash_code = UtilsLibrary.get_hash_code(order_id[:-2])
        checksum = abs(hash_code) % 100
        if checksum != int(order_id[-2:]):
            raise AssertionError("订单号校验失败: {0}, checksum: {1}".format(order_id, checksum))
        order_id_version = order_id[2]
        version = UtilsLibrary._get_order_id_version(order_id_version)
        if version.get("timestamp", 0) == 0:
            raise AssertionError("不支持的订单号: {0}, 版本: {1}".format(order_id, order_id_version))
        time_serial = int(order_id[3:22])
        time_difference = time_serial >> 23
        log.info(f"time_serial: {time_serial}")
        log.info(f"time_difference: {time_difference}")
        order_time = time_difference + version.get("timestamp", 0)
        log.info(f"order_time: {order_time}")
        struct_time = time.localtime(order_time / 1000)
        year_month = time.strftime("%Y%m", struct_time)
        return year_month

    @staticmethod
    @keyword
    def get_ordertime_from_order_id(order_id: str):
        """从订单系统的24位订单号，解析出其中的时间"""
        hash_code = UtilsLibrary.get_hash_code(order_id[:-2])
        checksum = abs(hash_code) % 100
        if checksum != int(order_id[-2:]):
            raise AssertionError("订单号校验失败: {0}, checksum: {1}".format(order_id, checksum))
        order_id_version = order_id[2]
        version = UtilsLibrary._get_order_id_version(order_id_version)
        if version.get("timestamp", 0) == 0:
            raise AssertionError("不支持的订单号: {0}, 版本: {1}".format(order_id, order_id_version))
        time_serial = int(order_id[3:22])
        time_difference = time_serial >> 23
        log.info(f"time_serial: {time_serial}")
        log.info(f"time_difference: {time_difference}")
        order_time = time_difference + version.get("timestamp", 0)
        log.info(f"order_time: {order_time}")
        seconds = order_time / 1000.0
        final_time = datetime.datetime.fromtimestamp(seconds)
        log.info(f"final_time: {final_time}")
        return final_time


    @staticmethod
    @keyword
    def get_new_order_id_by_date(expect_order_time: str):
        """输入YYYY-mm-dd HH:MM:SS，模拟返回24位订单号

        Example:
            | ${order_id} | get_new_order_id_by_date | 2022-01-18 10:00:00 |
        """
        order_id = "41"
        version_time_map = {}
        for i in range(1, 4):
            version_data = UtilsLibrary._get_order_id_version(str(i))
            version_time_map[str(i)] = version_data.get("timestamp")
        order_time = time.mktime(time.strptime(expect_order_time, "%Y-%m-%d %H:%M:%S")) * 1000
        order_time = int(order_time)
        log.info(f"order_time: {order_time}")
        version = "1"
        for k, v in version_time_map.items():
            if order_time > v:
                version = k
        version_time = version_time_map[version]
        log.info(f"version_time: {version_time}")
        time_difference = int(order_time - version_time)
        log.info(f"time_difference: {time_difference}")
        time_serial = time_difference << 23
        order_id += version + str(time_serial).rjust(19, "0")
        hash_code = UtilsLibrary.get_hash_code(order_id)
        checksum = str(abs(hash_code) % 100)
        order_id += checksum
        log.info(f"order_id : {order_id}")
        return order_id

    @staticmethod
    @keyword
    def get_upper(str):
        """
        - return: 含有英文字母，全部转换大写
        """
        return str.upper()

    @staticmethod
    @keyword
    def get_lower(str):
        """
        - return: 含有英文字母，全部转换小写
        """
        return str.lower()

    @staticmethod
    @keyword
    def get_account_date_and_trans_time():
        """
        - return: 返回当前时间和实际记账时间
        """
        timer = datetime.datetime.now()
        timestamp = str(timer)[:-7]
        times_split = list(map(int, timestamp.split()[1].split(":")))
        flag = 0
        # 判断时间是否是23：00:00之后
        if times_split[0] == 23 and (times_split[1] > 0 or times_split[2] > 0):
            flag = 1
        account_time = str(timer + datetime.timedelta(days=flag))[0:10]
        return timestamp, account_time

    @staticmethod
    @keyword
    def filepath_to_base64_str(path):
        with open(path, "rb") as f:
            byte_data = f.read()
        result = base64.b64encode(byte_data).decode("ascii")
        log.info(result)
        return result

    @staticmethod
    @keyword
    def get_file_hash_base64(file, type):
        """对文件内容进行哈希，并base64编码"""
        with open(file, 'rb') as f:
            bytes = f.read()
            if type == 'SM3':
                hash = bytes.fromhex(sm3_hash([i for i in bytes]))
            elif type == 'SHA256':
                hash = hashlib.sha256(bytes).digest()
            else:
                return None
            return base64.b64encode(hash).decode('utf-8')

    @staticmethod
    @keyword
    def get_file_binary_code(file_path):
        """获取文件的二进制内容"""
        return base64.b64decode(UtilsLibrary().filepath_to_base64_str(file_path)).decode('latin-1')

    @staticmethod
    @keyword
    def get_yesterday():
        """获取前一天时间戳，%Y-%m-%d %H:%M:%S"""

        yesterday = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 86400))
        return yesterday

    @staticmethod
    @keyword
    def random_int(start: int, end: int, width: int = 0, position: str = "left", fillchar: str = '0') -> str:
        """
        生成随机数字
        - param start:开始范围 如1
        - param end: 结束范围 如10
        - param width: 生成结果宽度 如2
        - param position: 左对齐 or 右对齐  如left或者right
        - param fillchar: 填充字符 默认以'0'填充
        - return: 若传入random_int(1,10,2,'right','h') 则会返回 'h1'  'h2'  。。。 '10'等
        """
        random_num = random.randint(start, end)
        if width == 0:
            return str(random_num)
        else:
            if position == "left":
                return str(random_num).ljust(width, fillchar)
            else:
                return str(random_num).rjust(width, fillchar)

    @staticmethod
    @keyword
    def web_get_otp(self, s):
        totp = pyotp.TOTP(s)
        now = totp.now()
        msg = "Current OTP: %s" % now
        log.info(msg, also_console=True)
        return now

    @staticmethod
    @keyword
    def modify_bill_trans_time(seconds_value=0, minutes_value=0, hours_value=0, days_value=0, weeks_value=0):
        """
        获取当日0点时间：yyyymmddhhmmss
        基于当日0点时间可传参正负进行加减
        """
        billtime = datetime.date.today().strftime('%Y/%m/%d %H:%M:%S')
        billtime = datetime.datetime.strptime(billtime, '%Y/%m/%d %H:%M:%S')
        time_dect = {
            "weeks": weeks_value,
            "days": days_value,
            "hours": hours_value,
            "minutes": minutes_value,
            "seconds": seconds_value,
        }
        billtime = billtime + datetime.timedelta(**time_dect)
        billtime = datetime.datetime.strftime(billtime, '%Y%m%d%H%M%S')
        return billtime

    @staticmethod
    @keyword
    def hex2ascii(s):
        """hex string转ascii string

        用于传统POS处理数据内容，自动化用例有用到
        """
        return binascii.a2b_hex(s).decode()

    @staticmethod
    @keyword
    def ascii2hex(s):
        """
        ascii string转hex string

        用于传统POS处理数据内容
        """
        b = s.encode()
        return binascii.b2a_hex(b).decode()

    @staticmethod
    @keyword
    def get_seq_number(num):
        """6位流水号/批次号

        - num: int
        - return: 流水号/批次号，共6位，不足左边补0
        """
        return str(num).zfill(6)

    @staticmethod
    @keyword
    def get_amount_number(amount):
        """12位金额

        - amount: 金额，单位：元
        - return: 返回标准化的金额，共12位，不足左边补0
        """
        l = len(str(amount).split("")[1]) if "." in str(amount) else 0
        if l in [0, 1, 2]:
            return str(int(float(amount) * 100)).zfill(12)
        elif l == 3:
            # 外币，三位小数
            return str(int(float(amount) * 100) * 10).zfill(12)
        else:
            return str(0).zfill(12)

    @staticmethod
    @keyword
    def get_hex(length):
        """生成随机位数的hex string

        - length: 需要生成的长度，不能超过uuid的长度
        - return: 指定长度的hex string
        """
        return str(uuid.uuid4()).replace("-", "")[:length]

    @staticmethod
    @keyword
    def hex2bin(s):
        """hex string转binary string

        - s: hex string
        - return: binary string
        """
        return bin(int(s, 16))

    @staticmethod
    @keyword
    def is_during(start_time, end_time, time_format="%Y%m%d%H%M%S"):
        if not start_time or not end_time:
            return False
        start = datetime.datetime.strptime(start_time, time_format)
        end = datetime.datetime.strptime(end_time, time_format)
        now = datetime.datetime.now()
        if start < now < end:
            return True
        return False

    @staticmethod
    @keyword
    def convert_date_util(date, result_format='timestamp', exclude_millis=False, date_format=None):
        """用法同 DateTime.convert_date

        Converts between supported `date formats`.

        Arguments:
        - ``date:``           Date in one of the supported `date formats`.
        - ``result_format:``  Format of the returned date.
        - ``exclude_millis:`` When set to any true value, rounds and drops
                            milliseconds as explained in `millisecond handling`.
        - ``date_format:``    Specifies possible `custom timestamp` format.

        Examples:
        | ${date} =       | Convert Date Util | 20140528 12:05:03.111   |
        | Should Be Equal | ${date}      | 2014-05-28 12:05:03.111 |
        | ${date} =       | Convert Date Util | ${date}                 | epoch |
        | Should Be Equal | ${date}      | ${1401267903.111}       |
        | ${date} =       | Convert Date Util | ${date}                 | int_epoch |
        | Should Be Equal | ${date}      | ${1401267903}       |
        | ${date} =       | Convert Date Util | 5.28.2014 12:05         | exclude_millis=yes | date_format=%m.%d.%Y %H:%M |
        | Should Be Equal | ${date}      | 2014-05-28 12:05:00     |
        """
        if result_format == 'int_epoch':
            return int(
                convert_date(date, result_format='epoch', exclude_millis=exclude_millis, date_format=date_format)
            )
        return convert_date(date, result_format=result_format, exclude_millis=exclude_millis, date_format=date_format)

    @staticmethod
    @keyword
    def show_qrcode(data: str):
        """用于打印二维码, 便于扫码链接直接在测试报告中展示"""
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=1,
        )
        qr.add_data(data)
        f = io.StringIO()
        qr.print_ascii(out=f)
        f.seek(0)
        log.info(f'<p class="qrcode" style="font-family: Courier">{f.read()}<p>', html=True)

    @staticmethod
    @keyword
    def get_random_string(length: Union[str, int]):
        """生成随机字符串"""
        characters = string.ascii_letters + string.digits
        random_string = ''.join(random.choice(characters) for _ in range(int(length)))
        return random_string

    @staticmethod
    @keyword
    def get_random_num(length: Union[str, int]):
        """生成随机位数的数字"""
        if int(length) <= 1:
            raise ValueError('length must be greater than 1')
        return random.randint(10 ** (int(length) - 1), 10 ** int(length) - 1)

    @staticmethod
    @keyword
    def format_dict_to_json(data):
        """字典类型的转换为json类型，且去除空格
        {'ret_code': '00', 'ret_msg': '更新成功', 'order_id': '421110629385507844915245'} => {"ret_code":"00","ret_msg":"更新成功","order_id":"421110629385507844915245"}
        """
        if isinstance(data, dict):
            json_string = json.dumps(data, ensure_ascii=False)
            return json_string.replace('": ', '":').replace(', ', ',')
        else:
            raise Exception('传入的内容不是字典格式')
