import decimal
import hashlib
import json
import os
import re
import tempfile
import time
import traceback
import zipfile
from json import JSONDecodeError
from typing import List, Union

import jsonpath
import requests
import xlrd2
from boltons.iterutils import remap
from robot.api.deco import keyword
from ruamel.yaml import YAML

from . import log
from .java.fastjson import JSONObjectEncoder
from .UtilsLibrary import UtilsLibrary

yaml = YAML(typ="safe")
utils = UtilsLibrary


class UtilsMsg:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @staticmethod
    @keyword
    def os_path_file(filekeyname, dir_name):
        """通过路径读取文件

        - filekeyname: 文件名
        - dir_name: 文件夹名

        """

        # 获取privateKey存放路径；
        # 获取filekeyname文件路径内容信息
        path = os.path.dirname(os.path.realpath(__file__))
        # path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = path + "\\" + dir_name
        doc = os.path.join(path, filekeyname)
        print(UtilsLibrary.time_strft(), "文件路径:", doc)
        with open(doc) as pk:
            key_data = pk.read()
        return key_data

    @staticmethod
    @keyword
    def os_path_output_yaml(filekeyname):
        """获取文件信息，把yaml文件转为dict格式

        - filekeyname: yaml格式的文件的文件名

        """
        path = os.path.dirname(os.path.realpath(__file__))
        # path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = path + "\\yaml"
        doc = os.path.join(path, filekeyname)
        print(UtilsLibrary.time_strft(), "文件路径:", doc)
        with open(doc, mode="r", encoding="utf-8") as file:
            data = yaml.load(file)
        return data

    @staticmethod
    @keyword
    def os_path_input_yaml(filekeyname, src_data):
        """把字典格式信息，生成为文件

        - filekeyname: 目标生成文件的文件名
        - src_data: 字典格式信息的源数据

        """
        #
        path = os.path.dirname(os.path.realpath(__file__))
        # path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        # path = path + "\yaml"
        # 兼容转义的情况
        path = path.replace("\\", "\\\\")
        doc = os.path.join(path, filekeyname)
        print(UtilsLibrary.time_strft(), "文件路径:", doc)
        with open(doc, mode="w", encoding="utf-8") as file:
            data = yaml.dump(src_data, file)
        return data

    @staticmethod
    @keyword
    def os_file_remove(filekeyname):
        """删除目标文件名的文件

        - filekeyname: 目标删除文件的文件名
        """
        os.remove(filekeyname)

    @staticmethod
    @keyword
    def msg_removeblank_sort(msg):
        """json消息体移除空格并排序

        该方法完成功能：
        1.对json消息体中key对应的值含有为空情况下，进行删除操作；
        2.对json消息体进行排序
        3.对json消息体中key与value中空格，进行删除操作

        - msg: json消息体

        """
        for key in list(msg.keys()):
            # msg[key]获取值，当为str的情况，并且为空的情况，则考虑对值进行删除，非str则不处理
            if isinstance(msg[key], str):
                if not msg[key].strip():
                    del msg[key]  # 改回原来的样子，这个msg指向self.req_msg，同时删除了请求内容中的值为空字符串的key
        # 删除对应sign以及signdata相关签名，不参与加密的数据
        msg = UtilsMsg.msg_del_sign(msg)

        # 设置中文不进行ascii格式转换,并进行排序
        msg_ascii = UtilsMsg.msg_dict_ensure_ascii_sort(msg)
        # print Utils.time_strft(),"msg_ascii：", type(msg_ascii), msg_ascii

        # 对str消息体进行空格删除操作；先替换，号后的空格，再替换：号后的空格
        msg_r_b = UtilsMsg.msg_replace_blank(str(msg_ascii), ", ", ",")

        msg_r_b = UtilsMsg.msg_replace_blank(msg_r_b, ": ", ":")
        return msg_r_b

    @staticmethod
    @keyword
    def msg_dict_ensure_ascii_sort(msg):
        """设置dict格式内容，中文不进行ascii格式转换,并进行排序

        - msg: 需要转化的json消息体

        """
        #
        return json.dumps(msg, ensure_ascii=False, sort_keys=True)

    # def msg_dict_ascii_sort(msg):
    #     # 设置dict格式内容，中文不进行ascii格式转换,并进行排序
    #     return json.dumps(msg, ensure_ascii=False, sort_keys=True)

    @staticmethod
    @keyword
    def msg_replace_blank(msg, old, new):
        """替换json消息体中的空格

        - msg: 替换前原json消息体
        - old: 即将被替代的字符串，一般为" "
        - new: 替换后的字符串，一般为""

        """
        return msg.replace(
            old,
            new,
        )

    @staticmethod
    @keyword
    def msg_remove_blank(msg):
        """对json消息体中key与value中空格，进行删除操作

        - msg: 原json消息体

        """
        return json.dumps(msg, separators=(",", ":"))

    @staticmethod
    @keyword
    def para_replace_list_add_key(matchers):
        """对传入参数直接添加，不进行比对操作

        - matchers: 传入的参数字典
        - return: 形成好的字典列表形式，结构为[{"name":"k1", "value":"v1"}, {"name":"k2", "value":"v2"}]等等
        """
        try:
            z = []
            for i in matchers:
                y = {}
                l_value = []
                y["name"] = i
                l_value.append(matchers[i])
                y["value"] = l_value
                z.append(y)
            return z
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("The para_replace_list_add_key method handles exceptions!", e.args)

    @staticmethod
    @keyword
    def para_replace_add_key(msg, data):
        """传入data消息，如果key不存在的情况下，则进行添加key至原始报文中

        - msg: 被取代内容的json对象
        - data：保存取代内容的目标键值对-

        """

        try:
            datas = data.keys()
            for i in datas:
                msg[i] = data[i]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("The para_replace_add_key method handles exceptions!", e.args)
        return msg

    @staticmethod
    @keyword
    def para_replace(msg, data):
        """
        对body消息体参数进行替换操作（支持根节点及内部多个节点的替换）

        - msg: body消息体参数
        - data: 目标替换后的参数
        """
        try:
            for key, value in data.items():
                try:
                    keys_list = key.split('.')
                    current_dict = msg
                    last_index = len(keys_list) - 1
                    for index, step in enumerate(keys_list):
                        if step == '$':
                            continue
                        elif '[' in step and step[-1] == ']':
                            step_index = step.index('[')
                            current_dict = UtilsMsg.jsonpath_replace(current_dict, step[:step_index], value)
                            current_dict = UtilsMsg.jsonpath_replace(
                                current_dict, step[step_index + 1: -1], value, is_list=True, is_last=(last_index == index)
                            )
                        elif step == '':
                            current_dict = UtilsMsg.jsonpath_replace(current_dict, step, value, is_last=(last_index == index))
                        else:
                            current_dict = UtilsMsg.jsonpath_replace(current_dict, step, value, is_last=(last_index == index))
                except AttributeError:
                    msg[key] = value
            if isinstance(msg, dict):
                return msg
            else:
                return json.dumps(msg, ensure_ascii=False)
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("The para_replace method handles exceptions!", str(e))

    @staticmethod
    def _has_default_replace_flag(dict, key, flag="y"):
        if key in dict and dict[key] and isinstance(dict[key], str) and dict[key].lower() == flag:
            return True
        else:
            return False

    @staticmethod
    @keyword
    def msg_default_para_replace(msg: dict) -> dict:
        """json消息体的默认参数替换

        - msg: json消息体

        """
        # 异常参数测试，None的时候，不要替换
        if UtilsMsg._has_default_replace_flag(msg, "order_id"):
            query_order_id = UtilsLibrary.get_order_id(msg["busi_type"], msg["busi_sub_type"])
            msg["order_id"] = query_order_id
            if "log_id" in msg:
                msg["log_id"] = query_order_id
            if "event_id" in msg:
                msg["event_id"] = query_order_id
        if UtilsMsg._has_default_replace_flag(msg, "out_order_id"):
            msg["out_order_id"] = UtilsLibrary.trans_time_not_space_random()
        if UtilsMsg._has_default_replace_flag(msg, "transTime"):
            msg["transTime"] = UtilsLibrary.get_trans_time()
        if UtilsMsg._has_default_replace_flag(msg, "trans_time"):
            msg["trans_time"] = UtilsLibrary.get_trans_time()
        if UtilsMsg._has_default_replace_flag(msg, "accounting_date"):
            msg["accounting_date"] = UtilsLibrary.get_date_YYYYMMDD()
        if UtilsMsg._has_default_replace_flag(msg, "client_ip"):
            msg["client_ip"] = UtilsLibrary.get_remote_ip()
        if UtilsMsg._has_default_replace_flag(msg, "localtion"):
            msg["localtion"] = UtilsLibrary.get_remote_ip()
        if UtilsMsg._has_default_replace_flag(msg, "ip"):
            msg["ip"] = UtilsLibrary.get_remote_ip()
        if UtilsMsg._has_default_replace_flag(msg, "source"):
            msg["source"] = UtilsLibrary.get_date_YYYYMMDD()
        if UtilsMsg._has_default_replace_flag(msg, "nonce_str"):
            msg["nonce_str"] = UtilsLibrary.get_nonce()
        if UtilsMsg._has_default_replace_flag(msg, "nonce"):
            msg["nonce"] = UtilsLibrary.get_nonce()
        if UtilsMsg._has_default_replace_flag(msg, "version"):
            msg["version"] = UtilsLibrary.format_beijing_time_to_timestamp()
        if UtilsMsg._has_default_replace_flag(msg, "timestamp"):
            msg["timestamp"] = str(time.time_ns())[:13]
        if msg.get("timestamp") and isinstance(msg.get("timestamp"), str):
            matchs = re.fullmatch(r'\$\{([\s\S]*)\}', msg["timestamp"])
            if matchs:
                msg["timestamp"] = UtilsLibrary.get_date_time(matchs.group(1))
        return msg

    @staticmethod
    @keyword
    def replace_dict_keyvalue(msg, key, value):
        """替换字典中的参数

        - msg: 目标字典
        - key: 目标替换键
        - value: 目标键对应的新值

        """
        if isinstance(msg, dict):
            if key in msg:
                msg[key] = value
            else:
                raise Exception("%s 该子节点不存在！" % key)
        log.debug("replace_dict_keyvalue", msg)
        return msg

    @staticmethod
    @keyword
    def para_replace_all(msg, **data):
        """对body消息体参数进行替换操作

        需实现2个部分：根节点与多个节点替换
        当前只实现根节点参数替换

        - msg: body消息体参数
        - data: 根节点的参数替换

        """

        datas = data.keys()
        #     print "datas", datas
        for i in datas:
            if i in msg:
                msg[i] = data[i]
            else:
                # 获取多个节点情况，需遍历的数据集，list
                msg_data_list = i.split(".")
                msg_data_value = data[i]
                # print "msg_data_value", type(msg_data_value), msg_data_value
                # 获取dict格式数据,获取根节点数据
                node_msg = msg[msg_data_list[0]]
                # print "node_msg",type(node_msg),node_msg
                # 获取需要替换的节点
                msg_data_node = msg_data_list[1]
                # print "msg_data_node",type(msg_data_node),msg_data_node
                # 循环获取跟节点对应的值
                node_msg = UtilsMsg.para_node_msg(node_msg, msg_data_node, msg_data_value)
                # 对list返回的数据进行替换
                msg[msg_data_list[0]] = node_msg
        #     print "msg-------------------", msg
        return msg

    @staticmethod
    @keyword
    def para_node_msg(node_msg, node, value):
        """对多长节点处理"""
        # 获取list长度
        node_tree_msg_len = len(node_msg)
        #
        if "[" in node or "]" in node:
            node_name = node[:-3]
            node_number = int("".join([node[len(node) - 2: -1]]))
            node_msg[node_number][node_name] = value
        elif isinstance(value, dict):
            node = str(node)
            node_msg[node] = json.dumps(value)
            print("node_msg", node_msg)
        else:
            # node = str(node)
            # value = str(value)
            # print "node_msg", type(node_msg), node_msg
            # print "node", type(node), node
            # print "value", type(value), value
            if isinstance(value, str) or isinstance(value, str):
                node_msg[node] = value
            else:
                for i in node_msg:
                    print("i", type(i), i)
                    if node in i:
                        node_msg[0][node] = value
            print(UtilsLibrary.time_strft(), "node_msg", node_msg)

        return node_msg

    @staticmethod
    @keyword
    def exist_compare(old_msg, data):
        """data在响应体中，字段是否存在

        - old_msg: 响应体参数
        - data: 验证是否存在的字段

        """
        try:
            old_msg = UtilsMsg.str_to_dict(old_msg)
            if data not in old_msg:
                raise AssertionError("Key does not exist!", data)
        except Exception as err:
            raise err

    @staticmethod
    @keyword
    def exists_compare(old_msg, data):
        """data在响应体中，判断字符串列表中字段是否都存在

        - old_msg: 响应体参数
        - data: 验证是否存在的字段的列表

        """

        try:
            old_msg = UtilsMsg.str_to_dict(old_msg)
            data = UtilsMsg.str_to_dict(data)
            for i in data:
                if i not in old_msg:
                    raise AssertionError("Key does not exist!", data)
        except Exception as err:
            raise err

    @staticmethod
    @keyword
    def get_resp_list_to_dict_data(data, para):
        """data 传入参数为list对象；para参数传参根据key=value方式传参；
        -  data: 返回dict对象
        """
        try:
            if type(data) == list:
                if len(data) >= 1:
                    for i in data:
                        key, value = para.split("=")[0], para.split("=")[1]
                        msg_keys = i.keys()
                        if key in msg_keys:
                            if i[key] == value:
                                return i
                else:
                    raise AssertionError(f"{data}长度小于0！")
            else:
                raise AssertionError(f"{data}传入参数非list类型！")
        except Exception as err:
            raise RuntimeError(f"{data},{para} 关键字入参有误！")

    @staticmethod
    @keyword
    def str_to_dict(msg: Union[str, dict]) -> dict:
        """将str类型数据转字典格式

        - msg: str类型数据

        """
        try:
            if isinstance(msg, str):
                return json.loads(msg.replace("\n", ""))
            return msg
        except JSONDecodeError as e:
            if isinstance(eval(msg), list):
                return eval(msg)
            else:
                log.warn(traceback.format_exc())
                raise RuntimeError(f"{msg} 不是一个JSON字符串: {str(e)}")

    @staticmethod
    @keyword
    def unicode_str_to_int(msg):
        """将str类型数据转为int

        - msg: unicode编码的数字字符串

        """
        try:
            msg = int(msg)
            return msg
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("The message is not in int format,Handle exceptions!", e.args)

    @staticmethod
    @keyword
    def byte_to_dict(data):
        """对byte信息转换为dict格式

        - data: byte类型的信息数据

        """

        data_str = data.decode()
        res_data = UtilsMsg.str_to_dict(data_str)
        return res_data

    @staticmethod
    @keyword
    def exist_compare_notexist(old_msg, data):
        """字典格式比较

        判断data形成的字典是否是old_msg的子集

        - old_msg: 验证子集的大字典
        - data: 字典形式的字符串

        """

        old_msg = UtilsMsg.str_to_dict(old_msg)
        if data in old_msg:
            raise AssertionError("Key does exist!", old_msg, data)

    @staticmethod
    @keyword
    def dict_compare(old_msg, data):
        """JSON String比较

        - msg: 字典格式的字符串
        - data: 判断是否等同的字典类型字符串

        """
        # 传入参数old_msg，str类型转dict格式
        if isinstance(old_msg, str):
            old_msg = UtilsMsg.str_to_dict(old_msg)
        if isinstance(data, str):
            data = UtilsMsg.str_to_dict(data)

        try:
            for key, expect_value in data.items():
                value = UtilsMsg.get_dict_value(old_msg, key)
                UtilsMsg.str_compare(value, expect_value)
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("dict_compare exception!", str(e))

    @staticmethod
    @keyword
    def dict_list_compare(old_msg, data):
        """JSON String比较
        - msg: 字典格式的字符串
        - data: 判断是否等同的字典类型字符串
        """
        # if isinstance(old_msg, list):
        #     old_msg = ''.join(str(item) for item in old_msg)
        if isinstance(data, str):
            data = json.loads(data)
        try:
            num = 0
            for i in old_msg:
                if i == data:
                    num = 1
            if num != 1:
                raise AssertionError("ERROR：Field value not equal! %s != %s" % (old_msg, data))
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("dict_compare exception!", str(e))



    @staticmethod
    @keyword
    def sub_dict_in_all_dict(sub_dict, all_dict):
        """判断大字典中是否包含子字典，键和值都会进行比较"""
        if isinstance(sub_dict, str):
            sub_dict = eval(sub_dict)
        if isinstance(all_dict, str):
            all_dict = eval(all_dict)
        contains = all(item in all_dict.items() for item in sub_dict.items())
        if not contains:
            raise Exception('dict_compare exception!')

    @staticmethod
    @keyword
    def sub_list_in_all_list(sub_list, all_list):
        """判断大列表中是否包含子列表"""
        if isinstance(sub_list, str):
            sub_list = eval(sub_list)
        if isinstance(all_list, str):
            all_list = eval(all_list)
        for item in sub_list:
            if item not in all_list:
                raise Exception(f'{item}在大列表中不存在')

    @staticmethod
    @keyword
    def str_in_compare(old, new):
        """
        old 与 new字段进行比较，如不一致，直接执行失败，并报异常。

        对传入数据，比对类型前置转为一致，均转为str；

        - old: old字段
        - new: new字段

        """
        if str(new) not in str(old):
            raise AssertionError("ERROR：Field value not equal! %s != %s" % (old, new))

    @staticmethod
    @keyword
    def str_compare(old, new):
        """字符串比较

        old 与 new字段进行比较，如不一致，直接执行失败，并报异常。

        - old: old字段
        - new: new字段

        """
        # # 对传入数据，比对类型前置转为一致；
        if str(old) != str(new):
            raise AssertionError("ERROR：Field value not equal! %s != %s" % (old, new))

    @staticmethod
    @keyword
    def db_list_compare(str, *data):
        """db数据list进行比较

        - str: query_str，请求字符串
        - data: 用于比较的数组数据

        """
        # 判断query_str 与 *data入参长度需保持一致；
        if len(str) == len(data):
            # 按下标进行数据比对
            for i in range(len(str)):
                UtilsMsg.str_compare(str[i], data[i])

    @staticmethod
    @keyword
    def db_check_compare(query_str, *data):
        """比较入参list数据

        入参：2个list数据，对入参list数据进行比较；

        - query_str: 第一个list数据
        - data: 第二个list数据

        """

        if isinstance(query_str, list):
            # 传入参数只对一个list进行校验，查询结果为多个list或者为空，则认为返回数据存在问题；
            if len(query_str) == 1:
                # 存在list与dict状态
                # 获取当前第1个节点的list或者dict,dict不进行处理；
                str0 = query_str[0]
                if isinstance(str0, list):
                    UtilsMsg.db_list_compare(str0, *data)
                elif isinstance(str0, dict):
                    raise AssertionError("ERROR：db_query_exist_compare 请使用db_query_exist_dict_compare方法进行比对！")
                else:
                    if isinstance(str0, tuple):
                        data = list(data)[0]
                        UtilsMsg.str_compare(str0, data)
                    else:
                        raise AssertionError("ERROR：db_check_compare 请使用db_check_compare方法进行比对！")
            else:
                raise AssertionError("ERROR：db_query_exist_compare 数据比对，返回数据大于1个list或者返回数据为空！")
        # 对tuple进行处理。
        elif isinstance(query_str, tuple):
            UtilsMsg.db_list_compare(query_str, *data)
        else:
            raise AssertionError("ERROR：其它类型，处理失败！")

    @staticmethod
    @keyword
    def get_org_str(request: dict, sign_fields: str):
        """mng switch取某些加签字段

        - request: 请求体字典
        - sign_fields: xxx,xxx
        - return: 加签后字段
        """
        sign_field_list = sign_fields.split(",")
        org_str = ""
        try:
            for field in sign_field_list:
                keys = field.split(".")
                depth = len(field.split("."))
                preffix = keys[0]
                if depth > 1:
                    suffix = keys[1]
                    obj = request.get(preffix)
                    if isinstance(obj, list):
                        for o in obj:
                            value = o.get(suffix)
                            org_str += str(value)
                else:
                    value = request.get(preffix)
                    if not value:
                        continue
                    org_str += str(value)
            log.info("待加签org_str:", org_str)
        except Exception as e:
            log.error(e)
        return org_str

    @staticmethod
    @keyword
    def get_sign_str(request: dict, sign_fields: str, app_aes_key: str):
        sign_field_list = sign_fields.split(",")
        for field in sign_field_list:
            value = request.get(field)
            if value is not None:
                app_aes_key += str(value)
        return app_aes_key

    @staticmethod
    @keyword
    def manage_dj_sort_dict(req_msg, *data_sign):
        """鼎嘉manage str类型处理

        把对应value，存放至字典中

        - req_msg: 请求的信息字典
        - data_sign: 数据签名字段

        """
        sign_values = []
        for i in data_sign:
            if i in list(req_msg.keys()):
                sign_values.append(req_msg[i])
                sign_values.append("&")
            else:
                # 获取多个节点情况，需遍历的数据集，list
                msg_data_list = i.split(".")
                # 只处理第一个节点
                nodetree = req_msg[msg_data_list[0]]
                nodetree_value = nodetree[0]
                print("nodetree_value", type(nodetree_value), nodetree_value)
                if msg_data_list[1] in nodetree_value:
                    sign_values.append(nodetree_value[msg_data_list[1]])
                    # print "nodetree_value[msg_data_list[1]]", nodetree_value[msg_data_list[1]]
                else:
                    raise AssertionError("ERROR：子节点不存在，处理失败!")
                sign_values.append("&")
        sign_values = sign_values[:-1]
        return sign_values

    @staticmethod
    @keyword
    def sign_field_compare(req_msg, sign_data):
        """对含有多个原消息体中含有签名字段进行替换

        - req_msg: 原先的消息请求体信息
        - sign_data: 用于替换的签名字段

        """

        if "sign" in req_msg:
            req_msg["sign"] = sign_data
        elif "signData" in req_msg:
            req_msg["signData"] = sign_data
        elif "sign_data" in req_msg:
            req_msg["sign_data"] = sign_data
        elif "sign_info" in req_msg:
            sign_info = req_msg["sign_info"]
            if "sign_result" in sign_info:
                sign_info["sign_result"] = sign_data
                req_msg["sign_info"] = sign_info
        return req_msg

    @staticmethod
    @keyword
    def splitaccount_sort(req_msg):
        """dict格式，转化为str类型并排序

        将非签名非空字段转化为key1=value1&key2=value2&...的形式的字符串

        - req_msg: dict类型

        """
        req_values = ""
        keys = sorted(req_msg.keys())
        for i in keys:
            if i != "sign_data" or i != "sign" or i != "signData":
                if str(req_msg[i]) != "":
                    req_values = str(req_values) + i + "=" + str(req_msg[i]) + "&"
                    # print "vaules----------",req_values
        req_values = req_values[:-1]
        # print "values",req_values
        return req_values

    @staticmethod
    @keyword
    def trans_splitaccount_sort(req_msg):
        """splitaccount，dict格式，转化为str类型，交易排序规则

        将非签名非空字段转化为key1=value1&key2=value2&...的形式的字符串

        - req_msg: dict类型

        """
        req_values = ""
        keys = sorted(req_msg.keys())
        for i in keys:
            if i != "sign_data" or i != "sign" or i != "signData":
                if str(req_msg[i]) != "":
                    # req_values = str(req_values) + i + "=" + str(req_msg[i]) + "&"
                    req_values = str(req_values) + str(req_msg[i]) + "&"
                    # print "vaules----------",req_values
        req_values = req_values[:-1]
        log.info("签名前内容:", req_values)
        return req_values

    @staticmethod
    @keyword
    def trans_splitaccount_sort_new(req_msg, req_values=''):
        """splitaccount，dict格式，转化为str类型，交易排序规则

        将非签名非空字段转化为key1=value1&key2=value2&...的形式的字符串

        - req_msg: dict类型

        """
        keys = sorted(req_msg.keys())
        for i in keys:
            if isinstance(req_msg[i], str) and i in ['agentId', 'deviceSn', 'signMethod']:
                req_values = str(req_values) + str(req_msg[i])
            elif isinstance(req_msg[i], list):
                for dic in req_msg[i]:
                    dic_keys = ['feeCalcType', 'fixed', 'rate', 'fee_flag', 'message_fee_package_id']
                    for i in dic_keys:
                        if i in dic.keys() and isinstance(dic[i], str):
                            req_values = str(req_values) + str(dic[i])
        req_values = req_values
        log.info("签名前内容:", req_values)
        return req_values

    @staticmethod
    @keyword
    def resp_sign_data(msg):
        """传入报文中获取签名字段对应的签名信息

        - msg: 带有签名信息的报文

        """

        msg = UtilsMsg.str_to_dict(msg)
        if "sign" in msg:
            return str(msg["sign"])
        if "signdata" in msg:
            return str(msg["signdata"])
        if "signature" in msg:
            return str(msg["signature"])

    @staticmethod
    @keyword
    def msg_del_sign(msg):
        """删除签名字段

        - msg: 带有签名字段的报文

        """

        if "sign" in msg:
            del msg["sign"]
        if "signdata" in msg:
            del msg["signdata"]
        if "signature" in msg:
            del msg["signature"]
        return msg

    @staticmethod
    @keyword
    def accp_account_sign_str(req_msg: dict):
        """签名字段：
        accp_account服务：使用merch_no|amount|order_id|trans_time字段进行签名
        accp-transfer服务：order_id，out_merch_no，amount，source，及各个in_merch_no拼结而成，以“|”分开

        - req_msg: 带有签名字段的字典
        """
        if 'out_merch_no' in req_msg:
            fields = ['order_id', 'out_merch_no', 'amount', 'source']
            fields_merchno = ['in_merch_no']
            value_list = [req_msg.get(key, "") for key in fields]
            print(value_list)
            for transfer_details in req_msg['transfer_details']:
                value_list.append(transfer_details['in_merch_no'])
            value_list = list(map(str, value_list))

        else:
            fields = ["merch_no", "amount", "order_id", "trans_time"]
            value_list = [req_msg.get(key, "") for key in fields]
        sign_str = "|".join(value_list)
        return sign_str

    @staticmethod
    @keyword
    def msg_return_value(req_msg, key):
        """取出req_msg字典中，key对应的value值

        - req_msg: 字典
        - key: 目标键

        """
        if key in req_msg:
            return req_msg[key]

    @staticmethod
    @keyword
    def str_append(msg, exists_str, append_str):
        """判断字段不存在的情况下，str数据进行追加

        - msg: 可能被追加的信息字符串
        - exist_str: 判断字段
        - append_str: 用于追加的字符串

        """
        if str(exists_str) != str(append_str):
            msg = msg + str(append_str)
        return msg

    @staticmethod
    @keyword
    def para_replace_mock(msg, **data):
        """对body消息体参数进行替换操作

        需实现2个部分：根节点与多个节点替换
        当前只实现根节点参数替换

        - msg: body消息体参数
        - data: 用于替换的节点参数

        """
        msg = UtilsMsg.str_to_dict(msg)
        datas = data.keys()
        for i in datas:
            if i in msg:
                msg[i] = data[i]
        return msg

    @staticmethod
    @keyword
    def utils_script_replace_File(sqlScriptFileName, **data):
        """批量发起文件上传，需要对文件关键字段进行替换操作

        该方法使用是针对SQL处理，只对字段进行替换操作；
        不支持随机生成

        - sqlScriptFileName: sql脚本的文件名
        - data: 参数字典

        """
        try:
            file_data = ""
            path = UtilsLibrary.os_path(sqlScriptFileName)
            sqlScriptFile = open(path)

            # 对文件关键字段进行替换操作
            for line in sqlScriptFile:
                # 循环替换参数
                for i in data:
                    file_data += line.replace(i, data[i])
            print(file_data)

            # 对文件进行写入操作
            trans_time = UtilsLibrary.trans_time_not_space()
            replace_file = path + "_" + trans_time
            fw = open(replace_file, "w+")
            fw.write(file_data)

            return replace_file

        except Exception as err:
            log.error("关键参数替换文件失败！")
            raise err

    @staticmethod
    @keyword
    def utils_delete_file(filepath):
        """删除文件

        - filepath: 文件路径

        """
        try:
            os.remove(filepath)
            log.info("删除文件成功!，删除路径：", filepath)
        except Exception as err:
            log.info("删除文件失败!，删除路径：", filepath)
            raise err

    @staticmethod
    @keyword
    def utils_unicode_to_encode(str):
        """获取当前对象，并转为dict格式

        - str: 字典形式的字符串

        """
        dict_msg = UtilsMsg.str_to_dict(str)
        # 获取所有的key，如果是unicode类型，则需要转换为中文
        dict_keys = dict_msg.keys()
        print(dict_keys)
        for i in dict_keys:
            if isinstance(dict_msg[i], str):
                # msg[i] = data[i].encode("utf-8")
                print(i, dict_msg[i].decode("unicode_escape"))

    @staticmethod
    @keyword
    @utils._method_logging
    def key_value_convert_json(key_value):
        """
        将key1=value1&key2=value2 转换成字典对象 {"key1":"value1","key2":"value2"}

        用于传统POS响应，48域ASCII转码后，转换成字典对象，便于断言

        - key_value: key=value的字符串对象
        """
        d = {}
        for item in key_value.split("&"):
            match = re.match(r"(\w+)=(\S+)", item)
            if match:
                k, v = match.groups()
                d[k] = v
        return d

    @staticmethod
    @keyword
    def json_path_assert(json_string, equal_expression, not_equal_expression="{}"):
        """JSON字符串比较，有应该相等的，也有不应该相等的。

        如果json_string中有与equal_expression不相等的字段，那么会报出异常
        如果json_string中有与not_equal_expression相等的字段，那么也会报出异常

        - json_string: json字符串
        - equal_expression: json字符串中应该相等的对象数据
        - not_equal_expression: json字符串中不应该相等的对象数据

        - return: None
        """
        if isinstance(json_string, str):
            json_obj = UtilsMsg.str_to_dict(json_string)
        else:
            json_obj = json_string
        if isinstance(equal_expression, str):
            equal_obj = UtilsMsg.str_to_dict(equal_expression)
        else:
            equal_obj = equal_expression
        if isinstance(not_equal_expression, str):
            not_equal_obj = UtilsMsg.str_to_dict(not_equal_expression)
        else:
            not_equal_obj = not_equal_expression
        err_msgs = []
        for expr, value in equal_obj.items():
            real_value = jsonpath.jsonpath(json_obj, expr)
            real_value = real_value[0] if real_value else None
            if not real_value == value:
                err_msgs.append(f"AssertionError: {expr} => except: {value} => but: {real_value}")
        for expr, value in not_equal_obj.items():
            real_value = jsonpath.jsonpath(json_obj, expr)
            real_value = real_value[0] if real_value else None
            if real_value == value:
                err_msgs.append(f"AssertionError: {expr} => not except: {value} => but: {real_value}")
        if err_msgs:
            raise Exception(err_msgs)

    @staticmethod
    @keyword
    def name_convert_to_snake(name: str) -> str:
        """驼峰转下划线

        - name: 名称字符串

        """
        if "_" not in name:
            name = re.sub(r"([a-z])([A-Z])", r"\1_\2", name)
        else:
            raise ValueError(f"{name}字符中包含下划线，无法转换")
        return name.lower()

    @staticmethod
    @keyword
    def json_encode(dct: dict, sort_keys=False):
        """对字典进行编码

        - dct: 目标编码的字典
        - sort_keys: false和fastjson默认顺序对其，True则全排列
        """

        chunks = []
        for chunk in JSONObjectEncoder(ensure_ascii=False, sort_keys=sort_keys).iterencode(dct):
            chunks.append(chunk)
        if chunks[0] and chunks[0].startswith('"') and chunks[0].endswith('"'):
            chunks[0] = chunks[0][1:-1]
        value = "".join(chunks)
        return value

    @staticmethod
    @keyword
    def build_sign_str(data, sign_field="sign"):
        """银联分期码回调，银联二维码回调，旧外接码付

        将非签名非空字段转化为key1=value1&key2=value2&...的形式的字符串

        - data:待签名串
        - return: 转化后的字符串，key1=value1&key2=value2&...
        """
        req = []
        for key in sorted(data.keys()):
            if key == sign_field:
                continue
            if data[key] != "":
                if isinstance(data[key], dict):
                    # 第二层object，银联和callback服务都是用fastjson 1.2.70序列化，未指定顺序时，默认使用HashMap存储
                    # 这里参考Java HashMap，保证key顺序一致，从而保证待加签串一致
                    value = UtilsMsg.json_encode(data[key])
                    req.append("%s=%s" % (key, value))
                else:
                    req.append("%s=%s" % (key, data[key]))
        sign_str = "&".join(req)
        log.info("签名前内容:", sign_str)
        return sign_str

    @staticmethod
    @keyword
    def get_sign_context(
            data: dict,
            sign_field: str = "sign",
            hashmap_order: bool = True,
            ascii_key_sort: bool = True,
            all_sort: bool = False,
    ):
        """获取签名前内容
        <groupId>com.jlpay.common</groupId>
        <artifactId>framework-utils</artifactId>
        <version>1.0.6</version>

        - data: 带有签名内容的字段
        - sign_field: 数据字段中的签名对应的key
        - sort_json_string: hashmap_order=True  all_sort=False 和公共包对齐
        """
        sign_list = []
        if hashmap_order:
            drop_none = lambda path, key, value: value is not None
            new_data = remap(data, visit=drop_none)
            content = UtilsMsg.json_encode(new_data, sort_keys=all_sort)
            log.debug("hashmap.toString => ", content)
            data = json.loads(content)
        iter_keys = sorted(data.keys()) if ascii_key_sort else data.keys()
        if ',' in sign_field:
            sign_field_list = sign_field.split(',')
        else:
            sign_field_list = [sign_field]
        for key in iter_keys:
            if key in sign_field_list:
                continue
            if data[key] is not None:
                # 空串、0、空list,都保留
                if isinstance(data[key], str):
                    value = data[key]
                elif isinstance(data[key], list):
                    value = json.dumps(data[key], ensure_ascii=False, separators=(",", ":"))
                else:
                    value = json.dumps(data[key], ensure_ascii=False, separators=(",", ":"))
                sign_list.append(f"{key}={value}")
        sign_str = "&".join(sign_list)
        log.info("签名前内容:", sign_str)
        return sign_str

    @staticmethod
    @keyword
    def get_sign_context_md5(data, sign_field="sign"):
        """获取数据内的签名内容的MD5码

        - data: 数据字段
        - sign_field: 数据字段中的签名对应的key

        """

        sign_str = UtilsMsg.get_sign_context(data, sign_field)
        sign_str_md5 = hashlib.md5(sign_str.encode("utf-8")).hexdigest()
        log.info("签名前内容(MD5)为", sign_str_md5)
        return sign_str_md5

    @staticmethod
    @keyword
    def get_sign_context_sha256(data, sign_field="sign"):
        """获取数据内的签名内容的SHA256摘要

        - data: 数据字段
        - sign_field: 数据字段中的签名对应的key

        """

        sign_str = UtilsMsg.get_sign_context(data, sign_field)
        sign_str_sha256 = hashlib.sha256(sign_str.encode("utf-8")).hexdigest()
        log.info("签名前内容(SHA256)为", sign_str_sha256)
        return sign_str_sha256

    @staticmethod
    @keyword
    def get_sign_json(data: dict, sign_field="sign") -> str:
        """外接码付，将待加签报文按字典顺序排序,输出格式为json字符串

        - data: 待加签报文
        - sign_field: 排序后的字符串，已去除sign字段，去除空格
        """
        sign_json = {}
        for key in sorted(data.keys()):
            if key != sign_field:
                sign_json[key] = data[key]
        sign_str = json.dumps(sign_json, ensure_ascii=False, separators=(",", ":"))
        log.info("签名前内容:", sign_str)
        return sign_str

    @staticmethod
    @keyword
    def get_dict_value(msg, key: str):
        """从msg消息体中获取expr对应的value

        - msg: _description_
        - key: jsonpath表达式
        - raises RuntimeError: _description_
        - return: _description_
        """
        try:
            json_obj = UtilsMsg.str_to_dict(msg)
            if not (key.startswith(".") or key.startswith("$.")):
                key = "$." + key
            value = jsonpath.jsonpath(json_obj, key)
            if value is False:
                return None
            if value and len(value) == 1:
                return value[0]
            return value
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"获取键值失败: {str(e)}")

    # 传入一个元素为字典的列表以及value。返回value所在元素的下标
    @staticmethod
    @keyword
    def get_list_index(list, value):
        for i in range(len(list)):
            tmp_dict = list[i]
            report_id = UtilsMsg.get_dict_value(tmp_dict, "report_id")
            if report_id == value:
                return i

    @staticmethod
    @keyword
    def union_string(*data: str) -> str:
        """组装消息为 xxx|xxx|xxx格式

        - data: _description_
        - return: _description_
        """
        return "|".join([item if item != "None" else "" for item in data])

    @staticmethod
    @keyword
    def get_data_by_download_url(download_url, type, merch_no=""):
        """
        根据下载地址,获取下载内容
        - param download_url: zip文件的下载地址
        - param type: 类型 如是资金账单还是交易账单
        - return: 以json格式返回下载的内容
        """
        url = download_url
        response = requests.get(url)

        data = response.content  # data为byte字节

        _tmp_file = tempfile.TemporaryFile()  # 创建临时文件

        _tmp_file.write(data)  # byte字节数据写入临时文件

        zf = zipfile.ZipFile(_tmp_file, mode="r")

        tmp = tempfile.gettempdir()  # 获取系统的临时目录
        log.info("开始解压...")
        for names in zf.namelist():
            f = zf.extract(names, tmp + "/zip")  # 解压到zip目录文件下

        # 解决解压后文件名乱码问题
        for zip_file in zf.namelist():
            current_path = tmp + "/zip/"
            # 常见的有两种编码，使用异常处理语句
            try:
                new_zip_file = zip_file.encode("cp437").decode("utf-8")
                os.rename(current_path + zip_file, current_path + new_zip_file)
            except:
                new_zip_file = zip_file.encode("cp437").decode("gbk")
                os.rename(current_path + zip_file, current_path + new_zip_file)

        zf.close()
        log.info("解压成功，解压文件所在位置", current_path + new_zip_file)
        if type == "资金":
            return UtilsMsg.read_fund_excel_to_json(new_zip_file)
        elif type == "集团资金":
            return UtilsMsg.read_group_fund_excel_to_json(new_zip_file, merch_no)
        else:
            return UtilsMsg.read_trade_excel_to_json(new_zip_file)

    @staticmethod
    def read_fund_excel_to_json(path):
        """
        读取资金账单的excel
        - param path: excel文件所在位置
        - return: 返回读取到的数据
        """
        tmp = tempfile.gettempdir()  # 获取系统的临时目录
        current_path = tmp + "/zip/"
        log.info("开始解析excel文件...", current_path + path)
        # 打开excel表，填写路径
        book = xlrd2.open_workbook(current_path + path)
        # 找到sheet页
        table = book.sheet_by_name("账单明细")
        table_sum = book.sheet_by_name("商户对账单")
        # 获取总行数总列数
        row_num = table.nrows
        col_num = table.ncols

        table_dict = {}

        # 处理sheet商户对账单汇总数据
        for i in range(2, 5):
            for j in range(0, 8, 2):
                # 兼容列表占两格
                if j == 6:
                    j = 7
                tmp_values = table_sum.row_values(i)
                table_dict[tmp_values[j]] = tmp_values[j + 1]
                table_dict = {k: v.replace(" ", "") for k, v in table_dict.items()}
        data_list = []
        key = table.row_values(1)  # 这是第一行数据，作为字典的key值

        if row_num <= 1:
            print("没数据")
        else:
            for i in range(2, row_num):
                tmp_dict = {}
                values = table.row_values(i)
                for x in range(col_num):
                    # 把key值对应的value赋值给key，每行循环
                    tmp_dict[key[x]] = values[x]
                    tmp_dict = {k: v.replace(" ", "") for k, v in tmp_dict.items()}
                # 把字典加到列表中
                data_list.append(tmp_dict)
        table_dict["data"] = data_list
        print(table_dict)

        log.info("解析完毕")
        return table_dict

    @staticmethod
    def read_trade_excel_to_json(path):
        """
        读取交易账单的excel
        - param path: excel文件所在位置
        - return: 返回读取到的数据
        """
        tmp = tempfile.gettempdir()  # 获取系统的临时目录
        current_path = tmp + "/zip/"
        log.info("开始解析excel文件...", current_path + path)
        # 打开excel表，填写路径
        book = xlrd2.open_workbook(current_path + path)
        # 找到sheet页
        table = book.sheet_by_name("商户流水导出")
        # 获取总行数总列数
        row_Num = table.nrows
        col_Num = table.ncols

        table_dict = {}

        data_list = []
        key = table.row_values(0)  # 这是第一行数据，作为字典的key值

        if row_Num <= 1:
            print("没数据")
        else:
            for i in range(1, row_Num):
                tmp_dict = {}
                values = table.row_values(i)
                for x in range(col_Num):
                    # 把key值对应的value赋值给key，每行循环
                    tmp_dict[key[x]] = values[x]

                # 把字典加到列表中
                data_list.append(tmp_dict)
        table_dict["data"] = data_list

        log.info("解析完毕")

        return table_dict

    # 删除生成的excel文件
    @staticmethod
    @keyword
    def delete_excel(path):
        current_path = os.getcwd() + "/zip/"
        absolute_path = current_path + path
        if os.path.exists(absolute_path):  # 判断文件是否存在
            os.remove(absolute_path)  # 如果存在就将其删除

    @staticmethod
    @keyword
    def json_replace(ori_json: Union[str, dict], replace_datas: Union[str, dict]):
        """json替换
        - ori_json: 原字典，json字符串或 字典类型
        - replace_datas: 要替换的数据，json字符串或 字典类型

        - return: 原字典为json字符串，就返回替换后的json字符串；原字典为字典类型，就返回替换后的字典

        Examples:
        | ${result} | Json Replace | {"data":{"item":{"name":"Lily"}}} | {"data.item.name":"Jack"} |
        | ${result} | Json Replace | {"data":{"item":{"name":"Lily"}}} | {"data..name":"Jack"} |
        | ${result} | Json Replace | {"data":[{"item":{"name":"Lily","age":3}}, {"item":{"name":"Bob","age":14}}]} | {"data[1].item.name":"Jack"} |
        | ${result} | Json Replace | {"data":[{"item":{"name":"Lily","age":3}}, {"item":{"name":"Bob","age":14}}]} | {"data[*].item.name":"Jack"} |

        Results:
        | {"data": {"item": {"name": "Jack"}}} |
        | {"data": {"item": {"name": "Jack"}}} |
        | {"data": [{"item": {"name": "Lily", "age": 3}}, {"item": {"name": "Jack", "age": 14}}]} |
        | {"data": [{"item": {"name": "Jack", "age": 3}}, {"item": {"name": "Jack", "age": 14}}]} |
        """
        ori_dict = UtilsMsg.str_to_dict(ori_json)
        replace_dict = UtilsMsg.str_to_dict(replace_datas)
        for key, value in replace_dict.items():
            expr_list = key.split('.')
            cur_dict = ori_dict
            last_index = len(expr_list) - 1
            for index, step in enumerate(expr_list):
                if step == '$':
                    continue
                elif '[' in step and step[-1] == ']':
                    step_index = step.index('[')
                    cur_dict = UtilsMsg.jsonpath_replace(cur_dict, step[:step_index], value)
                    cur_dict = UtilsMsg.jsonpath_replace(
                        cur_dict, step[step_index + 1: -1], value, is_list=True, is_last=(last_index == index)
                    )
                elif step == '':
                    cur_dict = UtilsMsg.jsonpath_replace(cur_dict, step, value, is_last=(last_index == index))
                else:
                    cur_dict = UtilsMsg.jsonpath_replace(cur_dict, step, value, is_last=(last_index == index))
        if isinstance(ori_json, dict):
            return ori_dict
        else:
            return json.dumps(ori_dict, ensure_ascii=False)

    @staticmethod
    def jsonpath_replace(
            ori_dict: Union[dict, List[dict]], key: str, value: Union[str, int], is_list=False, is_last=False
    ):
        if is_list:
            if not isinstance(ori_dict, list):
                raise ValueError(f'{ori_dict} is not a list, cannot use "[{key}]" to get it')
            if key == '*':
                if is_last:
                    for index, dic in enumerate(ori_dict):
                        ori_dict[index] = value
                return [dic for dic in ori_dict]
            else:
                try:
                    index_key = int(key)
                    if is_last:
                        ori_dict[index_key] = value
                    result_dict = ori_dict[index_key]
                    return result_dict
                except ValueError as e:
                    e.args = (f'[{key}] should be like number or *',)
                    raise e
                except KeyError:
                    raise ValueError(f'{key} not found in {ori_dict}')
        else:
            if isinstance(ori_dict, list):
                result_list = []
                for dic in ori_dict:
                    try:
                        if is_last:
                            dic[key] = value
                        result_list.append(dic[key])
                    except KeyError:
                        raise ValueError(f'{key} not found in {dic}')
                return result_list
            else:
                try:
                    if is_last:
                        if key == '':
                            for sub_dict in ori_dict.values():
                                sub_dict[key] = value
                        ori_dict[key] = value
                    return [sub_dict for sub_dict in ori_dict.values()] if key == '' else ori_dict[key]
                except KeyError:
                    raise ValueError(f'{key} not found in {ori_dict}')

    @staticmethod
    def read_group_fund_excel_to_json(path, merch_no):
        """
        读取集团多日账单的excel
        - param path: excel文件所在位置
        - return: 返回读取到的数据
        """
        tmp = tempfile.gettempdir()  # 获取系统的临时目录
        current_path = tmp + "/zip/"
        log.info("开始解析excel文件...", current_path + path)
        # 打开excel表，填写路径
        book = xlrd2.open_workbook(current_path + path)
        # 找到sheet页
        table = book.sheet_by_name(merch_no)
        table_sum = book.sheet_by_name("集团对账单")
        # 获取总行数总列数
        row_num = table.nrows
        col_num = table.ncols

        table_dict = {}

        # 处理集团对账单sheet商户对账单汇总数据
        for i in range(2, 4):
            for j in range(1, 8, 2):
                # 兼容列表占两格
                if j == 1:
                    j = 0
                tmp_values = table_sum.row_values(i)
                table_dict[tmp_values[j]] = tmp_values[j + 1]
                table_dict = {k: v.replace(" ", "") for k, v in table_dict.items()}
        merch_list = []
        tmp_dict0 = {}
        values = table.row_values(7)
        key0 = table.row_values(6)  # 这是第一行数据，作为字典的key值
        for x in range(col_num):
            # 把key值对应的value赋值给key，每行循环
            tmp_dict0[key0[x]] = values[x]
            tmp_dict0 = {k: v.replace(" ", "") for k, v in tmp_dict0.items()}
        # 把字典加到列表中
        merch_list.append(tmp_dict0)
        table_dict["merch_data"] = merch_list

        group_list = []
        key = table.row_values(12)  # 这是第一行数据，作为字典的key值

        if row_num <= 12:
            print("没数据")
        else:
            for i in range(13, row_num):
                tmp_dict = {}
                values = table.row_values(i)
                for x in range(col_num):
                    # 把key值对应的value赋值给key，每行循环
                    tmp_dict[key[x]] = values[x]
                    tmp_dict = {k: v.replace(" ", "") for k, v in tmp_dict.items()}
                # 把字典加到列表中
                group_list.append(tmp_dict)
        table_dict["group_data"] = group_list
        print(table_dict)

        log.info("解析完毕")
        return table_dict
