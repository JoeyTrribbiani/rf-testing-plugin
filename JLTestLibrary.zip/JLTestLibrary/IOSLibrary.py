# import base64
# import time
# from functools import wraps
# from http.client import RemoteDisconnected

# import wda
# from requests.exceptions import ConnectionError
# from robot.api.deco import keyword
# from wda import WDAElementNotDisappearError, WDAElementNotFoundError, WDARequestError

# from . import log


# def screenshot(func):
#     @wraps(func)
#     def inner(self, *args, **kwargs):
#         try:
#             f = func(self, *args, **kwargs)
#             return f
#         except (WDAElementNotFoundError, WDAElementNotDisappearError, AssertionError) as err:
#             self.ios_get_screen_shot()
#             raise err

#     return inner


# class IOSLibrary:
#     ROBOT_LIBRARY_SCOPE = "GLOBAL"

#     @keyword
#     def ios_open_application(self, device_url="http://localhost:8100", bundle_id=None, wait=30):
#         """
#         打开APP

#         - device_url: wda启动的url
#         - bundle_id: 要启动的app的标识
#         - wait: 等待启动wda的时间
#         - return: app对应的wda session
#         """
#         try:
#             # wda.DEBUG = True
#             # wda.HTTP_TIMEOUT = 60.0  # default 60.0 seconds
#             self.client = wda.Client(device_url)
#             log.info("等待WDA启动...", also_console=True)
#             self.client.wait_ready(int(wait))
#             # self.client = wda.USBClient('00008030-001911843A10802E', port=8100, wda_bundle_id="com.facebook.yuweihu.WebDriverAgentRunner.xctrunner")
#             log.info("WDA启动情况：%s" % self.client.status(), also_console=True)
#             self.client.unlock()
#             self.session = self.client.session(bundle_id)
#             log.info("当前APP信息：%s" % self.client.app_current(), also_console=True)
#         except ConnectionError as err:
#             raise ConnectionError("WDA未启动！请检查{}\n{}".format(device_url, err))
#         except RemoteDisconnected as err:
#             raise RemoteDisconnected("设备没有响应，WDA可能正在重启中...\n%s" % err)
#         return self.session

#     @keyword
#     def ios_activate_application(self, device_url="http://localhost:8100", bundle_id=None, wait=30):
#         """
#         调试case时用，可从用例的中间开始运行

#         - device_url: wda启动的url
#         - bundle_id: 要启动的app的标识
#         - wait: 等待启动wda的时间
#         - return: app对应的wda session
#         """
#         try:
#             # wda.DEBUG = True
#             # wda.HTTP_TIMEOUT = 60.0  # default 60.0 seconds
#             self.client = wda.Client(device_url)
#             log.info("等待WDA启动...", also_console=True)
#             self.client.wait_ready(int(wait))
#             # self.client = wda.USBClient('00008030-001911843A10802E', port=8100, wda_bundle_id="com.facebook.yuweihu.WebDriverAgentRunner.xctrunner")
#             log.info("WDA启动情况：%s" % self.client.status(), also_console=True)
#             self.client.unlock()
#             self.client.app_activate(bundle_id)
#             self.session = self.client.session()
#             log.info("当前APP信息：%s" % self.client.app_current(), also_console=True)
#         except ConnectionError as err:
#             raise ConnectionError("WDA未启动！请检查{}\n{}".format(device_url, err))
#         except RemoteDisconnected as err:
#             raise RemoteDisconnected("设备没有响应，WDA可能正在重启中...\n%s" % err)
#         return self.session

#     @keyword
#     def ios_find_element(self, locator, timeout=10):
#         """
#         查找元素

#         - locator: 定位器
#         - timeout: 超时时间
#         - return: element object
#         - raise: WDAElementNotFoundError
#         """
#         try:
#             code = "self.session(%s)" % locator
#             e = eval(code)
#         except NameError:
#             code = "self.session('%s')" % locator
#             e = eval(code)
#         try:
#             e.get(timeout=timeout)
#         except WDARequestError as err:
#             log.info("ios_find_element: %s" % err, also_console=True)
#         except WDAElementNotFoundError:
#             msg = "元素 {} 在 {} s后未找到".format(locator, timeout)
#             raise WDAElementNotFoundError(msg)
#         return e

#     @screenshot
#     @keyword
#     def ios_click_element(self, locator, timeout=10):
#         """
#         点击元素

#         - locator: 定位器
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("点击元素 %s" % locator, also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         e.click()

#     @screenshot
#     @keyword
#     def ios_click_element_if_exist(self, locator, timeout=2):
#         """
#         如果元素存在，点击元素

#         - locator: 定位器
#         - timeout: 超时时间
#         - return: element object
#         """
#         try:
#             e = self.ios_find_element(locator, timeout=timeout)
#             if e.click_exists(timeout=timeout):
#                 log.info("元素 %s 存在，已点击" % locator, also_console=True)
#                 return e
#         except WDAElementNotFoundError:
#             log.info("元素 {} {}s 不存在，跳过".format(locator, timeout), also_console=True)
#         return None

#     @screenshot
#     @keyword
#     def ios_input_text(self, locator, text, timeout=10):
#         """
#         输入文本到元素中

#         - locator: 定位器
#         - text: 文本
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("点击元素 %s" % locator, also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         e.click()
#         e.clear_text()
#         log.info("输入内容 %s" % repr(text), also_console=True)
#         self.session.send_keys(text)
#         self.ios_click_element_if_exist('className="Button",label="完成"')
#         self.ios_click_element_if_exist('className="Button",label="Toolbar Done Button"')

#     @screenshot
#     @keyword
#     def ios_input_text_if_exist(self, locator, text, timeout=2):
#         """
#         如果元素存在，输入文本到元素中

#         - locator: 定位器
#         - text: 文本
#         - timeout: 超时时间
#         - return: None
#         """
#         e = self.ios_click_element_if_exist(locator, timeout=timeout)
#         if e:
#             e.clear_text()
#             log.info("输入内容 %s" % repr(text), also_console=True)
#             self.session.send_keys(text)
#             self.ios_click_element_if_exist('className="Button",label="完成"')
#             self.ios_click_element_if_exist('className="Button",label="Toolbar Done Button"')

#     @screenshot
#     @keyword
#     def ios_input_value(self, locator, text, timeout=10):
#         """
#         输入文本到元素中

#         - locator: 定位器
#         - text: 文本
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("输入 {} 到元素 {} 中".format(repr(text), locator), also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         e.clear_text()
#         log.info("输入内容 %s" % repr(text), also_console=True)
#         e.set_text(text)
#         self.ios_click_element_if_exist('className="Button",label="完成"')
#         self.ios_click_element_if_exist('className="Button",label="Toolbar Done Button"')

#     @screenshot
#     @keyword
#     def ios_input_secure_keyboard(self, locator, text, timeout=10):
#         """


#         - locator: 定位器
#         - text: 文本
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("使用安全键盘输入 {} 到元素 {} 中".format(repr(text), locator), also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         e.clear_text()
#         # 立刷安全键盘
#         for i in text:
#             if i.isalpha() and i.islower():
#                 self.session(name=i).click()
#             if i.isalpha() and i.isupper():
#                 self.session(name="uppcase").click()
#                 self.session(name=i).click()
#                 self.session(name="uppcase").click()
#             if i.isdigit():
#                 self.session(name=".?123").click()
#                 self.session(name=i).click()
#                 self.session(name="ABC").click()
#         # e.set_text(text)
#         self.ios_click_element_if_exist('label=="完成"')

#     @screenshot
#     @keyword
#     def ios_wait_until_page_does_not_contain_element(self, locator, timeout=3):
#         """
#         等待元素不可见

#         - locator: 定位器
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("等待元素 %s 不可见" % locator, also_console=True)
#         try:
#             e = self.ios_find_element(locator, timeout=timeout)
#             try:
#                 e.wait_gone()
#             except WDAElementNotDisappearError:
#                 msg = "元素 {} 在 {} s后仍可见".format(locator, timeout)
#                 raise WDAElementNotDisappearError(msg)
#         except WDAElementNotFoundError:
#             pass
#         # WDARequestError(status=110, value={'error': 'stale element reference',
#         # 'message': 'The previously found element "

#     @screenshot
#     @keyword
#     def ios_get_text(self, locator, timeout=10):
#         """
#         获取元素文本

#         - locator: 定位器
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("获取元素 %s 文本" % locator, also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         element_text = e.text
#         log.info("=====文本如下=====\n%s\n=====********=====" % element_text, also_console=True)
#         return element_text

#     @screenshot
#     @keyword
#     def ios_get_table_text(self, locator, webview=False, timeout=10):
#         log.info("获取元素 %s 文本" % locator, also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         if webview:
#             ts = e.child(classChain="**/XCUIElementTypeOther/**/XCUIElementTypeStaticText").ios_find_elements()
#             msg = "\n".join([t.text for t in ts])
#         else:
#             cells = e.child(className="Cell").ios_find_elements()
#             counts = len(cells)
#             log.info("Cell数量：%s" % counts, also_console=True)
#             if counts == 0:
#                 ts = e.child(className="StaticText").ios_find_elements()
#                 msg = "\n".join([t.text for t in ts])
#             else:
#                 ts = e.child(classChain="**/XCUIElementTypeCell/XCUIElementTypeStaticText").ios_find_elements()
#                 msg = "\n".join([t.text for t in ts])
#         log.info("=====Table文本如下=====\n%s\n=====*************=====" % msg, also_console=True)
#         return msg

#     @screenshot
#     @keyword
#     def ios_element_text_should_be(self, locator, expected, timeout=10):
#         """
#         断言元素文本

#         - locator: 定位器
#         - expected: 期望的文本值
#         - timeout: 超时时间
#         - return: None
#         """
#         log.info("断言: 元素 {} 的文本应该为 {}".format(locator, expected), also_console=True)
#         text = self.ios_get_text(locator, timeout)
#         if text != expected:
#             msg = "断言失败: 文本:{} != 期望:{}".format(text, expected)
#             raise AssertionError(msg)
#         else:
#             log.info("断言成功: {} == {}".format(text, expected), also_console=True)

#     @keyword
#     def ios_get_screen_shot(self):
#         # 不支持文件名中含有冒号
#         # file_path = os.path.dirname(os.path.dirname(__file__))
#         # png_name = file_path + '/ios-screenshot-%s.png' % datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S.%f')
#         log.info("开始截图...", also_console=True)
#         # png_b64_str = base64.b64encode(self.client.screenshot(png_name, 'raw')).decode('utf-8')
#         png_b64_str = base64.b64encode(self.client.screenshot(format="raw")).decode("utf-8")
#         log.info(
#             '</td></tr><tr><td colspan="3">'
#             '<img alt="screenshot" class="robot-ioslibrary-screenshot" '
#             'src="data:image/png;base64,{0}" width="{1}px">'.format(png_b64_str, 400),
#             html=True,
#         )

#     @keyword
#     def ios_click_element_at_point(self, locator, x_offset=0, y_offset=0, timeout=10):
#         if x_offset == "" or not x_offset:
#             x_offset = 0
#         if y_offset == "" or not y_offset:
#             y_offset = 0
#         if timeout == "" or not timeout:
#             timeout = 10
#         log.info("点击元素 {} ，偏移[{}, {}]".format(locator, x_offset, y_offset), also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         x, y = e.bounds.x + x_offset, e.bounds.y + y_offset
#         self.session.click(x, y)

#     @keyword
#     def ios_ios_accept_alert_if_exist(self):
#         try:
#             log.info("alert 存在，已点击", also_console=True)
#             self.session.alert.accept()
#         except WDARequestError as err:
#             error = err.value.get("error")
#             if error == "no such alert":
#                 log.info("alert 不存在，跳过", also_console=True)
#             else:
#                 log.error(error)

#     @keyword
#     def ios_accept_alert(self):
#         try:
#             log.info("alert 接受", also_console=True)
#             self.session.alert.accept()
#         except WDARequestError as err:
#             error = err.value.get("error")
#             if error == "no such alert":
#                 raise Exception("alert 不存在")
#             else:
#                 raise Exception(error)

#     @keyword
#     def ios_scroll(self, locator, timeout=10):
#         log.info("滑动到元素 %s " % locator, also_console=True)
#         e = self.ios_find_element(locator, timeout=timeout)
#         # e.ios_scroll() # 有bug，已经找到元素了还在滑，导致请求wda超时的异常
#         x, y = e.bounds.x, e.bounds.y
#         width, height = self.session.window_size().width, self.session.window_size().height
#         num = y // height + 1
#         for i in range(num):
#             self.session.swipe_up()
#             if e.displayed:
#                 break
#             else:
#                 time.sleep(0.1)
#                 continue
#         if e.displayed:
#             log.info("元素已展示", also_console=True)
#         else:
#             log.info("元素未展示", also_console=True)


# if __name__ == "__main__":
#     self = IOSLibrary()
#     # wda.DEBUG = True
#     self.ios_open_application(bundle_id="com.tencent.xin")
#     self.ios_click_element_if_exist('name="下一步"')
#     time.sleep(1)
#     self.ios_click_element_if_exist('name="下一步"')
#     time.sleep(1)
#     self.ios_click_element_if_exist('name="下一步"')
#     time.sleep(1)
#     self.ios_click_element_if_exist('name="下一步"')
#     time.sleep(1)
#     self.ios_click_element_if_exist('name="进入微信"')
#     time.sleep(3)
#     # self.ios_click_element('name="订阅号消息"')
#     self.ios_input_value('className="SearchField",label="搜索"', "嘉联通行证")
#     self.ios_click_element('className="Button",label="搜索"')
#     self.ios_click_element('className="StaticText",label="搜一搜 "')
#     self.ios_click_element(
#         'className="StaticText",labelContains="嘉联 支付官方商户服务平台，百万商家收款对账管理工具，关注公众号，获取 嘉联 最新产品资讯和店铺经营管理技巧。 嘉联 支付，共付美好生活！ 嘉联支付有限公司"',
#         30,
#     )
#     self.ios_click_element_if_exist('className="Button",label="关注"')
#     self.ios_click_element_if_exist('className="Button",label="发消息"')
#     self.ios_click_element('className="Button",label="我是商户"')
#     self.ios_input_text('className="TextField"', "84944035521K02E")
#     self.ios_input_text('className="SecureTextField"', "bmeB5000")
#     self.ios_click_element('label="登录"')
#     self.ios_click_element('label="我的"')

#     # print(self.client.source())
