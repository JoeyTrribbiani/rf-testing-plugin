import json
import socket

from robot.api.deco import keyword
from thrift.protocol import TBinaryProtocol
from thrift.Thrift import TApplicationException
from thrift.transport import TSocket, TTransport
from thrift.transport.TTransport import TTransportException

from . import log
from .MposCrypto import Crypto
from .RpcAdapter import RpcAdapter
from .UtilsLibrary import UtilsLibrary


def log_request(ip, port, request_data, log_id, cmd=None):
    cmd_msg = "" if not cmd else f"cmd={cmd}\n "
    log.info(f"rpc请求 address={ip}:{port}\n " + f"log_id={log_id}\n " + cmd_msg + f"body={request_data}\n ")


def log_response(ip, port, response, log_id, cmd=None):
    cmd_msg = "" if not cmd else f"cmd={cmd}\n "
    log.info(f"rpc响应 address={ip}:{port}\n " + f"log_id={log_id}\n " + cmd_msg + f"body={response}\n ")


class RpcLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword
    def rpc_client_invoke(self, ip: str, port: int, template: dict, timeout: int = 8) -> dict:
        """实现RpcAdapter invoke方法调用,提供rpc调用能力

        - ip: _description_
        - port: _description_
        - template: _description_
        - timeout: 单位 秒
        - raises RuntimeError: _description_
        - return: _description_
        """
        no_space_uuid = UtilsLibrary.get_nonce()
        if isinstance(template, dict):
            log_id = template.setdefault("log_id", no_space_uuid)
            request_body = json.dumps(template, ensure_ascii=False)
        else:
            log_id = no_space_uuid
            request_body = template
        log_request(ip, port, request_body, log_id)
        t_socket = TSocket.TSocket(ip, port)
        t_socket.setTimeout(timeout * 1000)
        transport = TTransport.TFramedTransport(t_socket)
        protocol = TBinaryProtocol.TBinaryProtocol(transport)
        client = RpcAdapter.Client(protocol)
        try:
            transport.open()
            json_response = client.Invoke(log_id, request_body)
            log_response(ip, port, json_response, log_id)
            response_data = json.loads(json_response)
            transport.close()
            content = response_data
            return content
        except TApplicationException as e:
            raise RuntimeError(f"rpc_client_invoke 接收响应失败: {e.message}")
        except TTransportException as e:
            if e.type in (e.ALREADY_OPEN, e.NOT_OPEN):
                raise RuntimeError(f"rpc_client_invoke 连接失败: {e.message}")  # noqa
            elif isinstance(e.inner, socket.timeout):
                raise RuntimeError(f"rpc_client_invoke 响应超时: {timeout * 1000} ms仍未收到响应")
            else:
                raise RuntimeError(f"rpc_client_invoke 响应错误：{e.message}")  # noqa

    @keyword
    def rpc_crypto_invoke(self, ip: str, port: int, cmd: int, template: dict, timeout: int = 8) -> dict:
        """实现mpos-crypto-svc invoke方法调用,提供rpc调用能力

        - ip: _description_
        - port: _description_
        - template: _description_
        - raises RuntimeError: _description_
        - return: _description_
        """
        no_space_uuid = UtilsLibrary.get_nonce()
        if isinstance(template, dict):
            log_id = template.setdefault("log_id", no_space_uuid)
            request_body = json.dumps(template, ensure_ascii=False)
        else:
            log_id = no_space_uuid
            request_body = template
        log_request(ip, port, request_body, log_id, cmd)
        try:
            t_socket = TSocket.TSocket(ip, port)
            t_socket.setTimeout(timeout * 1000)
            transport = TTransport.TFramedTransport(t_socket)
            protocol = TBinaryProtocol.TBinaryProtocol(transport)
            client = Crypto.Client(protocol)
            transport.open()
            json_response = client.DoCrypto(cmd, log_id, request_body)
            log_response(ip, port, json_response, log_id, cmd)
            transport.close()
            response_data = json.loads(json_response)
            content = response_data
            return content
        except TApplicationException as e:
            raise RuntimeError(f"rpc_crypto_invoke 接收响应失败: {e.message}")
        except TTransportException as e:
            if e.type in (e.ALREADY_OPEN, e.NOT_OPEN):
                raise RuntimeError(f"rpc_crypto_invoke 连接失败: {e.message}")  # noqa
            elif isinstance(e.inner, socket.timeout):
                raise RuntimeError(f"rpc_crypto_invoke 响应超时: {timeout * 1000} ms仍未收到响应")
            else:
                raise RuntimeError(f"rpc_crypto_invoke 响应错误：{e.message}")  # noqa
