import json
import time
import traceback
import random
import string
import requests.utils
import base64


from binascii import b2a_hex
from typing import Union
from urllib.parse import urlparse, quote
from sm_crypto import sm2 as sm2_crypto
from asn1crypto import pem
from gmssl import sm2
from pyasn1.codec.der import decoder
from bs4 import BeautifulSoup
from robot.api.deco import keyword

from . import log
from .KubernetesLibrary import KubernetesLibrary
from .request.http_request import (
    AccessQuerySdkRequestFlow,
    AccessRequestFlow,
    AgentsRequestFlow,
    AgentWebRequestFlow,
    AuthSdkRequestFlow,
    CacheAuthorizationHttpRequestFlow,
    ExtQrcodeEncRequestFlow,
    ExtQrcodeRequestFlow,
    FilesRequestFlow,
    FormRequestFlow,
    GetRequest,
    HmacSha256RequestFlow,
    HttpRequestFlow,
    ImsSdkRequestFlow,
    JlpayRequestFlow,
    LedgerRequestFlow,
    LsRequestFlow,
    MerchantRegisterRequestFlow,
    MposManageRequestFlow,
    OldManageRegistRequestFlow,
    OldQrcodeRequestFlow,
    OpenAccessRequestFlow,
    OpenflatformRequestFlow,
    SignFilesRequestFlow,
    UnionFqQrcodeRequestFlow,
    UnionQrcodeRequestFlow,
    CoopBankRequestFlow,
    OpenflatformRequestFlowNew,
    FilesRequestFlowNew,
    HttpRequestFlowOpenPlatform,
    DictToXmlRequestFlow,
)
from .RpcLibrary import RpcLibrary
from .UtilsLibrary import UtilsLibrary
from .UtilsMsg import UtilsMsg
from .UtilsSign import UtilsSign
from .ZkLibrary import ZkLibrary


class RequestLibrary:
    def __init__(self) -> None:
        self.last_request = {}
        self.last_response = {}
        self.response_headers = {}
        self.http_flow = {}
        self.last_cookies = None
        self.zk_host = ""
        self.zk = ZkLibrary()
        self.rpc = RpcLibrary()
        self.k8s = KubernetesLibrary()

    @keyword
    def k8s_init_cluster(self, cluster="fat"):
        """调整k8s集群,用于 svc_url 解析
        - cluster: 支持参数: dev, fat, uat, ali-dev, pts
        """
        self.k8s.k8s_cluster(cluster)

    def http_flow_get(self, flow_name, flow_object):
        if flow_name not in self.http_flow:
            self.http_flow[flow_name] = flow_object
        return self.http_flow[flow_name]

    @keyword
    def http_post_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            resp_encoding: str = "",
            use_cache_authorization: bool = False,
            use_svc: bool = False,
            pri_key: str = "",
            pub_key: str = ""
    ) -> Union[str, dict, None]:
        """提供http post请求能力，消息类型为json

        - url: 请求地址 http://或https://开头
        - req_data: 请求体，json字符串
        - para_replace: 参数替换，json字符串, defaults to None
        - abnormal_replace: 异常参数替换，json字符串, defaults to None
        - http_headers: 请求头替换，json字符串, defaults to None
        - resp_encoding: 响应内容解码，如需要特殊时可以传入，如gbk, defaults to None
        - use_cache_authorization: 是否缓存响应头中的Authorization, 默认放在后续请求中
        - use_svc: 是否是svc方式调用, defaults to False
        - pri_key: RSA或SM2签名时用到的私钥（16进制格式），可选参数，传入时会对请求进行加签，defaults to None
        - pub_key: 可选参数，传入时会对响应进行验签（16进制格式）, defaults to None
        - return: 响应内容
        """
        if use_cache_authorization:
            http_post_flow = self.http_flow_get(
                "CacheAuthorizationHttpRequestFlow", CacheAuthorizationHttpRequestFlow()
            )
        else:
            http_post_flow = self.http_flow_get("HttpRequestFlow", HttpRequestFlow())
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=pri_key,
                                                                                    headers=http_headers).prepare(
            url, http_headers
        ).request().post_processor(resp_encoding).verify(public_key=pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response


    @keyword
    def open_platform_post(self, url, method='POST', body=None, para_replace=None,x_jlpay_key=None, sm2_pub_key=None, sm2_pri_key=None,
                           sm2_jl_pub_key_ver=None,x_jlpay_appid=None):
        ##增加参数替换逻辑
        if para_replace:
            body = UtilsMsg.str_to_dict(body)
            replace_data = UtilsMsg.str_to_dict(para_replace)
            body = UtilsMsg.para_replace(body, replace_data)
            body = UtilsMsg.msg_default_para_replace(body)

        uri = url.split('.com')[1]
        time_stamp = str(int(time.time()))
        characters = string.ascii_letters + string.digits
        random_string = ''.join(random.choice(characters) for _ in range(32))

        ##区分协议，进行报文组装
        if method == 'POST':
            sign_body = f'{method}\n{uri}\n{time_stamp}\n{random_string}\n{json.dumps(body, ensure_ascii=False)}\n'
        else:
            sign_body = f'{method}\n{uri}\n{time_stamp}\n{random_string}\n\n'
        # print(f'==========加签body==========: \n{sign_body}')

        # 公钥pem格式转16进制
        public_key_bytes = pem.unarmor(sm2_pub_key.encode())
        public_key_sm2 = sm2_crypto.SM2PublicKey.load(public_key_bytes[2])
        public_key = public_key_sm2.x + public_key_sm2.y

        # print(f'==========公钥16进制==========: \n{public_key}\n\n')

        # 私钥pem格式转16进制
        private_key_bytes = pem.unarmor(sm2_pri_key.encode())
        private_key_sm2 = sm2_crypto.SM2PrivateKey.load(private_key_bytes[2])
        private_key = private_key_sm2.value
        private_key = UtilsSign.parse_private_key(private_key)

        # print(f'==========私钥16进制==========: \n{private_key}\n\n')

        # 加签
        crypt = sm2.CryptSM2(private_key=private_key, public_key=public_key, mode=1, asn1=True)
        sign_str = crypt.sign_with_sm3(sign_body.encode())
        sign_value = base64.b64encode(bytes.fromhex(sign_str)).decode()

        # print(f'==========加签时签名==========: \n{sign_value}\n\n')

        http_headers = {
            'Content-Type': 'application/json; charset=utf-8',
            'x-jlpay-appid': x_jlpay_appid,
            'x-jlpay-nonce': random_string,
            'x-jlpay-timestamp': time_stamp,
            'x-jlpay-sign-alg': 'SM3WithSM2WithDer',
            'x-jlpay-sign': sign_value,
            'x-jlpay-key': x_jlpay_key
        }
        # print(f'请求地址: {url}\n请求头: {http_headers}')
        print(f'请求地址: {url}\n请求体: {json.dumps(body, ensure_ascii=False)}')

        # 发送http请求
        if  method =='POST':
            response = requests.post(url, data=json.dumps(body, ensure_ascii=False).encode('utf-8').decode('latin1'),headers=http_headers)
        else:
            response = requests.get(url,headers=http_headers)


        # print(f'http_status: {response.status_code}   响应头: {response.headers}')
        print(f'响应体: {response.text}')
        # 验签
        jl_public_key_bytes = pem.unarmor(sm2_jl_pub_key_ver.encode())
        jl_public_key_asn1, _ = decoder.decode(jl_public_key_bytes[2])
        jl_public_key = jl_public_key_asn1[1].asOctets().hex()[2:]
        # 生成嘉联加签验签对象
        sm2_jl_crypt = sm2.CryptSM2(public_key=jl_public_key, private_key=None, mode=1, asn1=True)

        sign_value = response.headers['x-jlpay-sign']
        time_stamp = response.headers['x-jlpay-timestamp']
        random_string = response.headers['x-jlpay-nonce']
        sign_body = f'{method}\n{uri}\n{time_stamp}\n{random_string}\n{response.text}\n'
        # print(f'==========验签body==========: \n{sign_body}\n')
        print(
            f'验签结果: {sm2_jl_crypt.verify_with_sm3(base64.b64decode(sign_value).hex(), bytes(sign_body, encoding="utf8"))}')

        self.last_response = response.text
        return response.text

    @keyword
    def http_post_api_ar(
            self,
            url: str,
            req_data: Union[str, dict],
            expect,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            resp_encoding: str = "",
            interval=1,
            time_out=60,
    ):
        start_time = time.time()
        end_time = start_time + time_out
        while time.time() < end_time:
            res = self.http_post_api(url, req_data, para_replace, abnormal_replace, http_headers, resp_encoding)
            try:
                UtilsMsg.dict_compare(res, expect)
                return res
            except BaseException:
                time.sleep(interval)
        return res

    @keyword
    def http_get_api(
            self,
            url: str,
            params: str = "{}",
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            resp_encoding: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """提供http get请求能力

        - url: _description_
        - params: _description_, defaults to '{}'
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: 响应内容
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_get_flow = self.http_flow_get("GetRequest", GetRequest())
        http_get_flow.pre_processor(params, para_replace, abnormal_replace).prepare(
            url, http_headers
        ).request().post_processor(resp_encoding)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_get_flow.last_request,
            http_get_flow.last_response,
            http_get_flow.response_headers,
            http_get_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_qrcode_api(
            self,
            privateKey: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            with_id: str = "",
            pub_key: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """http请求，提供给新外接码付调用

        - privateKey: RSA或SM2签名时用到的私钥
        - url: 请求地址
        - req_data: 请求体
        - para_replace: 参数替换, defaults to None
        - abnormal_replace: 异常参数替换, defaults to None
        - http_headers: 请求头, defaults to None
        - with_id: SM2签名时指定用户id签名时传入, defaults to None
        - pub_key: 可选参数，传入时会对响应进行验签, defaults to None
        - return: 响应内容
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("ExtQrcodeRequestFlow", ExtQrcodeRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=privateKey, with_id=with_id
        ).prepare(url, http_headers).request().post_processor().verify(public_key=pub_key, with_id=with_id)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_qrcode_api_hsm_cipher(
            self,
            privateKey: str,
            sm4_key: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            with_id: str = "",
            pub_key: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """http国密全报文加密请求，提供给新外接码付调用

        - privateKey: RSA或SM2签名时用到的私钥
        - sm4_key: 响应进行验签和全报文国密解密, defaults to None
        - url: 请求地址
        - req_data: 请求体
        - para_replace: 参数替换, defaults to None
        - abnormal_replace: 异常参数替换, defaults to None
        - http_headers: 请求头, defaults to None
        - with_id: SM2签名时指定用户id签名时传入, defaults to None
        - pub_key: 可选参数，传入时会对响应进行验签, defaults to None
        - return: 响应内容
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("ExtQrcodeEncRequestFlow", ExtQrcodeEncRequestFlow())
        # decrypto(key=None) 响应报文是使用响应头里的密文sm4key，
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=privateKey, with_id=with_id
        ).crypto(key=sm4_key).prepare(url, http_headers).request().post_processor().decrypto(
            key=None, pri_key=privateKey
        ).verify(
            public_key=pub_key, with_id=with_id
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_qrcode_old_api(
            self,
            privateKey: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """老外接码付

        - privateKey: _description_
        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to {}
        - abnormal_replace: _description_, defaults to {}
        - http_headers: _description_, defaults to {}
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("OldQrcodeRequestFlow", OldQrcodeRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=privateKey).prepare(
            url, http_headers
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_ledger_api(
            self,
            url: str,
            pri_key: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """http请求, 新分账业务

        - url: 请求地址
        - pri_key: RSA或SM2签名时用到的私钥
        - req_data: 请求体
        - para_replace: 参数替换, defaults to None
        - abnormal_replace: 异常参数替换, defaults to None
        - http_headers: 请求头, defaults to None
        - pub_key: 可选参数，传入时会对响应进行验签, defaults to None
        - return: 响应内容
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("LedgerRequestFlow", LedgerRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=pri_key).prepare(
            url, http_headers
        ).request().post_processor().verify(public_key=pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_coop_bank_api(
            self,
            url: str,
            pri_key: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            use_svc: bool = False
    ) -> Union[str, dict, None]:
        """http请求, 银行合作平台

        - url: 请求地址
        - pri_key: RSA或SM2签名时用到的私钥（16进制格式）
        - req_data: 请求体
        - para_replace: 参数替换, defaults to None
        - abnormal_replace: 异常参数替换, defaults to None
        - http_headers: 请求头, defaults to None
        - pub_key: 可选参数，传入时会对响应进行验签（16进制格式）, defaults to None
        - return: 响应内容
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("CoopBankRequestFlow", CoopBankRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=pri_key,
                                                                                    headers=http_headers).prepare(
            url, http_headers
        ).request().post_processor().verify(public_key=pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_manage_api(
            self,
            url: str,
            req_data: Union[str, dict],
            pri_key: str,
            sign_fields: str = "",
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """商户进件服务请求，对部分字段进行签名

        - url: _description_
        - req_data: _description_
        - pri_key: _description_
        - sign_fields: 多个字段用","号隔开，例如aaa,bbb,ccc, defaults to ''
        - para_replace: _description_, defaults to None
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("OldManageRegistRequestFlow", OldManageRegistRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            pri_key, sign_fields=sign_fields
        ).prepare(url, http_headers).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_openflatform_api(
            self,
            privateKey: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """针对fee-open-api服务创建订单，对部分字段进行加密

        - privateKey: _description_
        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("OpenflatformRequestFlow", OpenflatformRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(privateKey).prepare(
            url, http_headers
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_openflatform_api_new(
            self,
            pri_key: str,
            pub_key: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """针对fee-open-api服务预设机具功能，请求内容加签时不需要 & 拼接

        - privateKey: _description_
        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("OpenflatformRequestFlowNew", OpenflatformRequestFlowNew())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(pri_key).prepare(
            url, http_headers
        ).request().post_processor().verify(pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_union_fq_callback_api(
            self,
            private_key: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            with_id: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """银联分期码回调，SHA256withRSA，或SM2

        - private_key: pkcs#1格式rsa私钥，或hex string格式的SM2私钥
        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("UnionFqQrcodeRequestFlow", UnionFqQrcodeRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=private_key, with_id=with_id
        ).prepare(url, http_headers).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_union_callback_api(
            self,
            private_key: str,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            with_id: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """银联默认二维码回调，SHA1withRSA，或SM2

        - private_key: pkcs#1格式rsa私钥，或hex string格式的SM2私钥
        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("UnionQrcodeRequestFlow", UnionQrcodeRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=private_key, with_id=with_id
        ).prepare(url, http_headers).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_app_biz_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            app_pub_key: str = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvqCyzCtEzdnZu9P5asJ1q2y+eIx3FlagSEIY+ekH8GvymmtGzoEVAMcbKiPcIWgsjMewAAYWJddUcnVdBUKsViHjHpd+5qmE3/M4YoBr69NCQYB8RiQ6sGn2D5zTfYo7fJV/L6hPUk9rcml/64YdxQJ9+bwew6fZ7IqjTXjbEIhbzlbI+XEr3uGBNjbQxVx4Y9kaQOSa0AJFuF1Tntb8s7iI859iAOfAo0payBV4GY3wgCnkyWz1ceT+wg6t172CAOikdGBPvImwJhK2IXMKbXZhoxcihE7U9rHvPFxYajSX/HCGiPcQEiEWieGVLpaeYbaKgMR9zhheQSa+60cIHQIDAQAB",
            app_key: str = "SfmJX3wpzvydqPW1",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """嘉联支付app密文请求，TODO:签名相关

        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - app_id: _description_, defaults to '162575608951564'
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("JlpayRequestFlow", JlpayRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            key=app_key, pub_key=app_pub_key
        ).sign(private_key="").prepare(url, http_headers).request().post_processor().decrypto(app_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_ls_biz_api(
            self,
            url: str,
            pri_key: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            app_key: str = "LS20180918182402",
            jlpay_public_key: str = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs8VvLiszel4joQzHt/UIzstS4YUpsybo0pCUZzj+mB+DKwoVlffS1KjnlkHmAgkCDW1T64mGHtYv4SBMA9KAanQhzEoHumwEzu/yuuGz29pt1QDxo9Fd/3UNdl84sSVVptH2Uono5Xqgndf9MRhjSa/3xZ0POB47N2Pq0uQJpKd30ZNOLvbSSpzrqVmRF08oc2lCI6Ha6bmvO8zA4TrtZ6VgTu55qTtAXGzZKGFBvTKzI2/TtUBTsv6KstLpP4EO6E8ttcmVAiiaSaJFmSKjeqV2HFeC62I8QxEh60TtOVcFVeAlAap2TVU6tqnAOP7f2J9C8fLTzQwCZXVNIctdHQIDAQAB",
            enc_user_mp: bool = True,
            resp_verify: bool = True,
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """立刷app密文请求

        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - app_pub_key: _description_, defaults to 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAs8VvLiszel4joQzHt/UIzstS4YUpsybo0pCUZzj+mB+DKwoVlffS1KjnlkHmAgkCDW1T64mGHtYv4SBMA9KAanQhzEoHumwEzu/yuuGz29pt1QDxo9Fd/3UNdl84sSVVptH2Uono5Xqgndf9MRhjSa/3xZ0POB47N2Pq0uQJpKd30ZNOLvbSSpzrqVmRF08oc2lCI6Ha6bmvO8zA4TrtZ6VgTu55qTtAXGzZKGFBvTKzI2/TtUBTsv6KstLpP4EO6E8ttcmVAiiaSaJFmSKjeqV2HFeC62I8QxEh60TtOVcFVeAlAap2TVU6tqnAOP7f2J9C8fLTzQwCZXVNIctdHQIDAQAB'
        - app_key: _description_, defaults to 'LS20180918182402'
        - resp_verify: _description_, defaults to True, 需要关闭响应验签时
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("LsRequestFlow", LsRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            key=app_key, enc_user_mp=enc_user_mp
        ).sign(private_key=pri_key).prepare(url, http_headers).request().post_processor().verify(
            public_key=jlpay_public_key, resp_verify=resp_verify
        ).decrypto(
            app_key
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_access_biz_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pri_key: str = "",
            jlpay_public_key: str = "",
            app_key: str = "",
            biz_key: str = "biz_content",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """T9智能终端外部接入接口

        encryptKey接口
        - app的话，响应信息加密是用OPEN_GATEWAY_USER.T_APP_ENC_CONFIG中的jlpayPublicKey
        - 终端的话，响应信息加密是用CRM_NEW.T_TMS_KEY_MATCH中的public_content
        - url: _description_
        - req_data: _description_, defaults to None
        - para_replace: _description_, defaults to None
        - pri_key: app_id device_type为app时，提供app_pri_key; app_id device_type为pos时，提供终端的pri_key, defaults to ''
        - jlpay_public_key: _description_, defaults to ''
        - app_key: 对称加密密钥, defaults to ''
        - biz_key: _description_, defaults to 'biz_content'
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("AccessRequestFlow", AccessRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            key=app_key, pub_key=jlpay_public_key, biz_key=biz_key
        ).sign(private_key=pri_key).prepare(url, http_headers).request().post_processor().verify(
            public_key=jlpay_public_key
        ).decrypto(
            key=app_key, pri_key=pri_key
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_open_access_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pri_key: str = "",
            jlpay_public_key: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """兼容open-access请求

        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - pri_key: _description_, defaults to ''
        - jlpay_public_key: _description_, defaults to ''
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("OpenAccessRequestFlow", OpenAccessRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            pub_key=jlpay_public_key, biz_key="context"
        ).prepare(url, http_headers).request().post_processor().decrypto(None, pri_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_merchant_register_api(
            self,
            url: str,
            req_data: Union[str, dict],
            pri_key: str,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            sm4_key: str = "",
            body_enc: str = "",
            resp_enc: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """新进件服务，支持国密签名算法(SM3withSM2)，对标crypto-hsm服务 SM3WithSM2WithDer签名类型
        鉴权前置服务国密签名时也可用

        - url: _description_
        - req_data: _description_
        - pri_key: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - pub_key: _description_, defaults to ""
        - sm4_key: 加密请求中的敏感字段, 用到的sm4密钥, 如果不加密,则不传
        - body_enc: 请求中需要加密的字段
        - resp_enc: 响应中需要解密的字段, 多个的话用,隔开
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("MerchantRegisterRequestFlow", MerchantRegisterRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            key=sm4_key, pub_key=pub_key, body_enc=body_enc
        ).sign(private_key=pri_key).prepare(url, http_headers).request().post_processor().verify(
            public_key=pub_key
        ).decrypto(
            key=None, pri_key=pri_key, resp_enc=resp_enc
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_mpos_manage_api(
            self,
            url: str,
            req_data: Union[str, dict],
            app_key: str = "LS20180918182402",
            sign_fields: str = "",
            resp_sign_fields: str = "",
            resp_verify: bool = True,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """fee-open-api-srv 签名请求

        - url: _description_
        - req_data: _description_
        - app_key: _description_, defaults to 'LS20180918182402'
        - sign_fields: _description_, defaults to ''
        - resp_sign_fields: _description_, defaults to ''
        - resp_verify: _description_, defaults to True, 需要关闭响应验签时
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("MposManageRequestFlow", MposManageRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=app_key, sign_fields=sign_fields
        ).prepare(url, http_headers).request().post_processor().verify(
            public_key=app_key, resp_sign_fields=resp_sign_fields, resp_verify=resp_verify
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_query_sdk_api(
            self,
            url: str,
            req_data: Union[str, dict],
            private_key: str,
            public_key: str = "",
            sm4_key: str = "",
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            resp_verify: bool = True,
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """大数据查询入口服务 密文请求

        - url: _description_
        - req_data: _description_
        - private_key: 客户方SM2私钥，加签时使用，hex格式字符串，必填参数
        - public_key: 平台方SM2公钥，加密对称加密密钥时使用，hex格式字符串，全报文加密时必填参数。
        - sm4_key: 可选参数，不传默认在请求时会自动生成SM4对称加密密钥, 传入时可指定对称密钥加密报文，hex格式字符串
        - para_replace: _description_, defaults to {}
        - abnormal_replace: _description_, defaults to {}
        - http_headers: _description_, defaults to {}
        - resp_verify: 默认为True，传入False时跳过响应验签，这里还跳过响应解密
        - return: _description_

        | Http Query Sdk Api | {"org_no":"FUND","sign_type":"01","nonce_str":"y","timestamp":"\${%Y-%m-%d %H:%M:%S}","encrypt_alg":"1","encrypt_key":"","biz_context":{"beginTime":"2023-02-01 00:00:00","endTime":"2023-03-02 23:59:59"}} | 9edf424c1eee2edf05354ed90c575ef79c8fec9a30224af6a063b9a162d003cb | e60301d30b39e3d4a3bdee98ae2c637860bbd99f08c53e47614a61fcced3ba91d7a784d86ff478e760743ba22bb78390a49a77bf41c5275493293fe346b45222 |

        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("AccessQuerySdkRequestFlow", AccessQuerySdkRequestFlow())
        # decrypto(key=None) 使用加密时生成的sm4_key
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(
            key=sm4_key, pub_key=public_key
        ).sign(private_key=private_key).prepare(url, http_headers).request().post_processor().verify(
            public_key, resp_verify=resp_verify
        ).decrypto(
            key=None, resp_verify=resp_verify
        )
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_auth_sdk_api(
            self,
            url: str,
            req_data: Union[str, dict],
            pri_key: str,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """鉴权前置服务，支持国密签名算法(SM3withSM2)，对标crypto-hsm服务 SM3WithSM2WithDer签名类型

        - url: _description_
        - req_data: _description_
        - pri_key: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - pub_key: _description_, defaults to ""
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("AuthSdkRequestFlow", AuthSdkRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=pri_key).prepare(
            url, http_headers
        ).request().post_processor().verify(public_key=pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_ims_sdk_api(
            self,
            url: str,
            req_data: Union[str, dict],
            pri_key: str,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            der: bool = True,
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """进销存SDK服务，支持国密签名算法(SM3withSM2)，对标crypto-hsm服务 SM3WithSM2WithDer签名类型

        - url: _description_
        - req_data: _description_
        - pri_key: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - pub_key: _description_, defaults to ""
        - der: 默认对sm2签名值进行Der编码，如需要进行其他测试，可以设置False来检查服务的返回
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("ImsSdkRequestFlow", ImsSdkRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(
            private_key=pri_key, asn1=der
        ).prepare(url, http_headers).request().post_processor().verify(public_key=pub_key, asn1=der)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_hmacsha256_api(
            self,
            url: str,
            req_data: Union[str, dict],
            appsecret: str,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """账务hmacsha256 http请求
        - url: _description_
        - req_data: _description_
        - appsecret: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("HmacSha256RequestFlow", HmacSha256RequestFlow())
        # sign 必传参数为 private_key
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=appsecret).prepare(
            url, http_headers
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_agents_api(
            self,
            url: str,
            pri_key: str,
            common: dict,
            param: Union[str, dict],
            token: str = "",
            agent_aes_key: str = "U6woFMMEYEjgb+Ep",
            pub_key: str = "",
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """合伙人app密文请求，agent-query/agent-web服务请求使用
        ticket由deviceId和time计算得到，common不能为空
        nonce不能重复，redis key为'AGENT_APP_NONCE_' + nonce
        请求先签名，再加密，响应先解密，再验签

        - url: _description_
        - pri_key: _description_
        - common: _description_
        - param: _description_
        - token: _description_, defaults to ''
        - agent_aes_key: _description_, defaults to 'U6woFMMEYEjgb+Ep'
        - pub_key: 1.传入password字段进行登录时必须；2.需要验签时必须, defaults to None
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("AgentsRequestFlow", AgentsRequestFlow())
        http_post_flow.pre_processor(param, para_replace, abnormal_replace).sign(private_key=pri_key).crypto(
            key=agent_aes_key, common=common, token=token
        ).prepare(url, http_headers).request().post_processor().decrypto(agent_aes_key).verify(public_key=pub_key)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_urlencoded_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """http表单请求报文，消息类型x-www-form-urlencoded

        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("FormRequestFlow", FormRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).prepare(
            url, http_headers
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_spring_security_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            pub_key: str = "",
            use_svc: bool = False,
    ) -> dict:
        """spring security报文请求，post方式
        agent-web ,密码rsa加密方式登录

        - url: 请求地址
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - pub_key: 加密登录密码用到, defaults to None
        - return: _description_
        """
        http_post_flow = self.http_flow_get("AgentWebRequestFlow", AgentWebRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).crypto(pub_key=pub_key).prepare(
            url, http_headers
        ).request().post_processor()
        self.last_request = http_post_flow.last_request
        html = BeautifulSoup(http_post_flow.last_response, "html.parser")
        result = {}
        for item in html.find_all("input"):
            result[item.get("name")] = item.get("value")
        log.info("从响应的HTML中解析input得到：", result)
        self.last_response = result
        self.last_request, self.last_response, self.response_headers = (
            http_post_flow.last_request,
            result,
            http_post_flow.response_headers,
        )
        return self.last_response

    # @keyword
    def http_post_xml_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """TODO:xml报文请求，post方式

        - url: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - abnormal_replace: _description_, defaults to None
        - http_headers: _description_, defaults to None
        - raises RuntimeError: _description_
        - return: _description_
        """
        http_headers = {"Content-Type": "application/xml"}
        http_post_flow = self.http_flow_get("DictToXmlRequestFlow", DictToXmlRequestFlow())
        http_post_flow.prexmlpare(url=url,
                                  http_headers=http_headers).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_upload_file_api(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            files: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """根据业务需要，提供http上传文件功能

        - url 上传文件的url链接，如 http://trans-api.jlpay.com/open/file/upload
        - req_data 上传字段的data字典，其中如果有文件的话，需要是base64形式的字符串，请在本地使用`filepath_to_base64_str`方法，把文件转换为base64字符串然后传入，{"pic_file": "文件对应的base64字符串"}
        - para_replace 参数替代的字典
        - files 指定请求体中，哪些字段为文件类型，key为字段名，value为(文件名称,文件类型)，例如{"pic_file": {"file_name":"1.png","file_type":"image/png"}}
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("FilesRequestFlow", FilesRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace).prepare(
            url, http_headers, files=files
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_upload_file_api_new(
            self,
            url: str,
            req_data: Union[str, dict],
            http_headers: Union[str, dict] = {},
            files: Union[str, dict] = {},
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """
        【V4.0】商户系统规划(重构业务接入层)-基础文件直传服务
        https://jlpay.yuque.com/fsx9z5/regckm/uli77mdg29uxu1xq#AavgG
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("FilesRequestFlowNew", FilesRequestFlowNew())
        http_post_flow.pre_processor(req_data).prepare(url, http_headers, files=files).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_file_upload_sign_api(
            self,
            url: str,
            req_data: Union[str, dict],
            pri_key: str,
            para_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            files: Union[str, dict] = {},
            der: bool = True,
            use_svc: bool = False,
    ) -> Union[str, dict, None]:
        """http上传文件, 国密签名

        - url 上传文件的url链接，如 http://upload.jlpay.com/file/sign/upload
        - req_data 上传字段的data字典，其中如果有文件的话，需要是base64形式的字符串，请在本地使用`filepath_to_base64_str`方法，把文件转换为base64字符串然后传入，{"pic_file": "文件对应的base64字符串"}
        - pri_key hex格式sm2私钥, 必传
        - para_replace 参数替代的字典
        - files 指定请求体中，哪些字段为文件类型，key为字段名，value为(文件名称,文件类型)，例如{"pic_file": {"file_name":"1.png","file_type":"image/png","file_size":1}} file_size为多少Mb的文件,1就是1Mb的文件
        """
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow = self.http_flow_get("SignFilesRequestFlow", SignFilesRequestFlow())
        http_post_flow.pre_processor(req_data, para_replace).sign(pri_key, asn1=der, files=files).prepare(
            url, http_headers, files=files
        ).request().post_processor()
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    # 下面开始是rpc请求

    @keyword
    def zk_init_host(self, host: str) -> str:
        """设置rpc请求时，查询节点用的zookeeper地址"""
        self.zk_host = host
        return self.zk_host

    def _rpc_query_server(self, node_url: str):
        if not self.zk_host:
            raise ValueError("请先使用 Zk Init Host 关键字配置zk的连接地址")
        self.zk.zk_init_hosts(self.zk_host)
        ip, port = self.zk.query_nodes(node_url)
        log.info(f"服务节点{node_url}，服务地址为{ip}:{port}")
        return ip, port

    def _rpc_request_handle(self, request_data, replace_data, abnormal_data):
        request_body = UtilsMsg.str_to_dict(request_data)
        if replace_data:
            replace_data = UtilsMsg.str_to_dict(replace_data)
            request_body = UtilsMsg.para_replace(request_body, replace_data)
        request_body = UtilsMsg.msg_default_para_replace(request_body)
        if abnormal_data:
            abnormal_data = UtilsMsg.str_to_dict(abnormal_data)
            request_body = UtilsMsg.para_replace(request_body, abnormal_data)
        return request_body

    @keyword
    def rpc_access_api(
            self,
            node_url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            timeout: int = 8,
    ):
        """嘉联thirft rpc通用请求

        通过zk查询, 使用 podip 进行调用
        | Zk Init Host | xxx.xxx.xxx.xxx:2181 |
        | Rpc Access Api | /manage/accp | ${req_data} | ${para_replace} |

        默认fat集群, 通过svc域名转 nodeport 请求到 pod:
        | Rpc Access Api | rpc://manage-accp-svc.manage:25677 | ${req_data} | ${para_replace} |

        切换其他集群 `K8s Init Cluster`:
        | K8s Init Cluster | dev |
        | Rpc Access Api | rpc://manage-accp-svc.manage:25677 | ${req_data} | ${para_replace} |

        - node_url: 请求地址填zookeeper的路径, 或者rpc://开头的svc域名:rpc服务注册的端口(在apollo上查看服务配置)
        `rpc://{svc_name}.{namespace}:{port}` 例如: `rpc://manage-accp-svc.manage:25677`
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - timeout: 单位 秒, defaults to 8
        """
        if node_url.startswith("rpc://"):
            svc_url = node_url
            url = self.k8s.k8s_node_port_url(svc_url)
            parsed_result = urlparse(url)
            ip, port = parsed_result.hostname, parsed_result.port
        else:
            ip, port = self._rpc_query_server(node_url)
        body = self._rpc_request_handle(req_data, para_replace, abnormal_replace)
        response = self.rpc.rpc_client_invoke(ip, port, body, timeout)
        self.last_request = body
        self.last_response = response
        return self.last_response

    @keyword
    def rpc_access_api_ar(
            self,
            node_url: str,
            req_data: Union[str, dict],
            expect,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            interval=1,
            time_out=60,
    ):
        start_time = time.time()
        end_time = start_time + time_out
        while time.time() < end_time:
            res = self.rpc_access_api(node_url, req_data, para_replace, abnormal_replace)
            try:
                UtilsMsg.dict_compare(res, expect)
                return res
            except BaseException:
                time.sleep(interval)
        return res

    @keyword
    def rpc_access_api_hmacsha256(
            self,
            node_url: str,
            req_data: Union[str, dict],
            appsecret: str,
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            timeout: int = 8,
    ):
        """rpc请求，支持账务sign_hmacsha256

        - node_url: 用法同`Rpc Access Api`
        - req_data: _description_
        - appsecret: _description_
        - para_replace: _description_, defaults to None
        - timeout: 单位 秒, defaults to 8
        """
        if node_url.startswith("rpc://"):
            svc_url = node_url
            url = self.k8s.k8s_node_port_url(svc_url)
            parsed_result = urlparse(url)
            ip, port = parsed_result.hostname, parsed_result.port
        else:
            ip, port = self._rpc_query_server(node_url)
        body = self._rpc_request_handle(req_data, para_replace, abnormal_replace)
        sign_str = UtilsMsg.accp_account_sign_str(body)
        sign = UtilsSign.sign_hmac_sha256(appsecret, sign_str)
        body = UtilsMsg.sign_field_compare(body, sign)
        response = self.rpc.rpc_client_invoke(ip, port, body, timeout)
        self.last_request = body
        self.last_response = response
        return self.last_response

    @keyword
    def rpc_crypto_svc_api(
            self,
            node_url: str,
            cmd_id: int,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            timeout: int = 8,
    ):
        """mpos-crypto-svc rpc请求

        - node_url: 用法同`Rpc Access Api`
        - cmd_id: _description_
        - req_data: _description_
        - para_replace: _description_, defaults to None
        - timeout: 单位 秒, defaults to 8
        """
        if node_url.startswith("rpc://"):
            svc_url = node_url
            url = self.k8s.k8s_node_port_url(svc_url)
            parsed_result = urlparse(url)
            ip, port = parsed_result.hostname, parsed_result.port
        else:
            ip, port = self._rpc_query_server(node_url)
        body = self._rpc_request_handle(req_data, para_replace, abnormal_replace)
        response = self.rpc.rpc_crypto_invoke(ip, port, cmd_id, body, timeout)
        self.last_request = body
        self.last_response = response
        return self.last_response

    # 下面开始是工具方法

    @keyword
    def query_vouch_list(self, req_data: Union[str, dict], time_out: int = 20, para_replace=None):
        """
        req_data:查询会计分录报文:http://manage-accting-svc.manage:8080/entryVouchListQueryRpc
        time_out:轮询超时时间
        para_replace:查询报文替换参数
        """
        if time_out > 0:
            time.sleep(3)
            self.last_response = self.http_post_api("http://manage-accting-svc.manage:8080/entryVouchListQueryRpc", req_data, para_replace=para_replace)
            if self.last_response["total"] == 0:
                return self.query_vouch_list(req_data, time_out - 3, para_replace=para_replace)
            else:
                log.info("查询会计分录成功，剩余尝试时间%d" % time_out)
                return self.last_response
        else:
            log.info("查询会计分录失败")
            return self.last_response

    @keyword
    def replace_hex_template(self, req_data: Union[str, dict], para_replace: Union[str, dict] = {}):
        """智能pos交易使用

        - req_data: _description_
        - para_replace: _description_, defaults to None
        - return: _description_
        """
        req_msg = UtilsMsg.str_to_dict(req_data)
        req_para_replace = UtilsMsg.str_to_dict(para_replace)
        req_msg = UtilsMsg.para_replace(req_msg, req_para_replace)
        msg_sort = UtilsMsg.trans_splitaccount_sort(req_msg)
        return b2a_hex(msg_sort.encode("utf-8"))

    @keyword
    def resp_cookies_value(self, key: str) -> None:
        """获取会话中，cookies中的字段

        - key: _description_
        """
        if not self.last_cookies:
            raise RuntimeError("请求会话中的cookie为空！请检查是前面请求是否正常")
        cookies_dict = requests.utils.dict_from_cookiejar(self.last_cookies)
        try:
            return cookies_dict[key]
        except KeyError:
            raise RuntimeError(f"{key} 在 {cookies_dict} 中不存在！")

    @keyword
    def resp_headers_value(self, key: str) -> None:
        """获取响应头

        - key: _description_
        """
        if not self.response_headers:
            raise RuntimeError("上次请求响应头为空，请检查前面的请求是否正常")
        headers_dict = self.response_headers
        try:
            return headers_dict[key]
        except KeyError:
            raise RuntimeError(f"{key} 在 {headers_dict} 中不存在！")

    @keyword
    def resp_str_compare(self, resp_data: Union[str, dict]) -> None:
        """响应断言，对上个请求结果，和预期值进行比较

        - resp_data: _description_
        """
        self.last_response = (
            self.last_response
            if isinstance(self.last_response, str)
            else json.dumps(self.last_response, ensure_ascii=False)
        )
        UtilsMsg.str_compare(self.last_response, resp_data)

    @keyword
    def resp_in_str_compare(self, resp_data: str) -> None:
        """响应断言，期望的字符串 in 上个请求结果

        - resp_data: _description_
        """
        self.last_response = (
            self.last_response
            if isinstance(self.last_response, str)
            else json.dumps(self.last_response, ensure_ascii=False)
        )
        UtilsMsg.str_in_compare(self.last_response, resp_data)

    @keyword
    def resp_str_check(self, str1: str, str2: str):
        """断言，传入2个字符串进行对比

        - str1: _description_
        - str2: _description_
        """
        UtilsMsg.str_compare(str1, str2)

    @keyword
    def resp_str_num_check(self, str1: str, num: int, str2: str):
        """断言，常用判断初始金额，增加或减少后，与期望金额一致

        - str1: _description_
        - num: _description_
        - str2: _description_
        """
        result = int(str1) + int(num)
        UtilsMsg.str_compare(result, str2)

    @keyword
    def resp_dict_compare(self, resp_data: Union[str, dict]) -> None:
        """响应断言，上个请求结果，和预期json进行比较，预期json里不存在的key不进行比较

        - resp_data: _description_
        """
        data = UtilsMsg.str_to_dict(resp_data)
        UtilsMsg.dict_compare(self.last_response, data)

    @keyword
    def resp_exist_compare_notexist(self, data):
        """
        场景：校验传入str在响应消息体中不能存在
        data字段传入为字符串
        """
        UtilsMsg.exist_compare_notexist(self.last_response, data)

    @keyword
    def resp_exist_compare(self, data):
        """
        场景：校验传入str在响应消息体中需要存在
        data字段传入为字符串
        """
        UtilsMsg.exist_compare(self.last_response, data)

    @keyword
    def resp_exists_compare(self, data):
        """
        场景：校验传入字符串列表[str1,str2]在响应消息体中需要存在
        data字段传入为字符串列表
        """
        UtilsMsg.exists_compare(self.last_response, data)

    @keyword
    def db_check_exist_dict_compare(self, query_str, resp_data):
        """
        场景：DB查询接口与预期值进行比较
        数据查询，默认只能返回一条数据进行比较，即：返回数据对应是一个字典格式，非list数据
        """
        UtilsMsg.dict_compare(query_str, resp_data)

    @keyword
    def req_value(self, key: str):
        """获取请求消息体某个key的value

        - key: _description_
        - return: _description_
        """
        if isinstance(self.last_request, str):
            self.last_request = UtilsMsg.str_to_dict(self.last_request)
        if key in self.last_request:
            return self.last_request[key]
        else:
            return "None"

    @keyword
    def resp_value(self, key: str):
        """获取相应消息体某个key的value

        - key: _description_
        - return: _description_
        """
        if isinstance(self.last_response, str):
            self.last_response = UtilsMsg.str_to_dict(self.last_response)
        if key in self.last_response:
            return self.last_response[key]
        else:
            return "None"

    @keyword
    def resp_dict_value(self, expr: str):
        """从响应消息中获取repr对应的value

        - expr: jsonpath表达式
        - raises RuntimeError: _description_
        - return: _description_
        """
        return UtilsMsg.get_dict_value(self.last_response, expr)

    @keyword
    def mock_rpc_replace_node(self, old_node: str, new_node: str) -> dict:
        """
        1.	被调用方访问延迟返回；
        2.	被调用方连接已建立，但未返回；
        3.	被调用方访问后，返回固定的返回消息体；
        4.	被调用方节点不存在；
        5.	场景验证完毕，被调用方节点能够还原；
        此方法提供rpc节点替换；
        """
        try:
            self.zk.zk_init_hosts(self.zk_host)
            old_node_addr = self.zk.query_nodes_list(old_node)
            new_node_addr = self.zk.query_nodes_list(new_node)
            old_addr = ""
            for i in old_node_addr:
                old_addr = old_addr + i + ","
            old_addr = old_addr[:-1]

            resp_msg = {"ret_code": "01", "local_port": "", "description": "", "create_time": ""}  # --00：成功；01：失败
            if old_node_addr != "":
                resp_msg["local_port"] = old_addr
            resp_msg["create_time"] = UtilsLibrary.get_trans_time()

            # 替换old_node节点（先删除，后添加）
            self.zk.delete_provider(old_node)
            self.zk.add_node_provider(old_node, new_node_addr)

            resp_msg["ret_code"] = "00"
            self.oa_resp_msg = resp_msg
            return resp_msg
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"mock_rpc_replace_node Exception: {str(e)}")

    @keyword
    def mock_rpc_backend_node(self, old_node: str, local_port: str) -> dict:
        try:
            self.zk.zk_init_hosts(self.zk_host)
            # 先删除现有节点，再增加节点
            self.zk.delete_provider(old_node)
            if local_port != "":
                local_port_addr = local_port.split(",")
                local_port_list = []
                for i in local_port_addr:
                    local_port_list.append(i)
                self.zk.add_node_provider(old_node, local_port_list)
            log.info("恢复", old_node, "节点成功！")
            self.oa_resp_msg = {"ret_code": "00"}
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"mock_rpc_backend_node Exception: {str(e)}")

    @keyword
    def get_dict_from_response(
            self, url, req_data, http_headers, search_index, expect, interval=1, time_out=60, list_index="rows"
    ):
        """
        在列表中搜索指定数据
        - param url:请求地址
        - param req_data:请求参数
        - param http_headers:请求头
        - param search_index:筛选索引
        - param expect:期望的内容
        - param interval:等待时间
        - param time_out:最大请求时间
        - return:
        """

        start_time = time.time()
        end_time = start_time + time_out

        while time.time() < end_time:
            # 发起列表查询的请求
            resp = self.http_post_api(url=url, req_data=req_data, http_headers=http_headers)
            # if isinstance(resp, str):   因为UtilsMsg.str_to_dict()方法里会判断是否为字符串 是就转成dict 不是就直接返回dict
            resp = UtilsMsg.str_to_dict(resp)

            search_index = UtilsMsg.str_to_dict(search_index)

            expect = UtilsMsg.str_to_dict(expect)

            for i in range(len(resp[list_index])):
                tmp_dict = resp[list_index][i]
                success_compare_count = 0
                success_expect_compare_cout = 0
                for key in search_index:
                    if key in tmp_dict and search_index[key] == tmp_dict[key]:
                        success_compare_count = success_compare_count + 1
                if success_compare_count == len(search_index):
                    for k in expect:
                        if k in tmp_dict:
                            success_expect_compare_cout = success_expect_compare_cout + 1
                    if success_expect_compare_cout == len(expect):
                        target_dict = resp[list_index][i]
                        return target_dict
            time.sleep(interval)
        raise AssertionError("没有找到符合要求的内容")

    @keyword
    def string_join(self, pending_string, params):
        """
        拼接字符串
        - param string:待拼接的字符串 如 "https://merchant-fat.jlpay.com/boss_base/downloadReport?remote_path={file_url}&file_name={file_name}"
        - param params: 进行替换的参数 类型为json格式的字符串或者字典  如{"file_url":"aaa","file_name":"bbb"}
        - return: 返回拼接好的字符串 如  "https://merchant-fat.jlpay.com/boss_base/downloadReport?remote_path=aaa&file_name=bbb"
        """

        params = UtilsMsg.str_to_dict(params)
        handled_string = pending_string.format(**params)
        return handled_string

    @keyword
    def get_new_order_id(self) -> str:
        """调用订单系统直接获得订单号

        Examples:
        | ${order_id} | Get New Order Id |
        | Log | ${order_id} | #example: 411053973763049501491252 |
        """
        order_center_url = "http://order-center-svc.order:8080/generate_order_id"
        url = self.k8s.k8s_node_port_url(order_center_url)
        res = requests.get(url=url)
        try:
            resp = json.loads(res.text)
            if resp.get("ret_code") and resp.get("ret_code") == "00":
                return resp.get("order_id", "")
            else:
                log.info(f"订单系统响应异常{res.text}，正在重试...")
                return self.get_new_order_id()
        except json.JSONDecodeError:
            raise AssertionError(f"{order_center_url}订单系统响应错误：{res.text}")

    @keyword
    def http_post_api_open_platform(
            self,
            url: str,
            req_data: Union[str, dict],
            para_replace: Union[str, dict] = {},
            abnormal_replace: Union[str, dict] = {},
            http_headers: Union[str, dict] = {},
            resp_encoding: str = "",
            use_svc: bool = False,
            org_pri_key: str = "",
            org_pub_key: str = "",
            jl_pub_key: str = "",
            key: str = "",
            method: str = "POST",
            app_id: str = "an132e2fnywmgow",
            sign_type: str = "SM3WithSM2WithDer"
    ) -> Union[str, dict, None]:
        """
        V5.0 版本加验签（机构私钥加签，嘉联公钥验签）所有加验签方式是 V5.0 版本的服务都可以使用该方法
        开发接口统一签名方式：https://jlpay.yuque.com/fsx9z5/regckm/gk8uuowzqv938qcp?singleDoc#shFvM

        - url: 请求地址 http:// 或 https:// 开头
        - req_data: 请求体，json字符串
        - para_replace: 参数替换，json字符串，默认空字符串
        - abnormal_replace: 异常参数替换，json字符串，默认空字符串
        - http_headers: 请求头替换，json字符串，默认空字符串
        - resp_encoding: 响应内容解码，如需要特殊时可以传入，如gbk，默认空字符串（即不对响应进行编码）
        - use_svc: 是否是svc方式调用，默认False
        - org_pri_key: RSA或SM2签名时用到的机构私钥（pem格式），可选参数，传入时会对请求进行加签，默认空字符串（即不进行加验签）
        - org_pub_key: 机构公钥，可选参数，传入时会对响应进行加签（pem格式），默认空字符串（即不进行加验签）
        - jl_pub_key: 嘉联公钥，可选参数，传入时会对响应进行验签（pem格式），默认空字符串（即不进行加验签）
        - key: 可机构公钥，选参数，传入时会对响应进行验签（pem格式），默认空字符串（即不进行加验签）
        - method: 请求方法，默认为 POST
        - app_id: 请求应用编号，默认为uat环境的 an12c9t1965rnwj，fat环境是 an12c9t1965rnwj
        - with_id：SM2签名时指定用户id签名时传入，默认空字符串
        - sign_type：签名算法，SM3WithSM2WithDer 或者 RSA256
        - return: 响应内容
        """
        http_post_flow = self.http_flow_get('HttpRequestFlowOpenPlatform', HttpRequestFlowOpenPlatform())
        if use_svc:
            url = self.k8s.k8s_node_port_url(url)
        http_post_flow.pre_processor(req_data, para_replace, abnormal_replace).sign(private_key=org_pri_key,
                                                                                    org_pub_key=org_pub_key, key=key,
                                                                                    headers=http_headers, url=url,
                                                                                    method=method,
                                                                                    app_id=app_id,
                                                                                    sign_type=sign_type).prepare(url,
                                                                                                                 http_headers).request().post_processor(
            resp_encoding).verify(public_key=jl_pub_key, method=method, url=url)
        self.last_request, self.last_response, self.response_headers, self.last_cookies = (
            http_post_flow.last_request,
            http_post_flow.last_response,
            http_post_flow.response_headers,
            http_post_flow.cookies,
        )
        return self.last_response

    @keyword
    def http_post_api_qrcode(self,
                             url,
                             req_data):
        req_data_s = ""
        http_headers = {"Content-Type": "application/text; charset=UTF-8"}
        r_d_l = req_data.split("&")
        for i in r_d_l:
            j = i.split("=")
            req_data_s = req_data_s + j[0] + "=" + quote(j[1]) + "&"
        req_data_s = req_data_s[:-1]
        log.info(f"POST 请求 :  {url}")
        log.info(f"POST headers :  {http_headers}")
        log.info(f"POST body :  {req_data_s}")
        resp_data = requests.post(url=url, data=req_data_s, headers=http_headers)
        log.info(f"POST 响应 :  {resp_data.content}")
        return resp_data.content
