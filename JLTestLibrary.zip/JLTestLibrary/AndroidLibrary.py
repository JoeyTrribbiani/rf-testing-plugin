import time
from functools import wraps

import uiautomator2 as u2
from robot.api.deco import keyword
from uiautomator2 import Session, UiObjectNotFoundError

from . import log


def screenshot(func):
    @wraps(func)
    def inner(self, *args, **kwargs):
        try:
            f = func(self, *args, **kwargs)
            return f
        except (UiObjectNotFoundError, AssertionError) as err:
            raise err

    return inner


class AndroidLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword
    def ad_open_application(self, device_adb_wifi: str = "", package_name: str = "", wait: int = 30) -> Session:
        """打开APP

        - device_adb_wifi: adb_url
        - package_name: 要启动的app的标识
        - wait: 等待设备online的时间
        - return: app对应的session
        """
        if device_adb_wifi == "" or not device_adb_wifi:
            device_adb_wifi = "10.150.178.52:5555"
        try:
            self.device = u2.connect_adb_wifi(device_adb_wifi)
            log.info("等待uiautomator-v2启动...", also_console=True)
            self.device._wait_for_device(timeout=wait)
            log.info("当前设备信息：%s" % self.device.device_info, also_console=True)
            self.device.unlock()
            self.session = self.device.session(package_name, attach=False)
            log.info("当前APP信息：%s" % self.device.app_current(), also_console=True)
        except Exception as err:
            raise RuntimeError(f"启动异常！请检查{device_adb_wifi}\n{str(err)}")
        return self.session

    @keyword
    def ad_find_element(self, locator: str, timeout: int = 10):
        """查找元素

        - locator: 定位器
        - timeout: 超时时间
        - return: element object
        - raise: WDAElementNotFoundError
        """
        log.info("定位器 %s" % repr(locator), also_console=True)
        try:
            preffix = "xpath="
            if locator.startswith(preffix) and "," in locator:
                raise Exception("定位器使用xpath时，不允许使用多种参数")
            elif locator.startswith(preffix):
                self.session.xpath()
                cmd = "self.session.xpath({}).wait(timeout={})".format(locator.replace(preffix, ""), timeout)
                log.debug(cmd)
                exist = eval(cmd)

                cmd = "self.session.xpath(%s)" % locator.replace(preffix, "")
                log.debug(cmd)
                e = eval(cmd)
            else:
                cmd = "self.session(%s).wait(timeout=%s)" % (locator, timeout)
                log.debug(cmd)
                exist = eval(cmd)

                cmd = "self.session(%s)" % locator
                log.debug(cmd)
                e = eval(cmd)
        except ReferenceError as err:
            raise ReferenceError("定位器输入有误: %s" % err)
        if not exist:
            msg = "元素 {} 在 {} s后未找到".format(locator, timeout)
            raise UiObjectNotFoundError({"code": -32002, "message": msg, "method": "wait"})
        return e

    @keyword
    def ad_click_element(self, locator: str, timeout: int = 10) -> None:
        """点击元素

        - locator: 定位器
        - timeout: 超时时间
        - return: None
        """
        log.info("点击元素 %s" % locator, also_console=True)
        e = self.ad_find_element(locator, timeout=timeout)
        e.click()

    @keyword
    def ad_click_element_if_exist(self, locator: str, timeout: int = 3):
        """如果元素存在，点击元素

        - locator: 定位器
        - timeout: 超时时间
        - return: element object
        """
        try:
            e = self.ad_find_element(locator, timeout=timeout)
            e.click()
            log.info("元素 %s 存在，已点击" % locator, also_console=True)
            return e
        except UiObjectNotFoundError:
            log.info("元素 {} {}s 不存在，跳过".format(locator, timeout), also_console=True)
        return None

    @keyword
    def ad_input_text(self, locator: str, text: str, timeout: int = 10) -> None:
        """输入文本到元素中

        - locator: 定位器
        - text: 文本
        - timeout: 超时时间
        - return: None
        """
        log.info("点击元素 %s" % locator, also_console=True)
        e = self.ad_find_element(locator, timeout=timeout)
        e.click()
        e.clear_text()
        log.info("输入内容 %s" % repr(text), also_console=True)
        self.session.send_keys(text)
        self.session.set_fastinput_ime(False)
        time.sleep(0.5)
        self.session.press("back")

    @keyword
    def ad_input_text_if_exist(self, locator: str, text: str, timeout: int = 3) -> None:
        """如果元素存在，输入文本到元素中

        - locator: 定位器
        - text: 文本
        - timeout: 超时时间
        - return: None
        """
        e = self.ad_click_element_if_exist(locator, timeout=timeout)
        if e:
            e.clear_text()
            log.info("输入内容 %s" % repr(text), also_console=True)
            self.session.send_keys(text)
            self.session.set_fastinput_ime(False)
            time.sleep(0.5)
            self.session.press("back")

    @keyword
    def ad_input_value(self, locator: str, text: str, timeout: int = 10) -> None:
        """输入文本到元素中

        - locator: 定位器
        - text: 文本
        - timeout: 超时时间
        - return: None
        """
        if timeout == "" or not timeout:
            timeout = 10
        log.info("输入 {} 到元素 {} 中".format(repr(text), locator), also_console=True)
        e = self.ad_find_element(locator, timeout=timeout)
        e.clear_text()
        e.set_text(text)
        time.sleep(0.5)
        self.session.press("back")
