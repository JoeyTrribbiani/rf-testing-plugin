import re

from JLTestLibrary import log
from JLTestLibrary.iso import TLVSubDomains, cfg_8583, deal_8583

console = False


class iso_8583:
    __8583_cfg = None
    __8583_head_cfg = None
    __8583_str = ""
    _8583_dic = {}

    offset = 0
    bitmap = None

    __deal_content_type_funcs = None
    __deal_len_type_funcs = None

    def __init__(self, iso_head_conf=None, iso_conf=None, iso_str=None):
        # tips:iso_conf为空，或者配置错误，劳资都是木有办法玩的。
        assert iso_conf is not None, "iso_conf can not None"
        assert len(cfg_8583.ContentTypes) > 0, "cfg_8583 err "
        assert iso_conf in cfg_8583.ContentTypes, "iso_conf not in cfg_8583"

        self.__deal_content_type_funcs = deal_8583.deal_content_type()
        self.__deal_len_type_funcs = deal_8583.deal_len_type()
        self.__8583_cfg = cfg_8583.ContentTypes[iso_conf]
        # 增加初始化dic
        self._8583_dic = {}
        # 初始化子域 dic
        for domain, value in list(self.__8583_cfg.items()):
            if "has_subdomain" in value and value["has_subdomain"]:
                self._8583_dic.setdefault(str(domain), {})

        if iso_head_conf is not None:
            assert iso_head_conf in cfg_8583.ContentTypes, "iso_head_conf not in cfg_8583"
            self.__8583_head_cfg = cfg_8583.ContentTypes[iso_head_conf]

        if iso_str is not None:
            # unpack
            self.__8583_str = iso_str

    def __gen_bitmap_list(self):
        bitmap_list = []
        index = 1
        for x in self.bitmap:
            b = "%4s" % bin(int(str(x), 16))[2:]
            j = 0
            for y in b:
                if y == "1":
                    bitmap_list.append(index + j)
                j += 1

            index += 4
        return bitmap_list

    def __gen_bitmap(self, set64=False):
        # 排除子域的key，不用计算bitmap
        bitmap_list = [key for key in self._8583_dic if isinstance(key, int) and key > 1]

        if "bitmap" in self.__8583_head_cfg[-2] and self.__8583_head_cfg[-2]["bitmap"] == 1:
            bitmap = "1" + "0" * (self.__8583_head_cfg[-2]["max_len"] - 1)
        else:
            bitmap = "0" * (self.__8583_head_cfg[-2]["max_len"])
        if set64:
            bitmap_list.append(64)

        for x in bitmap_list:
            if x >= 1:
                bitmap = "%s1%s" % (bitmap[: x - 1], bitmap[x:])
        tmp = re.findall(r".{4}", bitmap)
        self.bitmap = "".join([hex(int(c, 2))[2:].upper() for c in tmp])
        log.info("gen bitmap list succ " + str(bitmap_list), also_console=console)
        return self.bitmap

    def __get_info(self, cfg, domain, output=False):
        if domain in cfg:
            cfg_domain = cfg[domain]

            subdomain_60_3 = self._8583_dic.get("60").get("60.3")
            if (
                self._8583_dic.get("39") == "00"
                and self._8583_dic.get("60")
                and subdomain_60_3 in ["001", "003", "004"]
            ):
                # 解析62域，当39域为“00”时必选
                # 当60.3域填写001时包含PIK、MAK，共24字节；
                # 当60.3域填写003时包含PIK、MAK，共40字节；
                # 当60.3域填写004时包含PIK、MAK和TDK，共60字节
                len_func_name = "%s_unpack" % "LLLVAR"
                len_func = getattr(self.__deal_len_type_funcs, len_func_name)
                content_type_func_name = "%s_unpack" % "BCD_UNC"
                content_type_func = getattr(self.__deal_content_type_funcs, content_type_func_name)
            else:
                len_func_name = "%s_unpack" % cfg_domain["len_type"]
                len_func = getattr(self.__deal_len_type_funcs, len_func_name)
                content_type_func_name = "%s_unpack" % cfg_domain["content_type"]
                content_type_func = getattr(self.__deal_content_type_funcs, content_type_func_name)

            len, offset_len = len_func(cfg_domain, self.__8583_str, self.offset)
            self.offset += offset_len

            val, offset_data = content_type_func(self.__8583_str, len, self.offset)
            self.offset += offset_data
            self._8583_dic[domain] = val
            len_val = self.__8583_str[self.offset - offset_data - offset_len : self.offset - offset_data]
            val_data = self.__8583_str[self.offset - offset_data : self.offset]
            if output:
                log.info(
                    "[%02s]  [%07s][%10s] [%04s] : %s %s"
                    % (
                        domain,
                        cfg_domain["content_type"],
                        cfg_domain["len_type"],
                        len_val,
                        val_data,
                        (" ==> %s") % str(val) if val and str(val) not in val_data else "",
                    ),
                    also_console=console,
                )
            return len

    def unpack_sub_body(self, domain, output, domain_len):
        """
        增加解析子域，TLV类型（55域）
        """
        key_list = cfg_8583.SubContentTypes["jlpos_%s" % domain].keys()
        self._8583_dic.setdefault(str(domain), {})
        self.sub_offset = 0

        for sub_domain in key_list:
            sub_domain_val = self._8583_dic[domain][self.sub_offset :]
            if isinstance(sub_domain_val, bytes):
                # 59域A1
                is_start = sub_domain_val.startswith(bytes(sub_domain.upper(), "utf-8"))
            else:
                is_start = sub_domain_val.startswith(sub_domain.upper())
            # print sub_domain, is_start
            if str(domain) in TLVSubDomains and is_start:
                # TLV类型，子域tag在报文中展示
                self.sub_offset += len(sub_domain)
                self.__get_sub_info(domain, sub_domain, output)
            elif str(domain) in TLVSubDomains and not is_start:
                pass
            else:
                # 定长类型，tag不用
                self.__get_sub_info(domain, sub_domain, output)
        return self._8583_dic[str(domain)]

    def __get_sub_info(self, domain, sub_domain, output):
        """
        增加解析子域，TLV类型（55域）
        """
        cfg = cfg_8583.SubContentTypes["jlpos_%s" % domain]
        if cfg:
            cfg_domain = cfg[sub_domain]

            len_func_name = "%s_unpack" % cfg_domain["len_type"]
            len_func = getattr(self.__deal_len_type_funcs, len_func_name)
            content_type_func_name = "%s_unpack" % cfg_domain["content_type"]
            content_type_func = getattr(self.__deal_content_type_funcs, content_type_func_name)

            len, offset_len = len_func(cfg_domain, self._8583_dic[domain], self.sub_offset)
            self.sub_offset += offset_len

            val, offset_data = content_type_func(self._8583_dic[domain], len, self.sub_offset)
            self.sub_offset += offset_data
            if output:
                if val:
                    log.info(
                        "[%04s][%07s][%10s] [%04s] : %s"
                        % (sub_domain, cfg_domain["content_type"], cfg_domain["len_type"], len, val),
                        also_console=console,
                    )
            if val:
                self._8583_dic[str(domain)][sub_domain] = val
            return self._8583_dic[str(domain)]

    def __unpack_head(self, output):
        for domain in range(-6, 0):
            self.__get_info(self.__8583_head_cfg, domain, output)

        self.bitmap = self._8583_dic[-2]

    def __unpack_body(self, output):
        bitmap_list = self.__gen_bitmap_list()
        log.info("get bitmap list succ %s" % bitmap_list, also_console=console)

        for domain in bitmap_list:
            val = self.__get_info(self.__8583_cfg, domain, output)
            if self.__8583_cfg[domain].get("has_subdomain"):
                self.unpack_sub_body(domain, output, val)

    def unpack(self, output=False):
        self.__unpack_head(output)
        self.__unpack_body(output)
        self._8583_dic = {k: v for k, v in self._8583_dic.items() if v}
        return self._8583_dic

    def set_bit(self, t, v):
        self._8583_dic[t] = v

    def __gen_info(self, cfg, domain, output):
        """主域组包

        :param cfg:
        :param domain:
        :return:
        """
        if domain in cfg:
            cfg_domain = cfg[domain]
            data = self._8583_dic[domain]

            len_func_name = "%s_pack" % cfg_domain["len_type"]
            len_func = getattr(self.__deal_len_type_funcs, len_func_name)
            content_type_func_name = "%s_pack" % cfg_domain["content_type"]
            content_type_func = getattr(self.__deal_content_type_funcs, content_type_func_name)

            info = {}
            info["len"] = len_func(cfg_domain, data)
            info["val"] = content_type_func(data)
            if output:
                log.info(
                    "[%02s]  [%07s][%10s] [%04s] : %s %s"
                    % (
                        domain,
                        cfg_domain["content_type"],
                        cfg_domain["len_type"],
                        info["len"],
                        info["val"],
                        ("  ==>  %s" % data) if data and str(data) not in info["val"] else "",
                    ),
                    also_console=console,
                )
            return info["len"] + info["val"]
        else:
            return ""

    def __pack_head(self, output, set64=False):
        self._8583_dic[-2] = self.__gen_bitmap(set64=set64)

        list = []
        pack_list = sorted([key for key in self._8583_dic if key in range(-5, 0)])
        for d in pack_list:
            list.append(self.__gen_info(self.__8583_head_cfg, d, output))
        return list

    def __pack_body(self, output):
        body_list = []
        pack_list = sorted([key for key in self._8583_dic if isinstance(key, int) and key >= 2])
        for d in pack_list:
            body_list.append(self.__gen_info(self.__8583_cfg, d, output))
        return body_list

    def set_sub_bit(self, domain, t, v):
        """
        设置子域
        """
        self._8583_dic[str(domain)][t] = v

    def convert_to_byte(self, data):
        if isinstance(data, str):
            return data.encode("utf-8")
        else:
            return data

    def pack_sub_body(self, domain, output=False):
        """
        增加子域的组包
        """
        body_list = []
        key_list = cfg_8583.SubContentTypes["jlpos_%s" % domain].keys()

        for sub_domain in key_list:
            body_list.append(self.__gen_sub_info(domain, sub_domain, output))
        has_bytes = True in [True for body in body_list if isinstance(body, bytes)]
        if not has_bytes:
            body_str = "".join(body_list)
        else:
            body_str = b""
            for body in body_list:
                if isinstance(body, str):
                    body_str += body.encode("utf-8")
                else:
                    body_str += body
        return body_str

    def __gen_sub_info(self, domain, sub_domain, output):
        """
        增加子域的组包
        """
        cfg = cfg_8583.SubContentTypes["jlpos_%s" % domain]
        if cfg and sub_domain in self._8583_dic[str(domain)]:
            cfg_domain = cfg[sub_domain]
            data = self._8583_dic[str(domain)][sub_domain]
            if not data:
                return ""

            len_func_name = "%s_pack" % cfg_domain["len_type"]
            len_func = getattr(self.__deal_len_type_funcs, len_func_name)
            content_type_func_name = "%s_pack" % cfg_domain["content_type"]
            content_type_func = getattr(self.__deal_content_type_funcs, content_type_func_name)

            info = {}
            info["len"] = len_func(cfg_domain, data)
            info["val"] = content_type_func(data)
            if output:
                log.info(
                    "[%04s][%07s][%10s] [%04s] : %s %s"
                    % (
                        sub_domain,
                        cfg_domain["content_type"],
                        cfg_domain["len_type"],
                        info["len"],
                        info["val"],
                        (f"  ==>  {data}") if data and data != info["val"] else "",
                    ),
                    also_console=console,
                )
            if str(domain) in TLVSubDomains:
                if isinstance(info["val"], bytes):
                    return bytes(sub_domain + info["len"], "utf-8") + info["val"]
                return sub_domain + info["len"] + info["val"]
            else:
                return info["len"] + info["val"]
        else:
            return ""

    def pack(self, output=False, set64=False):
        list = self.__pack_body(output)

        list = self.__pack_head(output, set64=set64) + list

        body = "".join(list)
        body_len = ""
        if "self_len" in self.__8583_head_cfg[-6] and self.__8583_head_cfg[-6]["self_len"] == 1:
            body_len = "%04X" % ((len(body) // 2) + 2)
        else:
            body_len = "%04X" % ((len(body) // 2))
        # return (body_len + body).upper()
        return (body_len + body).lower()
