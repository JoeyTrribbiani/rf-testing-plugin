import binascii


class deal_content_type:
    def BCD_unpack(self, data, len, offset):
        len = len
        padding = 1 if len % 2 else 0
        return (data[offset : offset + len], len + padding)

    def BINARY_unpack(self, data, len, offset):
        len = len // 4
        return (data[offset : offset + len], len)

    def BCD_UNC_unpack(self, data, len, offset):
        len = len * 2
        return (data[offset : offset + len], len)

    def ASCII_unpack(self, data, len, offset):
        len = len * 2
        try:
            return (binascii.a2b_hex(data[offset : offset + len]).decode("gb2312"), len)
        except UnicodeDecodeError:
            if "ff" in data[offset : offset + len]:
                return (binascii.a2b_hex(data[offset : offset + len]).decode("gb2312", errors="replace"), len)
            else:
                try:
                    return (binascii.a2b_hex(data[offset : offset + len]).decode(), len)
                except UnicodeDecodeError:
                    # ascii，其他用法时不是ascii数据
                    return (data[offset : offset + len], len)

    # pack
    def BCD_pack(self, data):
        data_len = len(data)
        padding = "0" if data_len % 2 else ""
        d_data = data + padding
        return d_data

    def BINARY_pack(self, data):
        return data

    def BCD_UNC_pack(self, data):
        return data

    def ASCII_pack(self, data):
        try:
            if isinstance(data, bytes):
                # 59域
                return binascii.b2a_hex(data).decode()
            return binascii.b2a_hex(data.encode("gb2312")).decode()
        except UnicodeEncodeError:
            return binascii.b2a_hex(data.encode()).decode()


class deal_len_type:
    def fixed_unpack(self, cfg, data, offset):
        return (cfg["max_len"], 0)

    def fixed_b_unpack(self, cfg, data, offset):
        return (cfg["max_len"], 0)

    def fixed_ub_unpack(self, cfg, data, offset):
        return (cfg["max_len"], 0)

    def LLVAR_unpack(self, cfg, data, offset):
        len = 2
        data_len = int(data[offset : offset + len])
        assert data_len <= 99, "LLVAR len err"
        return (data_len, len)

    def LLVAR_ASC_unpack(self, cfg, data, offset):
        len = 2 * 2
        data_len = int(binascii.a2b_hex(data[offset : offset + len]).decode())
        assert data_len <= 99, "LLVAR len err"
        return (data_len, len)

    def LLLVAR_unpack(self, cfg, data, offset):
        len = 2 * 2
        data_len = int(data[offset : offset + len])
        assert data_len <= 999, "LLLVAR len err"
        return (data_len, len)

    # 55域
    def LLLVAR_b_unpack(self, cfg, data, offset):
        len = 2 * 2
        data_len = int(data[offset : offset + len])
        assert data_len <= 999, "LLLVAR len err"
        return (data_len, len)

    # 55域子域
    def TLVAR_b_unpack(self, cfg, data, offset):
        bit_len = 2
        # 取L字段，2位
        len_hex = data[offset : offset + bit_len]
        # L字段，每位转2进制连起来
        len_bin = "".join([bin(int(x, 16))[2:].zfill(4) for x in len_hex])
        # 最左bit位（即bit8）为0，表示该L字段占一个字节，它的后续7个bit位（即bit7～bit1）表示子域取值的长度，采用二进制数表示子域取值长度的十进制数
        bit8 = len_bin[:1]
        if bit8 == "0":
            data_len = int(len_bin[2:], 2)
            # print len_bin, data_len
        elif bit8 == "1":
            # 最左bit位（即bit8）为1，表示该L字段不止占一个字节，那么它到底占几个字节由该最左字节的后续7个bit位（即bit7～bit1）的十进制取值表示
            l_len = int(len_bin[2:], 2)
            # TODO 若最左字节为10000010，表示L字段除该字节外，后面还有两个字节
            pass
        else:
            raise Exception("bit8 err")
        assert data_len <= 999, "TLVAR len err"
        return (data_len, bit_len)

    def TLLLVAR_ASC_unpack(self, cfg, data, offset):
        """
        59域子域
        :param cfg:
        :param data:
        :param offset:
        :return:
        """
        len = 3
        data_len = int(data[offset : offset + len])
        assert data_len <= 999, "TLLLVAR_ASC len err"
        return (data_len, len)

    def TLLLVAR_b_unpack(self, cfg, data, offset):
        """
        59域子域
        :param cfg:
        :param data:
        :param offset:
        :return:
        """
        len = 3
        data_len = int(data[offset : offset + len])
        assert data_len <= 999, "TLLLVAR_b len err"
        return (data_len, len)

    def LLLVAR_ub_unpack(self, cfg, data, offset):
        len = 3 * 2
        data_len = int(binascii.a2b_hex(data[offset : offset + len]).decode())
        assert data_len <= 999, "LLLVAR len err"
        return (data_len, len)

    def LLLVAR_ASC_unpack(self, cfg, data, offset):
        len = 2 * 2
        data_len = int(data[offset : offset + len])
        assert data_len <= 999, "LLLVAR len err"
        return (data_len, len)

    # pack
    def fixed_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len == max_len, "fixed len err"
        len_val = ""
        return len_val

    def fixed_ub_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len == max_len * 2, "fixed_b len err"
        len_val = ""
        return len_val

    def fixed_b_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len * 4 == max_len, "fixed_b len err"
        len_val = ""
        return len_val

    def LLVAR_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len <= max_len, "LLVAR len err"
        len_val = "%02d" % data_len
        return len_val

    def LLVAR_ASC_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data) // 2
        assert data_len <= max_len, "LLVAR len err"
        len_val = binascii.b2a_hex(b"%02d" % data_len).decode()
        return len_val

    def LLLVAR_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len <= max_len, "LLLVAR len err"
        len_val = "0%03d" % data_len
        return len_val

    # 55域
    def LLLVAR_b_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data) // 2
        assert data_len <= max_len, "LLLVAR len err"
        len_val = "0%03d" % data_len
        return len_val

    # 55域子域用
    def TLVAR_b_pack(self, cfg, data):
        max_len = cfg["max_len"]
        len_bin_str = bin(len(data) // 2)[2:].zfill(8)
        data_len = int("0b" + len_bin_str[:4], 2) * 10 + int("0b" + len_bin_str[4:], 2)
        assert data_len <= max_len, "TLVAR len err"
        len_val = "%02d" % data_len
        return len_val

    def TLLLVAR_ASC_pack(self, cfg, data):
        """
        59域子域
        :param cfg:
        :param data:
        :return:
        """
        max_len = cfg["max_len"]
        data_len = len(data.encode("gb2312"))
        assert data_len <= max_len, "TLLLVAR_ASC len err"
        len_val = "%03d" % data_len
        return len_val

    def TLLLVAR_b_pack(self, cfg, data):
        """
        59域子域
        :param cfg:
        :param data:
        :return:
        """
        max_len = cfg["max_len"]
        data_len = len(data)
        assert data_len <= max_len, "TLLLVAR_b len err"
        len_val = "%03d" % data_len
        return len_val

    def LLLVAR_ub_pack(self, cfg, data):
        max_len = cfg["max_len"]
        data_len = len(data) // 2
        assert data_len <= max_len, "LLLVAR len err"
        len_val = binascii.b2a_hex(b"%03d" % data_len).decode()
        return len_val

    def LLLVAR_ASC_pack(self, cfg, data):
        """
        59域用
        :param cfg:
        :param data:
        :return:
        """
        max_len = cfg["max_len"]
        data_len = len(data) if isinstance(data, bytes) else len(data.encode("gb2312"))
        assert data_len <= max_len, "LLLVAR_ASC len err"
        len_val = "0%03d" % data_len
        return len_val
