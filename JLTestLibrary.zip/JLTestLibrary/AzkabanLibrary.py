import json
import time

import requests
import urllib3
from robot.api.deco import keyword

from . import log
from .UtilsLibrary import UtilsLibrary

urllib3.disable_warnings()


utils = UtilsLibrary


class AzkabanLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        # 默认 'application/x-www-form-urlencoded'
        self.azka_session = requests.Session()
        self.azka_session.verify = False
        self._session_id = "session.id"
        self.azka_session_id = None
        self.azka_url: str = ""
        self.azka_current_execid = ""

    @keyword
    def azkaban_init_auth(
        self, url: str = "https://172.20.11.23:8443", username: str = "azkaban", password: str = "azkaban"
    ) -> None:
        """azkaban初始化授权

        - url:地址
        - username:用户名
        - password:密码
        """
        data = {"action": "login", "username": username, "password": password}
        log.info(f"请求参数{data}")
        url = url[:-1] if url.endswith("/") else url
        self.azka_url = url
        try:
            resp = self.azka_session.post(self.azka_url, data=data)
            log.info(resp.text)
            res = resp.json()
            if res.get("status") == "success":
                self.azka_session_id = res.get(self._session_id)
        except ValueError as e:
            raise ValueError(e, "登陆异常")

    @keyword
    def azkaban_execute_flow(
        self, project, flow, disabled=None, failure_action="finishCurrent", concurrent_option="skip", flow_override=None
    ):
        """azkaban触发任务

        | init_azkaban_auth |
        | azkaban_execute_flow | agent-profit-task | MposProfit | disabled='["CheckHiveJob","MposProfitJob"]' |
        | azkaban_execute_flow | testproject | testflow | flowOverride='{"demo.beginDate"="2021-11-14","demo.endDate":"2021-11-14"}' |

        - project:
        - flow:
        - disabled:
        - failure_action:finishCurrent, cancelImmediately, finishPossible
        - concurrent_option:ignore, pipeline, skip
        - flow_override:
        """
        overrides = {}
        if isinstance(flow_override, str):
            flow_override = json.loads(flow_override)
        if flow_override:
            for key, value in flow_override.items():
                overrides[f"flowOverride[{key}]"] = value
        data = {
            self._session_id: self.azka_session_id,
            "ajax": "executeFlow",
            "project": project,
            "flow": flow,
            "disabled": disabled,
            "failureAction": failure_action,
            "concurrentOption": concurrent_option,
        }
        data.update(overrides)
        log.info(f"请求参数{data}")
        try:
            resp = self.azka_session.get(self.azka_url + "/executor", params=data)
            log.info(resp.text)
            res = resp.json()
            if res.get("execid"):
                self.azka_current_execid = res.get("execid")
                return self.azka_current_execid
        except Exception as e:
            raise RuntimeError(str(e), "azkaban触发任务异常")

    @keyword
    def azkaban_execute_result(self, execid=None, timeout=180) -> None:
        """azkaban任务状态查询

        - execid:
        - timeout:
        """
        if execid:
            execid = int(execid)
        else:
            execid = self.azka_current_execid
        data = {self._session_id: self.azka_session_id, "ajax": "fetchexecflow", "execid": execid}
        log.info(f"请求参数{data}")
        start_time = time.time()
        need_ended = start_time + timeout
        while True:
            try:
                if not execid or execid == -1:
                    break
                resp = self.azka_session.get(self.azka_url + "/executor", params=data)
                log.info(resp.text)
                res = resp.json()
                status = res.get("status")
                if status in ["SUCCEEDED", "FAILED"]:
                    break
                else:
                    time.sleep(30)
            except Exception as e:
                log.info(str(e), "azkaban任务状态查询异常")
                time.sleep(30)
            if time.time() > need_ended:
                break
