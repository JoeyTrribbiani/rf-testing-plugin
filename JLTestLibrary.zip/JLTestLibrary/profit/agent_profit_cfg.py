from collections import OrderedDict

ProfitCfg = {}

# T_SYSTEM_TRADE_LIST 交易系统原始交易表
ProfitCfg["mpos_4"] = OrderedDict(
    LIST_ID={"desc": "交易流水号"},
    PHYSN={"desc": "机身号"},
    MERCHNO={"desc": "商户号"},
    TRADE_TIME={"desc": "交易时间"},
    RATE={"desc": "费率", "optional": True},
    AMOUNT={"desc": "交易金额"},
    FEE={"desc": "交易金额"},
    SETT_FEE={"desc": "结算费率", "optional": True},
    CARD_TYPE={"desc": "银行卡类型"},
    COST={"desc": "成本"},
    CARD_NO={"desc": "卡号"},
    BIZ_TYPE={"desc": "交易大类"},
    SUB_BIZ_TYPE={"desc": "交易小类"},
    WITHDRAW_FEE={"desc": "提现手续费"},
    STATUS={"desc": "状态，用于表示是否已计算过分润，1=未计算，2=已计算", "optional": True},
    CREATE_TIME={"desc": "导入时间", "optional": True},
    BUSINESS_TYPE={"desc": "业务类型，1表示立刷", "optional": True},
    TRADEFLAG={"desc": "交易标记", "optional": True},
    PHYSN_TYPE={"desc": "机型", "optional": True},
)
# T_MPOS_DEPOSIT_FEE_BILL
ProfitCfg["mpos_deposit"] = OrderedDict(
    LIST_ID={"desc": "流水号"},
    MERCHNO={"desc": "商户号"},
    PHYSN={"desc": "机具号"},
    AMOUNT={"desc": "交易金额"},
    FEE={"desc": "手续费", "optional": True},
    TRADE_TIME={"desc": "交易时间"},
    CARD_NO={"desc": "卡号"},
    SOURCE={"desc": "来源,0--商服,1--OEM"},
    SUB_BIZ_TYPE={"desc": "交易小类"},
    WITHHOLD_CYCLE={"desc": "扣费周期 0:一次性 1:按月 2:按季度 3:按年"},
    WITHHOLD_FREQ={"desc": "扣费频次 1：一个周期一次 2：两个周期一次 3：三个周期一次"},
    ORI_LIST_ID={"desc": "原始订单号", "optional": True},
    ORI_STATUS={"desc": "原始订单状态，4-已退", "optional": True},
)
# T_MPOS_MEMBERSHIP_FEE_BILL 会员费流水表
ProfitCfg["mpos_member"] = OrderedDict(
    LIST_ID={"desc": "流水号"},
    MERCHNO={"desc": "商户号"},
    PHYSN={"desc": "机身号"},
    AMOUNT={"desc": "交易金额"},
    FEE={"desc": "手续费", "optional": True},
    TRADE_TIME={"desc": "交易时间"},
    TYPE={"desc": "1--首购，0--续费"},
    CARD_NO={"desc": "卡号"},
    START_DATE={"desc": "会员生效时间"},
    END_DATE={"desc": "会员结束时间"},
    MONTHS={"desc": "会员费购买时长"},
    SOURCE={"desc": "来源,0--商服,1--OEM", "optional": True},
)

# TMP_POSP_TRADE_LIST
ProfitCfg["posp_1"] = OrderedDict(
    LIST_ID={"desc": "流水号"},
    PHYSN={"desc": "机身号"},
    MERCHNO={"desc": "商户号"},
    BIZ_TYPE={"desc": "交易大类"},
    TRADE_TIME={"desc": "交易时间"},
    RATE={"desc": "费率", "optional": True},
    AMOUNT={"desc": "交易金额"},
    FEE={"desc": "手续费"},
    ISTOP={"desc": ""},
    CARD_TYPE={"desc": "银行卡类型"},
    COST={"desc": "成本"},
    TOTAL_DATE={"desc": "统计日期", "optional": True},
    TRADE_FLAG={"desc": ""},
    ORDER_FEE={"desc": ""},
    TYPE={"desc": "1--首购，0--续费"},
    CLEAR_DATE={"desc": ""},
    ORI_LIST_ID={"desc": "原始订单号", "optional": True},
    CHAN_AMT={"desc": "", "optional": True},
    ACC_FLAG={"desc": ""},
    ROOT_USER_ID={"desc": ""},
    INSTALL_PERIOD={"desc": "", "optional": True},
    MONTH_MARK={"desc": ""},
    ORI_FEE={"desc": "", "optional": True},
    CARD_NO={"desc": "卡号", "optional": True},
    RATE_MARK={"desc": "微信支付结算规则ID,756、751--特殊行业1,757--特殊行业2,767--特殊行业3", "optional": True},
)
# T_SERVICE_FEE_LIST
ProfitCfg["posp_server"] = OrderedDict(
    LIST_ID={"desc": "流水ID"},
    PHYSN={"desc": "机具号"},
    MERCHNO={"desc": "商户号"},
    AMOUNT={"desc": "金额"},
    TRADE_TIME={"desc": "交易时间"},
    START_DATE={"desc": "服务费开始日期"},
    END_DATE={"desc": "服务费结束日期"},
    STATUS={"desc": "状态，1-成功，2-失败"},
    BIZ_TYPE={"desc": "交易大类"},
    ORI_LIST_ID={"desc": "原始订单号", "optional": True},
)

# T_POSP_WITHDRAW_LIST POS+提现记录表
ProfitCfg["posp_3"] = OrderedDict(
    LIST_ID={"desc": "流水ID"},
    PHYSN={"desc": "机身号", "optional": True},
    MERCHNO={"desc": "商户号"},
    WITHDRAW_TIME={"desc": "提现时间"},
    AMOUNT={"desc": "提现金额"},
    FEE={"desc": "提现手续费"},
    COST={"desc": "提现成本48490000=>银联 0.5/笔,03050000=>民生　1.55/万,04100000=>平安　1.3/万"},
    CHANNEL_ID={"desc": "渠道ID,48490000=>银联,03050000=>民生,04100000=>平安,03110000=>恒丰,03110001=>恒丰T1"},
    CYCLE={"desc": "结算周期0=T0，1=T1"},
    ACCOUNT_TYPE={"desc": "账户类型0=对私，1=对公"},
    MONTH_MARK={"desc": "0--日结,1--月结商户,2--月结优惠", "optional": True},
    ORI_FEE={"desc": "原始手续费", "optional": True},
)
