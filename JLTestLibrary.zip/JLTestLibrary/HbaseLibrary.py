import datetime
import json
import random
import re
import time
import traceback
import warnings
from decimal import Decimal
from typing import List, Union

import happybase
from robot.api.deco import keyword
from thriftpy2.transport.base import TTransportException

from . import log
from .DBLibrary import DBLibrary
from .UtilsLibrary import UtilsLibrary
from .UtilsMsg import UtilsMsg

utils = UtilsLibrary


class HbaseLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.hbase_conn = None
        self.batch_size = 500

    @keyword
    def hbase_init_host(self, hbase_url: str = "172.20.7.37:9090"):
        """初始化hbase连接地址，这里的地址是hbase thrift server的地址
        | hbase_init_host | # 默认为172.20.7.37:9090 |
        | hbase_init_host | xxx.xxx.xxx.xxx | # 默认端口为9090 |
        | hbase_init_host | xxx.xxx.xxx.xxx:xxxx | # 指定端口 |
        """
        if ":" not in hbase_url:
            host = hbase_url
            port = 9090
        else:
            host = hbase_url.split(":")[0]
            port = int(hbase_url.split(":")[-1])
        self.hbase_conn = happybase.Connection(host=host, port=port, autoconnect=False)

    @keyword
    def hbase_insert_data(
        self,
        table_name: str,
        data: Union[str, dict],
        row_key: str = "",
        update_data: Union[str, dict] = {},
    ) -> dict:
        """
        插入hbase数据
        | hbase_init_host |
        | hbase_insert_data | table_name='XDATA:T_ACC_TRANS_LIST' | data=${t_acc_trans_list_data_hbase} |
        - table_name: 插入数据的hbase名
        - data: 插入hbase表数据内容
        - row_key: 一般需要与对应es索引中的id保持一致
        - update_data: 需要替换数据的字段kv

        - return: 返回插入结果
        """
        insert_data = UtilsMsg.str_to_dict(data)
        if update_data:
            update_data = UtilsMsg.str_to_dict(update_data)
            insert_data.update(update_data)
        if not row_key:
            row_key = '%s%s' % (str(time.strftime("%Y%m%d%H%M%S")), str(random.randint(1, 10)))
        log.info("可以使用命令查询已插入的数据:", f"get '{table_name}','{row_key}'")
        try:
            self.hbase_conn.open()
            self.hbase_conn.table(table_name).put(row=row_key, data=insert_data)
            self.hbase_conn.close()
            ret = {"ret_code": "00", "ret_msg": "插入数据成功"}
        except TTransportException:
            log.error("hbase写入失败,请检查插入数据的字段名是否在hbase表中存在，一般字段名以cf:开头!")
            ret = {"ret_code": "02", "ret_msg": "数据插入失败，请检查字段名是否存在！"}
        except AttributeError:
            log.error("hbase写入失败,请先初始化hbase连接，使用关键字,init_hbase")
            ret = {"ret_code": "03", "ret_msg": "请先初始化hbase连接"}
        return ret

    @keyword
    def hbase_scan_table(self, table_name: str, term: Union[str, dict] = {}) -> list:
        """
        插入hbase数据
        | hbase_init_host |
        | hbase_scan_table | table_name='XDATA:T_ACC_TRANS_LIST' | term={"cf:R_COMPANY_NAME":"嘉联支付有限公司","cf:MER_NO":"849584059430061"} |
        - table_name: 插入数据的hbase名
        - term:查询条件，
        - return:返回符合条件的数据
        """
        table_conn = self.hbase_conn.table(table_name)
        term_dict = UtilsMsg.str_to_dict(term)
        term_keys = term_dict.keys()
        log.info("扫描全表数据")
        # TODO:
        # - 应该使用筛选参数，而不是查出全表数据再过滤
        self.hbase_conn.open()
        rets = self.hbase_rows_deal(table_conn.scan(batch_size=self.batch_size))
        self.hbase_conn.close()
        result = []
        for i in rets:
            for j in term_keys:
                if i.get(j) != term_dict[j]:
                    break
            else:
                result.append(i)
        return result

    @keyword
    def hbase_get_row(self, table_name: str, row_key: str) -> dict:
        """
        | hbase_init_host |
        | hbase_get_row | table_name=XDATA:T_AGENT_MERCH_REL | row_key=7_74003495048594800000 |

        - table_name：查询表名
        - row_key：查询单行row_key
        """
        self.hbase_conn.open()
        table = self.hbase_conn.table(table_name)
        result = self.hbase_row_deal(table.row(row_key))
        self.hbase_conn.close()
        return result

    @keyword
    def hbase_get_rows(self, table_name: str, row_keys: Union[str, list]):
        """
        | hbase_init_host |
        | hbase_get_rows | table_name=XDATA:T_AGENT_MERCH_REL | row_keys=["7_74003495048594800000","5_Z00A4495403294800000"] |

        - table_name：查询表名
        - row_key：查询多行指定row_key数据
        """
        if isinstance(row_keys, str):
            row_keys = json.loads(row_keys)
        self.hbase_conn.open()
        table = self.hbase_conn.table(table_name)
        result = self.hbase_rows_deal(table.rows(row_keys))
        self.hbase_conn.close()
        return result

    @keyword
    def hbase_row_deal(self, row_data):
        """
        处理查询hbase返回单行数据
        """
        result = {}
        if bool(row_data) == False:
            log.info("查无数据")
        else:
            # 处理返回数据
            for key, value in row_data.items():
                result[key.decode()] = value.decode()
        return result

    @keyword
    def hbase_rows_deal(self, rows_data):
        """
        处理查询hbase返回多行数据
        """
        result = []
        for i in rows_data:
            result.append(self.hbase_row_deal(i[1]))
        return result

    @keyword
    def ensure_data_insert_from_oracle_to_hbase(self, table_name, row_key, waiting_seconds):
        """检验row_key对应的数据是否成功插入

        - table_name: 表名，如XDATA:T_FULL_TRADE_BILL_202207
        - row_key: 列主键，通过前缀匹配数据库
        - waiting_second: 至多的等待时长，单位为秒，如3
        """
        start_time = time.time()

        self.hbase_conn.open()
        while time.time() < start_time + waiting_seconds:
            table = self.hbase_conn.table(table_name)
            k = table.scan(row_prefix=row_key.encode("utf-8"))

            if len(list(k)) != 0:
                return True
        self.hbase_conn.close()
        return False

    @keyword
    def hbase_insert_data_with_batch(self, table_name: str, datas: List, row_keys: List = []):
        """
        插入hbase数据
        | hbase_init_host |
        | hbase_insert_data | table_name='XDATA:T_ACC_TRANS_LIST' | data=${t_acc_trans_list_data_hbase} |
        - table_name: 插入数据的hbase名
        - data: 插入hbase表多条数据内容
        - row_key: 一般需要与对应es索引中的id保持一致
        - update_data: 需要替换数据的字段kv

        - return: 返回插入结果
        """
        self.hbase_conn.open()
        batch = self.hbase_conn.table(table_name).batch(batch_size=self.batch_size)

        for i in range(len(datas)):
            data = datas[i]
            row_key = row_keys[i]
            data = UtilsMsg.str_to_dict(data)

            if not row_key:
                row_key = "%s%s" % (str(time.strftime("%Y%m%d%H%M%S")), str(random.randint(1, 10)))
            log.info("可以使用命令查询已插入的数据:", f"get '{table_name}','{row_key}'")
            batch.put(row=row_key, data=data)
        try:
            batch.send()
            self.hbase_conn.close()
        except AttributeError:
            log.error("hbase写入失败,请先初始化hbase连接，使用关键字,init_hbase")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise e

    @keyword
    def hbase_insert_data_with_batch_trade(
        self,
        mer_no="84931015812A00N",
        term_no="60016260",
        start_trans_date="2022-09-25",
        end_trans_date="2022-09-26",
        delete_history=True,
    ):
        """
        往hbase里批量插入交易账单相关数据
        - param mer_no: 商户号
        - param term_no: 终端号
        - param trans_date: 交易日期
        - param delete_history: 插入前是否删除之前的旧数据
        - return: 无
        """
        from .EsLibrary import EsLibrary

        es = EsLibrary()
        es.es_init_host()

        insert_datas, insert_ids = es.mock_data_to_es_trade(
            lmer_no=mer_no,
            lterm_no=term_no,
            start_trans_date=start_trans_date,
            end_trans_date=end_trans_date,
            delete_history=delete_history,
        )

        es_index_list = list()
        for key in insert_datas:
            es_index_list.append(key)
        es_index_tuple = tuple(set(es_index_list))

        # 查询数据库的路由表
        mysql = DBLibrary()
        mysql.connect_to_database("mysql", "root/xdata#1#2#3#0929@172.20.7.33:3306/xdata")

        index_route_config = mysql.query_to_dict(
            "select index_real_name, hbase_table_name from t_index_route_config where t_index_route_config.index_real_name like '%t_mer_trans%'"
        )
        mysql.connect_close()

        es_and_hbase_relation = dict()
        for i in range(len(es_index_tuple)):
            for j in range(len(index_route_config)):
                if index_route_config[j]["index_real_name"] == es_index_tuple[i]:
                    if index_route_config[j]["hbase_table_name"]:
                        es_and_hbase_relation[es_index_tuple[i]] = index_route_config[j]["hbase_table_name"]
                    else:
                        es_and_hbase_relation[es_index_tuple[i]] = "XDATA:T_FULL_TRADE_BILL"
            # 解决路由表没有，返回默认值的情况
            if es_index_tuple[i] not in es_and_hbase_relation:
                es_and_hbase_relation[es_index_tuple[i]] = "XDATA:T_FULL_TRADE_BILL"

        log.info("查询路由表后得出的es与hbase的映射关系", es_and_hbase_relation)

        count = 0
        for key in insert_datas:
            count = count + 1
            hbase_datas = list()
            for i in range(len(insert_datas[key])):
                amt = random.randint(1000, 1000000)
                discount_amt = random.randint(1, 900)
                fee_amt = random.randint(1, 100)
                real_amt = amt - discount_amt - fee_amt

                es_data = insert_datas[key][i]

                tmp_hbase_data = {
                    "cf:ORDER_ID": es_data["ORDER_ID"],
                    "cf:TRANS_TIME": es_data["TRANS_TIME"],
                    "cf:ORI_AMT": str(amt),
                    "cf:AMT": str(amt),
                    "cf:DISCOUNT_AMT": str(discount_amt),
                    "cf:REAL_AMT": str(real_amt),
                    "cf:FEE_AMT": str(fee_amt),
                    "cf:LMER_NAME": "自动化测试插入",
                    "cf:LMER_NO": es_data["LMER_NO"],
                    "cf:LTERM_NO": es_data["LTERM_NO"],
                    "cf:RET_MSG": es_data["RET_MSG"],
                    "cf:BUSI_SUB_TYPE": es_data["BUSI_SUB_TYPE"],
                    "cf:FEE_CALC_TYPE": es_data["FEE_CALC_TYPE"],
                    "cf:STATUS": "2",
                    "cf:PMER_NAME": "自动化测试打印商户名",
                    "cf:BUSI_TYPE": "1003",
                    "cf:ORI_ORDER_ID": es_data["ORDER_ID"],
                    "cf:RET_CODE": "00",
                    "cf:ACCOUNTING_DATE": "2022-09-25",
                    "cf:CARD_NO": "6222621310000662383",
                    "cf:AUTH_NO": "1234",
                    "cf:REMARK": "自动化测试数据",
                }
                hbase_datas.append(json.dumps(tmp_hbase_data))
            log.info(f"第{count}次开始往hbase里插数据...")
            log.info("所插入hbase的表名为{}".format(es_and_hbase_relation[key]))
            self.hbase_insert_data_with_batch(es_and_hbase_relation[key], hbase_datas, insert_ids[key])

    @keyword
    def hbase_insert_data_with_batch_fund(
        self, mer_no="84931015812A00N", start_trans_date="2022-09-27", end_trans_date="2022-09-28", delete_history=True
    ):
        """
        往hbase里批量插入资金账单相关的数据
        - param mer_no: 商户号
        - param trans_date: 交易日期
        - param delete_history: 插入前是否对旧数据进行删除
        - return: 无
        """
        from .EsLibrary import EsLibrary

        es = EsLibrary()
        es.es_init_host()

        insert_datas, insert_ids = es.mock_data_to_es_fund(
            lmer_no=mer_no,
            start_trans_date=start_trans_date,
            end_trans_date=end_trans_date,
            delete_history=delete_history,
        )
        log.info("开始往hbase里插数据...")
        hbase_datas = list()
        for i in range(len(insert_datas)):
            es_data = insert_datas[i]

            date = datetime.datetime.strptime(es_data["BUSINESS_DATE"], "%Y%m%d")

            hour = random.randint(0, 23)
            second = random.randint(0, 59)
            date = date.replace(hour=hour)
            date = date.replace(second=second)
            tmp_hbase_data = {
                "cf:BUSINESS_DATE": es_data["BUSINESS_DATE"],
                "cf:AMT": es_data["AMT"],
                "cf:ORI_AMT": es_data["AMT"],
                "cf:FEE_AMT": es_data["FEE_AMT"],
                "cf:LIQUIDATION_AMT": es_data["LIQUIDATION_AMT"],
                "cf:TRANS_TIME": date.strftime("%Y%m%d%H%M%S"),
                "cf:TERM_NO": "1234",
                "cf:ORDER_ID": es_data["ORDER_ID"],
                "cf:ORI_ORDER_ID": es_data["ORDER_ID"],
                "cf:ACC_CREATE_TIME": date.strftime("%Y%m%d%H%M%S"),
                "cf:BUSI_SUB_TYPE": es_data["BUSI_SUB_TYPE"],
            }
            hbase_datas.append(json.dumps(tmp_hbase_data))
        log.info("所插入hbase的表名为SETTLE:T_CLEAR_TRANS_LIST")
        self.hbase_insert_data_with_batch("SETTLE:T_CLEAR_TRANS_LIST", hbase_datas, insert_ids)

    @keyword
    def transfer_data_from_oracle_to_hbase(self, oracle_url, merch_no, trans_date):
        """将oracle数据库中的数据大批量自动转移到hbase数据库

        - oracle_url: oracle数据库的连接地址，如 accp_user/123456@172.20.34.10:1521/posplu
        - merch_no: 要完成大批量数据转移的商户号，如 84931015812A00N
        - trans_date: 该商户号的交易年月日，如 2022-08-11
        """

        db = None
        try:
            date = datetime.datetime.strptime(trans_date, "%Y-%m-%d")  # 通过传入的交易年月，获得要插入数据库的表的表名
            table_name_postfix = "%04d%02d" % (date.year, date.month)
            table_name = "XDATA:T_FULL_TRADE_BILL_" + table_name_postfix

            db = DBLibrary()  # 构建和oracle数据库的链接
            db.connect_to_database("cx_Oracle", oracle_url)
            select_from_t_ofl_l_trans_list_sql = """
                            select to_char(CREATE_TIME,'yyyy-mm-dd') ACCOUNTING_DATE,
                               ACCOUNT_FLAG,
                               AGENT_ID AGT_ID,
                               AMOUNT AMT,
                               BUSI_SUB_TYPE,
                               BUSI_TYPE,
                               CARD_NO,
                               CHANNEL_NO CHN_NO,
                               DISCOUNT_AMOUNT DISCOUNT_AMT,
                               FEE_AMOUNT FEE_AMT,
                               FEE_CALC_TYPE,
                               IS_INTERNAL_CARD INTERNAL_FLAG,
                               LMERCH_NAME LMER_NAME,
                               LMERCH_NO LMER_NO,
                               LREFER_NO,
                               LTERM_NO,
                               LVOUCH_NO,
                               ORDER_ID,
                               ORI_AMOUNT ORI_AMT,
                               ORI_ORDER_ID,
                               PRINT_MERCH_NAME PMER_NAME,
                               QR_PAY_CODE,
                               STATUS,
                               TERM_SN,
                               TRANS_TIME,
                               UPDATE_TIME,
                               USER_ORDER_ID
                               from T_OFL_L_TRANS_LIST where LMERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
                        """ % (
                merch_no,
                trans_date,
            )  # SQL语句，选出同年同月同日的所有数据

            select_from_t_qr_pay_order_sql = """
                select to_char(CREATE_TIME, 'yyyy-mm-dd') ACCOUNTING_DATE,
                   AMOUNT AMT,
                   APP_ID APPID,
                   BUSI_SUB_TYPE,
                   BUSI_TYPE,
                   DISCOUNT_AMOUNT DISCOUNT_AMT,
                   MERCH_NO LMER_NO,
                   TERM_NO LTERM_NO,
                   ORDER_ID,
                   ORI_ORDER_ID,
                   STATUS,
                   TRANS_TIME,
                   UPDATE_TIME
                   from T_QR_PAY_ORDER
                where MERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )

            select_from_t_guarantee_trans_list_sql = """
                select to_char(CREATE_TIME, 'yyyy-mm-dd') ACCOUNTING_DATE,
                   AMOUNT AMT,
                   BUSI_SUB_TYPE,
                   BUSI_TYPE,
                   CHANNEL_NO CHN_NO,
                   FEE_AMOUNT FEE_AMT,
                   MERCH_NAME LMER_NAME,
                   MERCH_NO LMER_NO,
                   ORDER_ID,
                   ORI_AMOUNT ORI_AMT,
                   ORI_ORDER_ID,
                   SOURCE,
                   STATUS,
                   TERM_SN,
                   TRANS_TIME,
                   UPDATE_TIME
                   from T_GUARANTEE_TRANS_LIST
                where MERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )

            datas = []
            row_keys = []

            log.info(re.sub("\s+", " ", select_from_t_ofl_l_trans_list_sql.replace("\n", "")))
            data_t_ofl_l_trans_list = db.query_to_dict(select_from_t_ofl_l_trans_list_sql)  # 发送请求

            for each_row in data_t_ofl_l_trans_list:
                es_json = {}

                for hbase_key in each_row:
                    if each_row[hbase_key] is not None:
                        es_json["cf:" + hbase_key.upper()] = str(each_row[hbase_key])

                es_data_str = str(es_json).replace("'", '"')
                row_key = es_json["cf:ORDER_ID"][::-1] + "_" + es_json["cf:LMER_NO"]
                datas.append(es_data_str)
                row_keys.append(row_key)
                # self.hbase_insert_data(table_name=table_name, row_key=row_key, data=es_data_str)

            log.info(re.sub("\s+", " ", select_from_t_qr_pay_order_sql.replace("\n", "")))
            data_t_qr_pay_order = db.query_to_dict(select_from_t_qr_pay_order_sql)  # 发送请求

            for each_row in data_t_qr_pay_order:
                es_json = {}

                for hbase_key in each_row:
                    if each_row[hbase_key] is not None:
                        es_json["cf:" + hbase_key.upper()] = str(each_row[hbase_key])

                es_data_str = str(es_json).replace("'", '"')
                row_key = es_json["cf:ORDER_ID"][::-1] + "_" + es_json["cf:LMER_NO"]
                datas.append(es_data_str)
                row_keys.append(row_key)
                # self.hbase_insert_data(table_name=table_name, row_key=row_key, data=es_data_str)

            log.info(re.sub("\s+", " ", select_from_t_guarantee_trans_list_sql.replace("\n", "")))
            data_t_guarantee_trans_list = db.query_to_dict(select_from_t_guarantee_trans_list_sql)  # 发送请求

            for each_row in data_t_guarantee_trans_list:
                es_json = {}

                for hbase_key in each_row:
                    if each_row[hbase_key] is not None:
                        es_json["cf:" + hbase_key.upper()] = str(each_row[hbase_key])

                es_data_str = str(es_json).replace("'", '"')
                row_key = es_json["cf:ORDER_ID"][::-1] + "_" + es_json["cf:LMER_NO"]
                datas.append(es_data_str)
                row_keys.append(row_key)
                # self.hbase_insert_data(table_name=table_name, row_key=row_key, data=es_data_str)

            self.hbase_insert_data_with_batch(table_name=table_name, datas=datas, row_keys=row_keys)
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"从oracle数据库转移大数据到hbase数据库失败！: {str(e)}")
        finally:
            if db is not None:
                db.connect_close()

    @keyword
    def get_data_source_fund(
        self,
        start_time,
        end_time,
        es_url="http://172.20.11.23:9200,http://172.20.20.183:9200,http://172.20.20.184:9200",
        doc_type="xdata",
        hbase_name="SETTLE:T_CLEAR_TRANS_LIST",
    ):
        """
        获取资金账单的源数据
        - param start_time:开始时间  如2022-01-01
        - param end_time: 结束时间   如2022-01-31
        - param es_url: es的地址
        - param es_name: 所查询的es表名
        - param doc_type: 类型
        - param hbase_name: 所查询的hbase的表名
        - return: 返回查询到的数据
        """

        # 获取查询时间
        from JLTestLibrary import RequestLibrary

        request = RequestLibrary()

        # url = "http://172.20.20.82:35519/clearbill"
        url = "http://clear-settle-merch-bill-svc.manage:8080/clearbill"
        req_data = '{{"command_id":"query_clear_acc_date_new","end_busi_date":"{}","limit":999,"merch_no":"84931015812A00N","offset":0,"start_busi_date":"{}"}}'.format(
            end_time, start_time
        )

        resp = request.http_post_api(url, req_data=req_data)
        start_busi_date = resp["start_busi_date"]
        end_busi_date = resp["end_busi_date"]
        start_acc_date = resp["start_acc_date"]
        end_acc_date = resp["end_acc_date"]
        start_settle_date = resp["start_settle_date"]
        end_settle_date = resp["end_settle_date"]

        query = '{{"bool":{{"must":[{{"term":{{"MERCH_SHOW_MARK":{{"value":"0","boost":1.0}}}}}},{{"term":{{"COLLECT_MERCH_NO":{{"value":"84931015812A00N","boost":1.0}}}}}},{{"range":{{"BUSINESS_DATE":{{"from":"{}","to":"{}","include_lower":true,"include_upper":true,"boost":1.0}}}}}},{{"range":{{"ACC_DATE":{{"from":"{}","to":"{}","include_lower":true,"include_upper":true,"boost":1.0}}}}}},{{"range":{{"LIQUIDATION_DATE":{{"from":"{}","to":"{}","include_lower":true,"include_upper":true,"boost":1.0}}}}}}],"adjust_pure_negative":true,"boost":1.0}}}}'.format(
            start_busi_date, end_busi_date, start_acc_date, end_acc_date, start_settle_date, end_settle_date
        )

        start_date = datetime.datetime.strptime(start_settle_date, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end_settle_date, "%Y-%m-%d")

        start_quarter = start_date.month // 3 if start_date.month % 3 == 0 else start_date.month // 3 + 1
        end_quarter = end_date.month // 3 if end_date.month % 3 == 0 else end_date.month // 3 + 1
        start = str(start_date.year) + str(start_quarter)
        end = str(end_date.year) + str(end_quarter)

        int_start = int(start)
        int_end = int(end)
        profix_list = [int_start, int_end]

        # 获取今年的年份
        year = datetime.date.today().year
        last_year = year - 1
        year_min_quarter = int(str(year) + "1")
        last_year_max_quarter = int(str(last_year) + "4")

        while int_start < last_year_max_quarter and int_start < int_end:
            profix_list.append(int_start + 1)
            int_start = int_start + 1
        while int_end > year_min_quarter and int_end > int_start:
            profix_list.append(int_end - 1)
            int_end = int_end - 1

        es_table_name_list = []
        for i in profix_list:
            es_table_name_list.append("t_clear_trans_list_" + str(i))
        es_table_name_list = list(set(es_table_name_list))
        log.info("获取数据源,根据清算时间生成的es待查询的表名", es_table_name_list)
        from .EsLibrary import EsLibrary

        es = EsLibrary()
        es.es_init_host(es_url)

        hbase_rowkeys = []
        for i in range(len(es_table_name_list)):
            select_result = es.es_search_datas(es_table_name_list[i], doc_type, query)
            for j in range(len(select_result)):
                tmp_dict = select_result[j]
                hbase_rowkeys.append(tmp_dict["_id"])
        hbase_rowkeys = list(set(hbase_rowkeys))
        log.info("es的查询语句", query)
        # 有可能es里没有数据
        if not hbase_rowkeys:
            log.info("所查询的es中没有ids数据，结束接下来的hbase查询操作")
            return json.dumps({"data": []}, ensure_ascii=False)

        log.info("开始查询hbase...")
        log.info("所查询hbase的表名", hbase_name)
        hbase_result = self.hbase_get_rows(hbase_name, hbase_rowkeys)

        # 处理hbase查询出来的数据
        key_dict = {
            "cf:BUSINESS_DATE": "交易日期",
            "cf:AMT": "交易金额（元）",
            "cf:ORI_AMT": "原交易金额（元）",
            "cf:FEE_AMT": "手续费（元）",
            "cf:LIQUIDATION_AMT": "应付金额（元）",
            "cf:TRANS_TIME": "交易时间",
            "cf:TERM_NO": "终端号",
            "cf:ORDER_ID": "订单号",
            "cf:ORI_ORDER_ID": "原始订单号",
            "cf:ACC_CREATE_TIME": "记账时间",
        }

        money_key_list = ["cf:ORI_AMT", "cf:AMT", "cf:LIQUIDATION_AMT", "cf:FEE_AMT"]
        time_key_list = ["cf:TRANS_TIME", "cf:ACC_CREATE_TIME", "cf:BUSINESS_DATE"]
        data_list = []
        for i in range(len(hbase_result)):
            pending_dict = hbase_result[i]
            solved_dic = {}
            for key in pending_dict:
                if key in key_dict:
                    if key in money_key_list:
                        solved_dic[key_dict[key]] = float(pending_dict[key]) / 100

                    elif key in time_key_list:
                        if key == "cf:BUSINESS_DATE":
                            timeArray = time.strptime(pending_dict[key], "%Y%m%d")
                            otherstyleTime = time.strftime("%Y-%m-%d", timeArray)
                        else:
                            timeArray = time.strptime(pending_dict[key], "%Y%m%d%H%M%S")
                            otherstyleTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
                        solved_dic[key_dict[key]] = otherstyleTime
                    else:
                        solved_dic[key_dict[key]] = pending_dict[key]
            data_list.append(solved_dic)

        # 生成表头数据

        sum_amt = 0
        sum_fee_amt = 0
        sum_liquidation_amt = 0
        for i in range(len(data_list)):
            item_dict = data_list[i]
            sum_amt = sum_amt + Decimal(str(item_dict["交易金额（元）"]))
            sum_fee_amt = sum_fee_amt + Decimal(str(item_dict["手续费（元）"]))
            sum_liquidation_amt = sum_liquidation_amt + Decimal(str(item_dict["应付金额（元）"]))

        sum_trade_count = Decimal(len(data_list))
        data_source_dict = {}
        data_source_dict["交易金额（元）:"] = sum_amt
        data_source_dict["手续费（元）:"] = sum_fee_amt
        data_source_dict["应付金额（元）:"] = sum_liquidation_amt
        data_source_dict["交易笔数："] = sum_trade_count
        data_source_dict["data"] = data_list

        return data_source_dict

    @staticmethod
    @keyword
    def compare_of_fund(data_source, excel):
        """
        资金账单的对比方法
        - param data_source:源数据
        - param excel: 平台下载出来的数据
        - return: 对比结果
        """
        # 断言标志位
        count = 0
        # 设置排错信息
        fail_message = []

        # 对比表头数据
        for key in data_source:
            if key != "data":
                assert key in data_source and key in excel, f"在进行表头数据对比时{key}这个key在源数据或excel中不存在"
                if data_source[key] != Decimal(excel[key]):
                    count = count + 1
                    fail_message.append(f"在进行表头数据对比时{key}源数据与excel不相等，源数据为{data_source[key]}，excel数据为{excel[key]}")
                else:
                    log.info("对比成功", "对比的表头数据为", key)

        data_source_list = data_source["data"]
        excel_list = excel["data"]

        money_key_list = ["原始交易金额（元）", "交易金额（元）", "应付金额（元）", "手续费（元）"]

        # 先寻找excel_list中对应的下标  期望是一定可以找到
        for i in range(len(data_source_list)):
            data_source_tmp_dict = data_source_list[i]

            excel_index = 99999999
            for j in range(len(excel_list)):
                if data_source_tmp_dict["订单号"] in excel_list[j]["订单号"]:
                    excel_index = j
                    break
            try:
                for key in data_source_list[i]:
                    if data_source_list[i][key] == excel_list[excel_index][key]:
                        log.info("对比成功", "对比的订单号为", data_source_list[i]["订单号"], "对比的列为", key)
                    elif (
                        key in money_key_list and data_source_list[i][key] - float(excel_list[excel_index][key]) == 0.0
                    ):
                        log.info("对比成功", "对比的订单号为", data_source_list[i]["订单号"], "对比的列为", key)
                    else:
                        log.info(
                            "对比失败",
                            "对比的订单号为",
                            data_source_list[i]["订单号"],
                            "对比的列为",
                            key,
                            "源数据的列值",
                            data_source_list[i][key],
                            "excel的列值",
                            excel_list[excel_index][key],
                        )
                        count = count + 1
                        fail_message.append(
                            "对比失败，对比的订单号为{}，对比的列为{}，源数据的列值为{}，excel的列值为{}".format(
                                data_source_list[i]["订单号"], key, data_source_list[i][key], excel_list[excel_index][key]
                            )
                        )
            except IndexError:
                count = count + 1
                fail_message.append("excel缺少这行数据order_id为{}".format(data_source_list[i]["订单号"]))

        assert count == 0, "存在对比失败或者excle中数据不完全{}".format(fail_message)

    @keyword
    def get_data_source_trade(
        self,
        start_time,
        end_time,
        es_url="http://172.20.11.23:9200,http://172.20.20.183:9200,http://172.20.20.184:9200",
        doc_type=None,
    ):
        """
        获取交易账单的源数据
        - param start_time:开始时间  如2022-10-01
        - param end_time: 结束时间   如2022-10-21
        - param es_url: es的地址
        - param es_name: 所查询的es表名
        - param doc_type: 类型
        - return: 返回查询到的数据
        """

        start_date = datetime.datetime.strptime(start_time, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end_time, "%Y-%m-%d")
        start_month = "%04d%02d" % (start_date.year, start_date.month)
        end_month = "%04d%02d" % (end_date.year, end_date.month)
        es_table_list = []
        if start_month == end_month:
            es_table_list.append("t_mer_trans_list_" + start_month)
        else:
            es_table_list.append("t_mer_trans_list_" + start_month)
            es_table_list.append("t_mer_trans_list_" + end_month)

        query = '{{"bool":{{"must":[{{"range":{{"TRANS_TIME":{{"from":"{} 00:00:00","to":"{} 23:59:59","include_lower":true,"include_upper":true,"boost":1.0}}}}}},{{"term":{{"LMER_NO":{{"value":"84931015812A00N","boost":1.0}}}}}},{{"terms":{{"STATUS":["2","4","6"],"boost":1.0}}}}],"must_not":[{{"terms":{{"BUSI_SUB_TYPE":["1585","0117","0110","0119","0105","0107","1541","1555","1540","1554","0115","1544","1588","3434","0185","1542","1553","1559"],"boost":1.0}}}}],"adjust_pure_negative":true,"boost":1.0}}}}'.format(
            start_time, end_time
        )
        log.info("es的查询语句", query)
        log.info("开始的交易日期", start_time, "结束的交易日期", end_time, "交易账单获取数据源时，根据交易日期生成的es待查询的表名", es_table_list)

        from .EsLibrary import EsLibrary

        es = EsLibrary()
        es.es_init_host(es_url)

        hbase_rowkeys = []

        for i in range(len(es_table_list)):
            select_result = es.es_search_datas(es_table_list[i], doc_type, query)
            for j in range(len(select_result)):
                tmp_dict = select_result[j]
                hbase_rowkeys.append(tmp_dict["_id"])

        # 查询数据库的路由表

        mysql = DBLibrary()
        mysql.connect_to_database("mysql", "root/xdata#1#2#3#0929@172.20.7.33:3306/xdata")

        index_route_config = mysql.query_to_dict(
            "select index_real_name, hbase_table_name from t_index_route_config where t_index_route_config.index_real_name like '%t_mer_trans%'"
        )
        mysql.connect_close()

        hbase_table_name_list = list()
        for i in range(len(es_table_list)):
            for j in range(len(index_route_config)):
                if index_route_config[j]["index_real_name"] == es_table_list[i]:
                    if index_route_config[j]["hbase_table_name"]:
                        hbase_table_name_list.append(index_route_config[j]["hbase_table_name"])
        if not hbase_table_name_list:
            hbase_table_name_list.append("XDATA:T_FULL_TRADE_BILL")
        # 有可能es里没有数据
        if not hbase_rowkeys:
            log.info("所查询的es中没有数据,结束接下来的hbase查询")
            return {"data": []}

        hbase_result = list()

        log.info("开始hbase查询...")
        # 去重
        hbase_table_name_list = list(set(hbase_table_name_list))
        log.info("由路由表得到所查询hbase的表名", hbase_table_name_list)
        for i in range(len(hbase_table_name_list)):
            hbase_result.extend(self.hbase_get_rows(hbase_table_name_list[i], hbase_rowkeys))

        # 处理hbase查询出来的数据
        key_dict = {
            "cf:ORDER_ID": "订单号",
            "cf:TRANS_TIME": "交易时间",
            "cf:ORI_AMT": "原始交易金额（元）",
            "cf:AMT": "交易金额（元）",
            "cf:DISCOUNT_AMT": "优惠（元）",
            "cf:REAL_AMT": "实付金额（元）",
            "cf:FEE_AMT": "手续费（元）",
            "cf:LMER_NAME": "商户名称",
            "cf:LMER_NO": "商户号",
            "cf:LTERM_NO": "终端号",
            "cf:RET_MSG": "返回信息",
        }
        # 查询交易类型
        db = DBLibrary()
        db.connect_to_database("cx_Oracle", "base_data_user/123456@172.20.34.10:1521/posplus")

        result = db.query_to_dict("select VALUE,LABEL from T_DICT where TYPE='BusiSubType'")
        busi_sub_type_dict = dict()
        for i in range(len(result)):
            busi_sub_type_dict.update({result[i]["value"]: result[i]["label"]})

        money_key_list = ["cf:ORI_AMT", "cf:AMT", "cf:REAL_AMT", "cf:DISCOUNT_AMT", "cf:FEE_AMT"]
        data_list = []
        for i in range(len(hbase_result)):
            pending_dict = hbase_result[i]
            solved_dic = {}
            for key in pending_dict:
                if key in key_dict:
                    if key in money_key_list:
                        if "cf:BUSI_SUB_TYPE" in pending_dict:
                            assert pending_dict["cf:BUSI_SUB_TYPE"] in busi_sub_type_dict, (
                                "源数据的这个业务小类在数据库中没有,这个业务小类为" + pending_dict["cf:BUSI_SUB_TYPE"]
                            )
                            # 因为交易账单对业务小类为撤销，退货的交易金额数据进行了添加负号处理  但又对折扣金额不处理
                            if (
                                busi_sub_type_dict[pending_dict["cf:BUSI_SUB_TYPE"]].endswith(("撤销", "退货"))
                                and key != "cf:DISCOUNT_AMT"
                            ):
                                solved_dic[key_dict[key]] = -float(pending_dict[key]) / 100
                            else:
                                solved_dic[key_dict[key]] = float(pending_dict[key]) / 100
                        else:
                            warnings.warn("源数据中没有cf:BUSI_SUB_TYPE这个字段")
                            solved_dic[key_dict[key]] = float(pending_dict[key]) / 100

                    else:
                        solved_dic[key_dict[key]] = pending_dict[key]
            data_list.append(solved_dic)

        data_source_dict = {}
        data_source_dict["data"] = data_list

        return data_source_dict

    @staticmethod
    @keyword
    def compare_of_trade(data_source, excel):
        """
        交易账单的对比方法
        - param data_source:源数据
        - param excel: 从平台下载的数据
        - return: 对比结果
        """
        # 断言标志位
        count = 0
        # 设置排错信息
        fail_message = []

        data_source_list = data_source["data"]
        excel_list = excel["data"]

        money_key_list = ["原始交易金额（元）", "交易金额（元）", "实付金额（元）", "优惠（元）", "手续费（元）"]

        # 先寻找excel_list中对应的下标  期望是一定可以找到
        for i in range(len(data_source_list)):
            data_source_tmp_dict = data_source_list[i]

            excel_index = 99999999
            for j in range(len(excel_list)):
                if data_source_tmp_dict["订单号"] in excel_list[j]["订单号"]:
                    excel_index = j
                    break
            try:
                for key in data_source_list[i]:
                    if data_source_list[i][key] == excel_list[excel_index][key]:
                        log.info("对比成功", "对比的订单号为", data_source_list[i]["订单号"], "对比的列为", key)
                    elif (
                        key in money_key_list and data_source_list[i][key] - float(excel_list[excel_index][key]) == 0.0
                    ):
                        log.info("对比成功", "对比的订单号为", data_source_list[i]["订单号"], "对比的列为", key)
                    else:
                        log.info(
                            "对比失败",
                            "对比的订单号为",
                            data_source_list[i]["订单号"],
                            "对比的列为",
                            key,
                            "源数据的列值",
                            data_source_list[i][key],
                            "excel的列值",
                            excel_list[excel_index][key],
                        )
                        count = count + 1
                        fail_message.append(
                            "对比失败，对比的订单号为{}，对比的列为{}，源数据的列值为{}，excel的列值为{}".format(
                                data_source_list[i]["订单号"], key, data_source_list[i][key], excel_list[excel_index][key]
                            )
                        )
            except IndexError:
                count = count + 1
                fail_message.append("excel缺少这行数据order_id为{}".format(data_source_list[i]["订单号"]))

        assert count == 0, "存在对比失败或者excle中数据不完全{}".format(fail_message)
