#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time : 2021/12/24 10:27
# @Author : Joey Xu
# @File : BankCard.py

from collections import OrderedDict

from faker.providers.credit_card import Provider

localized = True


class BankCard:
    def __init__(self, name, prefixes, length=16, security_code="CVC", security_code_length=3):
        self.name = name
        self.prefixes = prefixes
        self.length = length
        self.security_code = security_code
        self.security_code_length = security_code_length


class LSProvider(Provider):
    """Implement default credit card provider for Faker.

    For all methods that take ``card_type`` as an argument, a random card type
    will be used if the supplied value is ``None``. The list of valid card types
    includes ``'amex'``, ``'diners'``, ``'discover'``, ``'jcb'``, ``'jcb15'``,
    ``'jcb16'``, ``'maestro'``, ``'mastercard'``, ``'visa'``, ``'visa13'``,
    ``'visa16'``, and ``'visa19'``.

    Sources:

    - https://en.wikipedia.org/wiki/Payment_card_number#Issuer_identification_number_.28IIN.29
    - https://www.regular-expressions.info/creditcard.html
    - https://creditcardjs.com/credit-card-type-detection
    """

    prefix_maestro = [
        "5018",
        "5020",
        "5038",
        "56##",
        "57##",
        "58##",
        "6304",
        "6759",
        "6761",
        "6762",
        "6763",
        "0604",
        "6390",
    ]
    prefix_mastercard = [
        "51",
        "52",
        "53",
        "54",
        "55",
        "222%",
        "223",
        "224",
        "225",
        "226",
        "227",
        "228",
        "229",
        "23",
        "24",
        "25",
        "26",
        "270",
        "271",
        "2720",
    ]
    prefix_visa = ["4"]
    prefix_amex = ["34", "37"]
    prefix_discover = ["6011", "65"]
    prefix_diners = ["300", "301", "302", "303", "304", "305", "36", "38"]
    prefix_jcb16 = ["35"]
    prefix_jcb15 = ["2131", "1800"]
    ccb_credit18 = ['5453242', '5491031', '5544033'] # 建设银行信用卡18位
    ccb_credit16 = ['622725', '622728', '436728'] # 建设银行信用卡16位
    ccb_debit19 = ['621284'] # 建设银行储蓄卡19位
    ccb_debit16 = ['421349', '434061', '434062'] # 建设银行储蓄卡16位
    boc_credit16 = ['356833', '409665', '622788', '622752', '518378', '625140', '622789', '626200', '622380', '558869'] # 中国银行信用卡16位
    boc_credit15 = ['377677'] # 中国银行信用卡15位/银联美运顶级卡
    boc_prepaid16 = ['620019', '620035', '620211', '620514']    # 预付费卡16位
    boc_prepaid19 = ['620531', '620210', '620040']  # 预付费卡19位
    boc_debit19 = ['621660', '621661', '623586', '621756', '621668', '621666', '621741', '621782'] # 中国银行储蓄卡19位
    boc_debit16 = ['621248', '621249', '621215', '621395', '623040', '621231', '622348', '621638'] # 中国银行储蓄卡16位

    credit_card_types = OrderedDict(
        (
            ("maestro", BankCard("Maestro", prefix_maestro, 12, security_code="CVV")),
            ("mastercard", BankCard("Mastercard", prefix_mastercard, 16, security_code="CVV")),
            ("visa16", BankCard("VISA 16 digit", prefix_visa)),
            ("visa13", BankCard("VISA 13 digit", prefix_visa, 13)),
            ("visa19", BankCard("VISA 19 digit", prefix_visa, 19)),
            ("amex", BankCard("American Express", prefix_amex, 15, security_code="CID", security_code_length=4)),
            ("discover", BankCard("Discover", prefix_discover)),
            ("diners", BankCard("Diners Club / Carte Blanche", prefix_diners, 14)),
            ("jcb15", BankCard("JCB 15 digit", prefix_jcb15, 15)),
            ("jcb16", BankCard("JCB 16 digit", prefix_jcb16)),
            ("ccb_credit18", BankCard("CCB 18 digit", ccb_credit18, 18)),
            ("ccb_credit16", BankCard("CCB 16 digit", ccb_credit16, 16)),
            ("ccb_debit19", BankCard("CCB 19 digit", ccb_debit19, 19)),
            ("ccb_debit16", BankCard("CCB 16 digit", ccb_debit16, 16)),
            ('boc_credit15', BankCard('BOC 18 digit', boc_credit15, 15)),
            ('boc_credit16', BankCard('BOC 16 digit', boc_credit16, 16)),
            ('boc_debit19', BankCard('BOC 19 digit', boc_debit19, 19)),
            ('boc_debit16', BankCard('BOC 16 digit', boc_debit16, 16)),
		    ('boc_prepaid16', BankCard('BOC 16 digit', boc_prepaid16, 16)),
		    ('boc_prepaid19', BankCard('BOC 19 digit', boc_prepaid19, 19)),
        )
    )
    credit_card_types["visa"] = credit_card_types["visa16"]
    credit_card_types["jcb"] = credit_card_types["jcb16"]
    credit_card_types["ccb"] = credit_card_types["ccb_credit16"]
    credit_card_types['boc'] = credit_card_types['boc_credit16']

    luhn_lookup = {"0": 0, "1": 2, "2": 4, "3": 6, "4": 8, "5": 1, "6": 3, "7": 5, "8": 7, "9": 9}

    def credit_card_provider(self, card_type=None):
        """Generate a credit card provider name."""
        if card_type is None:
            card_type = self.random_element(self.credit_card_types.keys())
        return self._credit_card_type(card_type).name

    def credit_card_number(self, card_type=None):
        """Generate a valid credit card number."""
        card = self._credit_card_type(card_type)
        prefix = self.random_element(card.prefixes)
        number = self._generate_number(self.numerify(prefix), card.length)
        return number

    def credit_card_expire(self, start="now", end="+10y", date_format="%m/%y"):
        """Generate a credit card expiry date.

        This method uses |date_time_between| under the hood to generate the
        expiry date, so the ``start`` and ``end`` arguments work in the same way
        here as it would in that method. For the actual formatting of the expiry
        date, |strftime| is used and ``date_format`` is simply passed
        to that method.
        """
        expire_date = self.generator.date_time_between(start, end)
        return expire_date.strftime(date_format)

    def credit_card_full(self, card_type=None):
        """Generate a set of credit card details."""
        card = self._credit_card_type(card_type)

        tpl = "{provider}\n" "{owner}\n" "{number} {expire_date}\n" "{security}: {security_nb}\n"

        tpl = tpl.format(
            provider=card.name,
            owner=self.generator.parse("{{first_name}} {{last_name}}"),
            number=self.credit_card_number(card),
            expire_date=self.credit_card_expire(),
            security=card.security_code,
            security_nb=self.credit_card_security_code(card),
        )

        return self.generator.parse(tpl)

    def credit_card_security_code(self, card_type=None):
        """Generate a credit card security code."""
        sec_len = self._credit_card_type(card_type).security_code_length
        return self.numerify("#" * sec_len)

    def _credit_card_type(self, card_type=None):
        """Generate a random CreditCard instance of the specified card type."""
        if card_type is None:
            card_type = self.random_element(self.credit_card_types.keys())
        elif isinstance(card_type, BankCard):
            return card_type
        return self.credit_card_types[card_type]

    def _generate_number(self, prefix, length):
        """Generate a credit card number.

        The ``prefix`` argument is the start of the CC number as a string which
         may contain any number of digits. The ``length`` argument is the length
         of the CC number to generate which is typically 13 or 16.
        """
        number = prefix
        # Generate random char digits
        number += "#" * (length - len(prefix) - 1)
        number = self.numerify(number)
        reverse = number[::-1]
        # Calculate sum
        tot = 0
        pos = 0
        while pos < length - 1:
            tot += Provider.luhn_lookup[reverse[pos]]
            if pos != (length - 2):
                tot += int(reverse[pos + 1])
            pos += 2
        # Calculate check digit
        check_digit = (10 - (tot % 10)) % 10
        number += str(check_digit)
        return number
