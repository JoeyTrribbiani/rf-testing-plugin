import json
from abc import ABC
from typing import Union
from urllib.parse import unquote_plus

import requests
import simplejson.errors
from requests.models import PreparedRequest
from requests.compat import json as complexjson

from JLTestLibrary import log
from JLTestLibrary.UtilsMsg import UtilsMsg


def log_request(response: requests.Response) -> None:
    request = response.request
    # prepare request
    if response.history:
        original_request = response.history[0].request
        redirected = "(redirected) "
    else:
        original_request = request
        redirected = ""
    if original_request.body and isinstance(original_request.body, bytes):
        try:
            body_log = f"encoding=\n " + f"body={original_request.body.decode('utf-8')}"
        except UnicodeDecodeError:
            body_log = (
                f"encoding=latin-1(iso-8859-1), 中文将无法正常显示, body部份过长已截断 \n "
                + f"body={original_request.body.decode('latin-1')[:1999]}"
            )
    else:
        body_log = f"body={original_request.body}"
    log.info(
        f"{original_request.method.upper()} 请求 : url={unquote_plus(original_request.url)} {redirected}\n "
        + f"path_url={original_request.path_url} \n "
        + f"headers={original_request.headers} \n "
        + f"{body_log} \n "
    )


def log_response(response: requests.Response, encoding=None) -> None:
    log.info(
        f"{response.request.method.upper()} 响应 : url={response.url} \n "
        + f"elapsed_time={response.elapsed.microseconds // 1000} ms \n "
        + f"status={response.status_code}, reason={response.reason} \n "
        + f"headers={response.headers} \n "
        + f"body={response.content.decode(encoding) if encoding else response.text} \n "
    )


class RequestHandler(ABC):
    def _handle_request(self, request_data, replace_data, abnormal_data):
        raise NotImplementedError

    def _handle_response(self, resp, encoding: str = '') -> Union[dict, str]:
        raise NotImplementedError


class CommonRequestHandler(RequestHandler):
    def _handle_request(
        self,
        request_data: Union[str, dict],
        replace_data: Union[str, dict] = {},
        abnormal_data: Union[str, dict] = {},
    ):
        request_body = UtilsMsg.str_to_dict(request_data)
        if replace_data:
            replace_data = UtilsMsg.str_to_dict(replace_data)
            request_body = UtilsMsg.para_replace(request_body, replace_data)
        request_body = UtilsMsg.msg_default_para_replace(request_body)
        if abnormal_data:
            abnormal_data = UtilsMsg.str_to_dict(abnormal_data)
            request_body = UtilsMsg.para_replace(request_body, abnormal_data)
        return request_body

    def _handle_response(self, resp: requests.Response, encoding: str = '') -> Union[dict, str]:
        log_request(resp)
        log_response(resp, encoding)
        if resp.status_code >= 400:
            log.warn("status_code:", resp.status_code)
        try:
            if not encoding:
                encoding = "utf-8"
            try:
                return complexjson.loads(resp.content.decode(encoding))
            except UnicodeDecodeError:
                pass
            return complexjson.loads(resp.text)
        except (simplejson.errors.JSONDecodeError, json.JSONDecodeError):
            return resp.content.decode(encoding) if encoding else resp.text

    def get_response_headers(self, resp: requests.Response) -> dict:
        return resp.headers


class CommonRequestPrepare:
    def _prepare_header(self, prepared: requests.PreparedRequest, headers: Union[str, dict], content_type: str = ''):
        if not headers:
            return {}
        request_header = UtilsMsg.str_to_dict(headers)
        if content_type:
            prepared.headers["Content-Type"] = content_type
        else:
            if prepared.headers.get("Content-Type"):
                del prepared.headers["Content-Type"]
        return request_header if request_header else {}

    def _request_instance(self, url: str, data: dict, **kwargs):
        return requests.Request(method="POST", url=url, data=data)

    def _update_headers(self, prepared: requests.PreparedRequest, headers: Union[str, dict]):
        prepared.headers.update(self._prepare_header(prepared, headers, "application/json"))

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        json_data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        if isinstance(headers, str) and headers:
            headers = eval(headers)
        # 创建PreparedRequest对象
        prepared = PreparedRequest()
        prepared.method = 'POST'
        prepared.url = url
        prepared.headers = headers
        prepared.prepare(method=prepared.method, url=prepared.url, headers=prepared.headers, data=json_data, files=kwargs.get('files', None))
        prepared.body = json_data

        self._update_headers(prepared, prepared.headers)
        return prepared

    def _prexmlpare(self, url: str, data, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        if isinstance(headers, str) and headers:
            headers = eval(headers)
        # 创建PreparedRequest对象
        prepared = PreparedRequest()
        prepared.method = 'POST'
        prepared.url = url
        prepared.headers = headers
        prepared.prepare(method=prepared.method, url=prepared.url, headers=prepared.headers, data=data, files=kwargs.get('files', None))
        prepared.body = data
        self._update_headers(prepared, prepared.headers)
        return prepared
class BaseRequest(CommonRequestHandler, CommonRequestPrepare):
    def __init__(self) -> None:
        self.sign_type = ''

    def _sign(self, request: dict, **kwargs):
        return request

    def _crypto(self, request: dict, **kwargs):
        return request

    def _verify(self, response, **kwargs):
        return response

    def _decrypto(self, response: dict, **kwargs):
        return response
