import base64
import binascii
import json
import random
import secrets
import string
import time
from copy import deepcopy
from enum import Enum
from io import BytesIO
from typing import Union

import requests
from asn1crypto import pem
from gmssl import sm2
from requests import PreparedRequest
from requests.exceptions import ConnectTimeout
from robot.utils import ConnectionCache
from sm_crypto import sm2 as sm2_crypto
from pyasn1.codec.der import decoder

from JLTestLibrary import log
from JLTestLibrary.UtilsMsg import UtilsMsg
from JLTestLibrary.UtilsSign import UtilsSign
from JLTestLibrary.UtilsLibrary import UtilsLibrary

from . import BaseRequest, log_request, log_response


class HttpRequestFlow(BaseRequest):
    """默认POST json请求"""

    def __init__(
        self,
    ) -> None:
        self._cache = ConnectionCache("No sessions created")
        self.prepared_request = None
        self.resp = None
        self.last_request = {}
        self.last_response = {}
        self.timeout = 60
        self.cookies = None
        self.last_files = None
        self.response_head = None
        super().__init__()

    def _get_session(self, url: str, path_url: str) -> requests.Session:
        host = url.replace(path_url, "")
        try:
            session = self._cache[host]
            log.info(f"使用缓存中的session {session} for {host}")
            return session
        except RuntimeError:
            log.info(f"新建session for {host}")
            session = requests.Session()
            self._cache.register(session, host)
            return self._cache[host]

    def pre_processor(
        self,
        request_data: Union[str, dict],
        replace_data: Union[str, dict] = {},
        abnormal_data: Union[str, dict] = {},
    ):
        log.info("开始请求报文预处理")
        self.last_request = self._handle_request(request_data, replace_data, abnormal_data)
        return self

    def crypto(self, key: str = '', pub_key: str = '', **kwargs):
        """_summary_

        :param request_data: _description_
        :param key: 对称加密时，使用对称加密密钥, defaults to None
        :param pub_key: 非对称加密时，使用公钥, defaults to None
        :param enc_user_mp: _description_, defaults to True
        :param biz_key: _description_, defaults to "biz_content"
        :param common: _description_, defaults to None
        :param token: _description_, defaults to ""
        :return: _description_
        """
        log.info("开始请求报文加密")
        if not kwargs.get("biz_key"):
            kwargs.update({"biz_key": "biz_content"})
        if kwargs.get("enc_user_mp") is None:
            kwargs.update({"enc_user_mp": True})
        if not kwargs.get("token"):
            kwargs.update({"token": ""})
        self.last_request = self._crypto(self.last_request, key=key, pub_key=pub_key, **kwargs)
        return self

    def sign(self, private_key: str, **kwargs):
        """
        :kwargs: private_key, with_id, sign_fields, app_key
        :return: _description_
        """
        if private_key:
            log.info("开始请求报文签名")
            self.last_request = self._sign(self.last_request, private_key=private_key, **kwargs)
            self.sign_type = self.sign_type
            log.info(f'缓存请求中的签名类型 {self.sign_type}')
        else:
            log.info("未提供私钥，请求报文默认跳过加签")
        return self

    def prepare(self, url: str, http_headers: Union[str, dict] = {}, files: Union[str, dict] = {}):
        log.info("开始准备请求内容")
        self.prepared_request = self._prepare(url, self.last_request, http_headers, files=files)
        if self.prepared_request:
            self.prepared_request.prepare_cookies(self.cookies)
        return self

    def prexmlpare(self, url: str, http_headers: Union[str, dict] = {}, files: Union[str, dict] = {}):
        log.info("开始准备请求内容")
        self.prepared_request = self._prexmlpare(url, self.last_request, http_headers, files=files)
        if self.prepared_request:
            self.prepared_request.prepare_cookies(self.cookies)
        return self

    def request(self):
        log.info("开始发送请求")
        try:
            self.resp = self._get_session(self.prepared_request.url, self.prepared_request.path_url).send(
                self.prepared_request, timeout=self.timeout
            )
        except ConnectTimeout:
            raise RuntimeError(f"{self.prepared_request.url} 请求连接超时")
        if self.resp.cookies:
            self.cookies = self.resp.cookies
        log.info(f"缓存内的cookie值: {self.cookies}")
        return self

    def post_processor(self, resp_encoding: str = ''):
        log.info("开始响应报文预处理")
        self.last_response = self._handle_response(self.resp, resp_encoding)
        self.response_headers = self.get_response_headers(self.resp)
        return self

    def verify(self, public_key: str = '', **kwargs):
        """
        kwargs: with_id
        """
        if public_key:
            if not kwargs.get('resp_verify', True):
                # 只有False时才跳过
                log.warn("已指定参数，跳过响应验签")
                return self
            log.info("已提供公钥，开始响应报文验签")
            self._verify(self.last_response, public_key=public_key, sign_type=self.sign_type, **kwargs)
        else:
            log.info("未提供公钥，服务返回的消息默认跳过验签")
        return self

    def decrypto(self, key: str, pri_key: str = "", **kwargs):
        if not kwargs.get('resp_verify', True):
            log.warn("已跳过响应验签, 开始跳过响应报文解密")
            return self
        log.info("开始响应报文解密")
        self.last_response = self._decrypto(self.last_response, key=key, pri_key=pri_key, **kwargs)
        log.info(f"响应报文解密后: {self.last_response}")
        return self


class GetRequest(HttpRequestFlow):
    def _request_instance(self, url: str, data: dict, **kwargs):
        params = data
        return requests.Request("GET", url, params=params)

    def _update_headers(self, prepped: requests.PreparedRequest, headers: Union[str, dict]):
        prepped.headers.update(self._prepare_header(prepped, headers, ""))

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        req = self._request_instance(url, data, **kwargs)
        prepared = req.prepare()
        self._update_headers(prepared, headers)
        return prepared

class DictToXmlRequestFlow(HttpRequestFlow):
    pass


class ExtQrcodeRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        private_key = kwargs.get("private_key")
        with_id = kwargs.get("with_id")

        class SignType(str, Enum):
            RSA = "RSA"
            SM2 = "SM2"

        sign_str = UtilsMsg.get_sign_json(request)
        sign_type = request.get("sign_type", SignType.RSA)
        if sign_type == SignType.SM2:
            sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=False, with_id=with_id)
        else:
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        public_key = kwargs.get("public_key")
        with_id = kwargs.get("with_id")

        class SignType(str, Enum):
            RSA = "RSA"
            SM2 = "SM2"

        response = UtilsMsg.str_to_dict(response)
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        sign_str = UtilsMsg.get_sign_json(response)
        sign_type = response.get("sign_type", SignType.RSA)
        if sign_type == SignType.SM2:
            sign = UtilsSign.verify_sm2_sign(public_key, sign_str, sign, asn1=False, with_id=with_id)
        else:
            sign = UtilsSign.verify_256sign(public_key, sign_str, sign)
        return response


class ExtQrcodeEncRequestMiXin(BaseRequest):
    """外接码付国密，全加密报文请求为data"""

    def __init__(self):
        self.key = ""
        super().__init__()

    def _handle_response(self, resp: requests.Response, encoding: str = "") -> Union[dict, str]:
        cipher_sm4_key = resp.headers.get("cipher-sm4-key")
        if cipher_sm4_key:
            self.key = cipher_sm4_key
        return super()._handle_response(resp, encoding)

    def _request_instance(self, url: str, data: str, **kwargs):  # type: ignore[override]
        # 加密后都是str，直接用data传输
        return requests.Request(method="POST", url=url, data=data)

    def _decrypto(self, response: str, **kwargs):  # type: ignore[override]
        """外接码付响应报文国密解密"""
        pri_key = kwargs.get("pri_key")
        sm4_key = UtilsSign.sm2_decrypt(self.key.encode("utf-8"), pri_key, True)
        self.lastresponse = base64.b64decode(UtilsSign.sm4_ecb_decrypt(response, sm4_key, True)).decode("utf-8")
        return self.lastresponse


class ExtQrcodeEncRequestFlow(ExtQrcodeEncRequestMiXin, ExtQrcodeRequestFlow):
    def _crypto(self, request: dict, **kwargs):
        """外接码付请求报文国密加密"""
        sm4_key = kwargs.get("key")
        data = json.dumps(request)
        log.info(f'加密前报文: {data}')
        data = UtilsSign.sm4_ecb_encrypt(
            base64.b64encode(data.encode("utf-8")).decode("utf-8"), sm4_key, b64_content=True, b64_encrypt=True
        )
        return data

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        req = self._request_instance(url, data, **kwargs)
        prepared = req.prepare()
        self._update_headers(prepared, headers)
        return prepared


class OldQrcodeRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """老外接码付请求报文 RSA签名"""
        private_key = kwargs.get("private_key")
        sign_str = UtilsMsg.build_sign_str(request)
        sign = UtilsSign.sign_sha(private_key, sign_str)
        request["sign"] = sign
        return request


class OldManageRegistRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """老进件请求报文 RSA2签名"""
        private_key = kwargs.get("private_key")
        sign_fields = kwargs.get("sign_fields")

        class SignMethod(str, Enum):
            RSA = "02"
            SM2 = "03"

        sign_method = request.get("signMethod", SignMethod.RSA)
        if sign_method == SignMethod.SM2:
            org_str = UtilsMsg.get_sign_context(request, "signData")
            sign = UtilsSign.sign_sm2(org_str, private_key)
        else:
            org_str = UtilsMsg.get_org_str(request, sign_fields)
            sign = UtilsSign.sign_sha256(private_key, org_str)
        request["signData"] = sign
        return request


class OpenflatformRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        private_key = kwargs.get("private_key")
        sign_str = UtilsMsg.trans_splitaccount_sort(request)
        sign = UtilsSign.sign_sha256(private_key, sign_str)
        request["sign_data"] = sign
        return request


class OpenflatformRequestFlowNew(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        private_key = kwargs.get("private_key")
        sign_str = UtilsMsg.trans_splitaccount_sort_new(request)
        sign = UtilsSign.sign_sha256(private_key, sign_str)
        request["signData"] = sign
        return request


class UnionFqQrcodeRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """银联分期码回调"""
        private_key = kwargs.get("private_key")
        with_id = kwargs.get("with_id")

        class SignType(str, Enum):
            RSA = "02"
            SM2 = "03"

        sign_str = UtilsMsg.build_sign_str(request)
        sign_type = request.get("signType", SignType.RSA)
        if sign_type == SignType.SM2:
            sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=False, with_id=with_id)
        else:
            sign = UtilsSign.union_fq_sign(sign_str, private_key)
        request["sign"] = sign
        return request


class UnionQrcodeRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """银联二维码回调"""
        private_key = kwargs.get("private_key")

        class SignType(str, Enum):
            RSA = "02"
            SM2 = "03"

        sign_str = UtilsMsg.build_sign_str(request, sign_field="signature")
        sign_type = request.get("signType", SignType.RSA)
        if sign_type == SignType.SM2:
            sign = UtilsSign.sign_sm2(sign_str, private_key)
        else:
            sign = UtilsSign.union_sign(sign_str, private_key)
        request["signature"] = sign
        return request

    def _handle_response(self, resp: requests.Response, encoding: str = '') -> Union[dict, str]:
        resp_text = super()._handle_response(resp, encoding)
        return UtilsMsg.key_value_convert_json(resp_text) if "=" in resp_text else resp_text

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        req = self._request_instance(url, data, **kwargs)
        prepared = req.prepare()
        self._update_headers(prepared, headers)
        return prepared


class JlpayRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """嘉联支付app，签名"""
        private_key = kwargs.get("private_key")

        class SignType(str, Enum):
            NO_SIGN = "RSA2"
            RSA2 = "RSAwithSHA256"
            SM2 = "SM2"

        sign_str = UtilsMsg.build_sign_str(request)
        sign_type = request.get("sign_type", SignType.NO_SIGN)
        if sign_type == SignType.NO_SIGN:
            sign = "1822"
        elif sign_type == SignType.RSA2:
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        elif sign_type == SignType.SM2:
            sign = UtilsSign.sign_sm2(sign_str, private_key)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过签名")
            sign = ""
        request["sign"] = sign
        return request

    def _crypto(self, request: dict, **kwargs):
        """嘉联支付app，登录密码加密，全报文加密"""
        app_key = kwargs.get("key")
        app_pub_key = kwargs.get("pub_key")
        if request.get("login_pwd"):
            request["login_pwd"] = UtilsSign.rsa_encrypt_login_pwd(request.get("login_pwd"), app_pub_key)
        biz_content = UtilsSign.encrypt_biz_content(
            json.dumps(request.get("biz_content", {}), ensure_ascii=False), app_key
        )
        request["biz_content"] = biz_content
        return request

    def _decrypto(self, response: dict, **kwargs):
        """嘉联支付app，响应报文解密"""
        app_key = kwargs.get("key")
        biz_contenxt = response.get("biz_context")
        self.lastresponse = UtilsSign.decrypt_biz_content(biz_contenxt, app_key, padding=b"\x00")
        return self.lastresponse


class CacheAuthorizationMixin(BaseRequest):
    """缓存Authorization"""

    def __init__(self):
        self.auth = None
        super().__init__()

    def _handle_response(self, resp: requests.Response, encoding: str = '') -> Union[dict, str]:
        resp_json = super()._handle_response(resp, encoding)
        if resp.headers.get("Authorization"):
            self.auth = resp.headers.get("Authorization")
        return resp_json

    def _update_headers(self, prepped: requests.PreparedRequest, headers: Union[str, dict]):
        prepped.headers.update(self._prepare_header(prepped, headers, "application/json"))
        if self.auth:
            prepped.headers.update({"Authorization": self.auth})


class LsRequestFlow(CacheAuthorizationMixin, JlpayRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """立刷app，请求签名"""
        private_key = kwargs.get("private_key")

        class SignType(str, Enum):
            NO_SIGN = "RSA2"
            RSA2 = "RSA256"
            RSA_SHA256 = "RSA-SHA256"
            SM2 = "SM2"

        sign_type = request.get("sign_type", SignType.RSA2)
        if sign_type == SignType.NO_SIGN:
            sign = "1822"
        elif sign_type == SignType.RSA2:
            sign_str = UtilsMsg.get_sign_context_md5(request)
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        elif sign_type == SignType.RSA_SHA256:
            sign_str = UtilsMsg.get_sign_context_sha256(request)
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        elif sign_type == SignType.SM2:
            sign_str = UtilsMsg.get_sign_context_md5(request)
            sign = UtilsSign.sign_sm2(sign_str, private_key)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过签名")
            sign = ""
        self.sign_type = sign_type
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """立刷app，响应验签"""
        public_key = kwargs.get("public_key")
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")

        class SignType(str, Enum):
            NO_SIGN = "RSA2"
            RSA2 = "RSA256"
            RSA_SHA256 = "RSA-SHA256"
            SM2 = "SM2"

        sign_type = kwargs.get("sign_type", SignType.RSA2)
        if sign_type == SignType.NO_SIGN:
            log.warn(f"{sign_type} 签名类型不用验签，跳过验签")
            return response
        elif sign_type == SignType.RSA2:
            data = UtilsMsg.get_sign_context_md5(response)
            UtilsSign.verify_256sign(public_key, data, sign)
        elif sign_type == SignType.RSA_SHA256:
            data = UtilsMsg.get_sign_context_sha256(response)
            UtilsSign.verify_256sign(public_key, data, sign)
        elif sign_type == SignType.SM2:
            data = UtilsMsg.get_sign_context_md5(response)
            UtilsSign.verify_sm2_sign(public_key, data, sign)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过验签")
        return response

    def _crypto(self, request: dict, **kwargs):
        """立刷app，登录密码加密，全报文加密"""
        app_key = kwargs.get("key")
        enc_user_mp = kwargs.get("enc_user_mp")

        content = request.get("biz_content", {})
        if enc_user_mp and content.get("user_mp"):
            content["user_mp"] = UtilsSign.hash_phone(content.get("user_mp"))
        if content.get("user_pwd"):
            content["user_pwd"] = UtilsSign.password_aes_encrypt(content.get("user_pwd"), app_key)
        if content.get("pwd_new"):
            content["pwd_new"] = UtilsSign.password_aes_encrypt(content.get("pwd_new"), app_key)

        biz_content = UtilsSign.encrypt_biz_content(json.dumps(content, ensure_ascii=False), app_key)
        request["biz_content"] = biz_content
        return request

    def _decrypto(self, response: dict, **kwargs):
        """立刷app，响应报文解密"""
        return super()._decrypto(response, **kwargs)

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        req = self._request_instance(url, data, **kwargs)
        prepared = req.prepare()
        self._update_headers(prepared, headers)
        return prepared


class FormRequestMixin(BaseRequest):
    """http表单请求"""

    def _request_instance(self, url: str, data: dict, **kwargs):
        return requests.Request("POST", url, data=data)

    def _update_headers(self, prepped: requests.PreparedRequest, headers: Union[str, dict]):
        prepped.headers.update(self._prepare_header(prepped, headers, "x-www-form-urlencoded"))

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs) -> requests.PreparedRequest:
        req = self._request_instance(url, data, **kwargs)
        prepared = req.prepare()
        self._update_headers(prepared, headers)
        return prepared


class FormRequestFlow(FormRequestMixin, HttpRequestFlow):
    pass


class AgentWebRequestFlow(FormRequestMixin, HttpRequestFlow):
    def _crypto(self, request: dict, **kwargs):
        """合伙人平台agent-web，登录信息加密"""
        app_pub_key = kwargs.get("pub_key")
        if request.get("userno"):
            request["userno"] = UtilsSign.rsa_encrypt_login_pwd(request.get("userno"), app_pub_key)
        if request.get("userpwd"):
            request["userpwd"] = UtilsSign.rsa_encrypt_login_pwd(request.get("userpwd"), app_pub_key)
        return request


class AccessEncryptAlg(str, Enum):
    AES = "1"
    SM4 = "2"
    RSA = "3"
    SM2 = "4"


class AccessSignType(str, Enum):
    RSA256 = "RSA256"
    SM3WITHSM2 = "SM3withSM2"
    SHA256WITHRSA = "SHA256withRSA"


class AccessRequestFlow(HttpRequestFlow):
    def _crypto(self, request: dict, **kwargs):
        """T9智能终端外部接入，密文请求"""
        app_key = kwargs.get("key")
        biz_key = kwargs.get("biz_key")
        biz_content = request.get(biz_key)
        if biz_content:
            log.info("待加密明文:", biz_content)

            encrypt_alg = request.get("encrypt_alg", AccessEncryptAlg.AES)
            if AccessEncryptAlg.AES == encrypt_alg:
                biz_context = UtilsSign.encrypt_biz_content(json.dumps(biz_content, ensure_ascii=False), app_key)
            elif AccessEncryptAlg.SM4 == encrypt_alg:
                biz_context = UtilsSign.sm4_ecb_encrypt(
                    json.dumps(biz_content, ensure_ascii=False), app_key, b64_content=True, b64_encrypt=True
                )
            else:
                log.warn(f"{encrypt_alg} 加密类型暂不支持，跳过加密")
                biz_context = biz_content
            request[biz_key] = biz_context
        return request

    def _sign(self, request: dict, **kwargs):
        """T9智能终端外部接入，请求签名"""
        private_key = kwargs.get("private_key")

        sign_str = UtilsMsg.get_sign_context(request)
        sign_type = request.get("sign_type", AccessSignType.SHA256WITHRSA)
        if sign_type == AccessSignType.SHA256WITHRSA:
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        elif sign_type == AccessSignType.SM3WITHSM2:
            sign = UtilsSign.sign_sm2(sign_str, private_key)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过签名")
            sign = ""
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """T9智能终端外部接入，响应验签"""
        public_key = kwargs.get("public_key")
        if response["ret_code"] != "00":
            return response
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        sign_type = response.get("sign_type", AccessSignType.SHA256WITHRSA)
        data = UtilsMsg.get_sign_context(response)
        if AccessSignType.SHA256WITHRSA == sign_type:
            UtilsSign.verify_256sign(public_key, data, sign)
        elif AccessSignType.SM3WITHSM2 == sign_type:
            UtilsSign.verify_sm2_sign(public_key, data, sign)
        else:
            raise AssertionError(f"{sign_type} 签名类型异常，验签失败")
        return response

    def _decrypto(self, response: dict, **kwargs):
        """T9智能终端外部接入，响应报文解密"""
        app_key = kwargs.get("key")
        pri_key = kwargs.get("pri_key")

        if response["ret_code"] != "00":
            return response
        biz_context = response.get("biz_context")
        encrypt_alg = response.get("encrypt_alg", AccessEncryptAlg.AES)
        if AccessEncryptAlg.AES == encrypt_alg:
            response = UtilsSign.decrypt_biz_content(
                json.dumps(biz_context, ensure_ascii=False), app_key, "AES", padding=b"\x00"
            )
        elif AccessEncryptAlg.RSA == encrypt_alg:
            response = UtilsSign.decrypt_biz_content(json.dumps(biz_context, ensure_ascii=False), pri_key, "RSA")
        elif AccessEncryptAlg.SM4 == encrypt_alg:
            response = UtilsSign.sm4_ecb_decrypt(json.dumps(biz_context, ensure_ascii=False), app_key, b64=True)
        elif AccessEncryptAlg.SM2 == encrypt_alg:
            response = UtilsSign.sm2_decrypt(biz_context, pri_key)
        else:
            raise AssertionError(f"{encrypt_alg} 加密类型异常，解密失败")
        return response


class OpenAccessRequestFlow(HttpRequestFlow):
    def _crypto(self, request: dict, **kwargs):
        """兼容open-access服务请求，请求报文加密"""
        pub_key = kwargs.get("pub_key")
        biz_key = kwargs.get("biz_key")

        context = request.get(biz_key)
        sign_str = UtilsMsg.get_sign_json(context)
        log.info("待加密明文:", sign_str)

        biz_context = UtilsSign.rsa_ecb_encrypt(sign_str, pub_key, b64=True)
        request[biz_key] = biz_context
        return request

    def _decrypto(self, response: dict, **kwargs):
        """兼容open-access服务请求，响应报文解密"""
        pri_key = kwargs.get("pri_key")

        response = UtilsSign.rsa_ecb_decrypt(response, pri_key, b64=True)
        return response


class MerchantRegisterRequestFlow(HttpRequestFlow):
    def __init__(self):
        self.key = ""
        self.resp_key = ""
        self.public_key = ""
        super().__init__()

    def _sign(self, request: dict, **kwargs):
        """新进件服务，请求签名"""
        private_key = kwargs.get("private_key")

        sign_str = UtilsMsg.get_sign_context(request)
        sign = UtilsSign.sign_sm2(sign_str, private_key)
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """新进件服务，响应验签"""
        public_key = kwargs.get("public_key")
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        data = UtilsMsg.get_sign_context(response)
        UtilsSign.verify_sm2_sign(public_key, data, sign)
        return response

    def _crypto(self, request: dict, **kwargs):
        """进件SDK v1.2版本,敏感信息使用动态SM4密钥加密"""
        self.key = sm4_key = kwargs.get("key")
        self.public_key = kwargs.get("pub_key")
        body_enc = kwargs.get("body_enc", "")
        if not sm4_key or not body_enc:
            return request

        if not self.public_key:
            raise ValueError("SM4加密敏感信息时, 必须传入pub_key")
        key_list = body_enc.split(',')
        for key, value in request.items():
            if key in key_list:
                request[key] = UtilsSign.sm4_ecb_encrypt(value, sm4_key, b64_encrypt=True)
        return request

    def _update_headers(self, prepared: requests.PreparedRequest, headers: Union[str, dict]):
        super()._update_headers(prepared, headers)
        if self.key:
            # 传进来是hex格式的sm4密钥，这里需要转bytes后调用sm2加密
            cipher_sm4_key = UtilsSign.sm2_encrypt(bytes.fromhex(self.key), self.public_key, b64_encrypt=True)
            prepared.headers.update({"Key-Info": cipher_sm4_key})

    def _handle_response(self, resp: requests.Response, encoding: str = "") -> Union[dict, str]:
        cipher_sm4_key = resp.headers.get("Key-Info")
        if cipher_sm4_key:
            self.resp_key = cipher_sm4_key
        return super()._handle_response(resp, encoding)

    def _decrypto(self, response: dict, **kwargs):  # type: ignore[override]
        """进件SDK v1.2版本,敏感信息使用动态SM4密钥加密"""
        pri_key = kwargs.get("pri_key")
        resp_enc = kwargs.get("resp_enc", "")
        key_list = resp_enc.split(',')
        if resp_enc and not self.resp_key:
            raise ValueError("响应信息需要解密时，响应头为返回Key-Info")
        if self.resp_key:
            sm4_key = UtilsSign.sm2_decrypt(self.resp_key.encode("utf-8"), pri_key, b64_content=True)
            log.info(f"解密得到SM4密钥为 {sm4_key}")
            for key, value in response.items():
                if key in key_list:
                    response[key] = UtilsSign.sm4_ecb_decrypt(value, sm4_key, b64=True)
        self.lastresponse = response
        return self.lastresponse


class ImsSdkRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """进销存SDK服务，请求签名"""
        private_key = kwargs.get("private_key")
        asn1 = kwargs.get("asn1", True)

        sign_str = UtilsMsg.get_sign_context(request, hashmap_order=False)
        sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=asn1)
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """进销存SDK服务，响应验签"""
        public_key = kwargs.get("public_key")
        asn1 = kwargs.get("asn1", True)
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        data = UtilsMsg.get_sign_context(response, hashmap_order=False)
        UtilsSign.verify_sm2_sign(public_key, data, sign, asn1=asn1)
        return response


class AgentsRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """合伙人app，param签名，签名后和common、token部分一起加密成密文"""
        private_key = kwargs.get("private_key")
        public_key = kwargs.get("public_key")

        if request.get("password") and request.get("encodeFlag") == 0:
            request["password"] = UtilsSign.rsa_encrypt_agent_login_pwd(
                request.get("account"), request.get("password"), public_key
            )
        if request.get("password") and request.get("encodeFlag") is None:
            request["password"] = UtilsSign.md5(request.get("password"))

        param_with_sign = UtilsSign._agent_sign_form_param(request, private_key)
        return param_with_sign

    def _crypto(self, request: dict, **kwargs):
        """合伙人app，全报文加密"""
        key = kwargs.get("key")
        common = kwargs.get("common")
        token = kwargs.get("token")

        common = UtilsMsg.str_to_dict(common)

        param_with_sign = request
        encrypt_context = UtilsSign._agent_encrypt_param_context(common, token, param_with_sign, agent_aes_key=key)
        return {"encryptContext": encrypt_context}

    def _verify(self, response: dict, **kwargs):
        """合伙人app，param验签"""
        public_key = kwargs.get("public_key")
        if public_key:
            response = UtilsMsg.str_to_dict(response)
            if response.get("rows"):
                param = json.dumps(response.get("rows"))
            elif response.get("data"):
                param = json.dumps(response.get("data"))
            else:
                log.info("data或rows都不存在，不做签名验证")
                return response
            params = json.loads(param.replace("\n", ""))
            if not params.get("paramSign"):
                log.warn("签名不存在，无法校验，请检查响应信息")
                return response
            sign = params["paramSign"]
            sign_str_md5 = UtilsSign.get_to_sign_param_str_md5(params)
            UtilsSign.verify_256sign(public_key, sign_str_md5, sign)
            return params
        return response

    def _decrypto(self, response: dict, **kwargs):
        """合伙人app，响应报文解密"""
        app_key = kwargs.get("key")
        response = UtilsSign._agent_decrypt_param_context(response, agent_aes_key=app_key)
        return response


class FilesRequestMixin(BaseRequest):
    """文件上传请求"""

    def _request_instance(self, url: str, data: dict, **kwargs):
        files = kwargs.get("files")
        return requests.Request("POST", url, data=data, files=files)

    def _update_headers(self, prepped: requests.PreparedRequest, headers: Union[str, dict]):
        prepped.headers.update(self._prepare_header(prepped, headers, ""))

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs):
        files = kwargs.get("files")
        files = UtilsMsg.str_to_dict(files)
        file_list = []
        if files:
            for file_key, file_details in files.items():
                file_name, file_type, file_size = (
                    file_details["file_name"],
                    file_details["file_type"],
                    file_details.get("file_size"),
                )
                base64_str = data[file_key]
                f = BytesIO(base64.b64decode(base64_str))
                file_list.append((file_key, (file_name, f, file_type)))
                data.pop(file_key)
        req = self._request_instance(url, data, files=file_list)
        prepped = req.prepare()
        self._update_headers(prepped, headers)
        return prepped


class FilesRequestFlow(FilesRequestMixin, HttpRequestFlow):
    pass


class FilesRequestFlowNew(FilesRequestMixin, HttpRequestFlow):
    def _handle_request(
        self,
        request_data: Union[str, dict],
        replace_data: Union[str, dict] = {},
        abnormal_data: Union[str, dict] = {},
    ):
        request_body = eval(request_data) if isinstance(request_data, str) else request_data
        # 特殊处理：把文件的二进制内容传到请求体里边，这样特殊处理的原因是为了兼容传入的请求是string类型的情况
        file_path = request_body['file']
        file_binary = base64.b64decode(UtilsLibrary.filepath_to_base64_str(file_path)).decode('latin-1')
        request_body['file'] = file_binary
        return request_body

    def _prepare(self, url: str, data: dict, headers: Union[str, dict], **kwargs):
        if isinstance(headers, str):
            headers = eval(headers)
        file_info = kwargs.get('files')
        if isinstance(file_info, str):
            file_info = eval(file_info)
        if file_info:
            file_name = file_info['file']['file_name']
            file_type = file_info['file']['file_type']
        characters = string.digits
        random_string = ''.join(random.choice(characters) for _ in range(int(24)))
        body = f'--{random_string}\r\nContent-Disposition: form-data; name="meta"\r\nContent-Type: application/json\r\n\r\n{json.dumps(data["meta"], ensure_ascii=False)}\r\n--{random_string}\r\nContent-Disposition: form-data; name="file"; filename="{file_name}"\r\nContent-Type: {file_type}\r\n\r\n{data["file"]}\r\n--{random_string}--'
        headers['Content-Type'] = f'multipart/form-data; boundary={random_string}'
        prepared = PreparedRequest()
        prepared.prepare(
            method='POST',
            url=url,
            data=body,
            headers=headers
        )
        return prepared


class SignFilesRequestFlow(FilesRequestMixin, HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """sign_type默认0 国密签名
        响应没有签名，不验签"""
        private_key = kwargs.get("private_key")
        asn1 = kwargs.get("asn1", True)
        files = kwargs.get("files")
        files = UtilsMsg.str_to_dict(files)
        if files:
            for file_key, file_details in files.items():
                file_size = file_details.get("file_size")
                if file_size:
                    if int(file_size) > 256:
                        file_size = 256
                        log.warn("最大支持256Mb的文件上传, 避免过多消耗资源, 设置为最大值256Mb")
                    file_bytes = secrets.token_bytes(int(file_size) * 1024 * 1024)
                    request[file_key] = base64.b64encode(file_bytes).decode("utf-8")
                else:
                    file_bytes = base64.b64decode(request[file_key])
                data = deepcopy(request)
                # TODO: python这个sm3 hash速度比较慢, 后续优化
                data[file_key] = base64.b64encode(
                    binascii.unhexlify(UtilsSign.sm3_hash_with_z(file_bytes, b''))
                ).decode('utf-8')

        sign_str = UtilsMsg.get_sign_context(data, hashmap_order=False)
        sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=asn1)
        request["sign"] = sign
        return request


class AuthSdkRequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        """鉴权Sdk，请求签名"""
        private_key = kwargs.get("private_key")

        sign_str = UtilsMsg.get_sign_context(request, all_sort=False)
        sign = UtilsSign.sign_sm2(sign_str, private_key)
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """鉴权Sdk，响应验签"""
        public_key = kwargs.get("public_key")
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        data = UtilsMsg.get_sign_context(response, all_sort=False)
        UtilsSign.verify_sm2_sign(public_key, data, sign)
        return response


class MposManageRequestFlow(CacheAuthorizationMixin, HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        app_key = kwargs.get("private_key")
        sign_fields = kwargs.get("sign_fields")
        org_str = UtilsMsg.get_sign_str(request, sign_fields, app_key)
        log.info("待加签明文:", org_str)
        sign = UtilsSign.sign256_base64(org_str)
        request["sign"] = sign
        return request

    def _verify(self, response, **kwargs):
        app_key = kwargs.get("public_key")
        resp_sign_fields = kwargs.get("resp_sign_fields")
        org_str = UtilsMsg.get_sign_str(response, resp_sign_fields, app_key)
        log.info("待验签明文:", org_str)
        sign = UtilsSign.sign256_base64(org_str)
        is_verify = response.get("sign") == sign
        if not is_verify:
            raise AssertionError("SHA256 Base64 验签失败")
        log.info("SHA256 Base64 验签成功")
        return is_verify


class CacheAuthorizationHttpRequestFlow(CacheAuthorizationMixin, HttpRequestFlow):
    pass


class AccessQuerySdkRequestFlow(HttpRequestFlow):
    def __init__(self) -> None:
        super().__init__()
        self.sm4_key = ""
        self.encrypt_alg = ""

    class EncryptAlg(str, Enum):
        SM4 = "1"  # for aliyun expose api
        SM2 = "2"  # for local expose api

    class SignType(str, Enum):
        SM2 = "01"
        SM3WITHSM2 = "02"

    def _sm4_crypto(self, request: dict, **kwargs):
        # 如果没有传sm4密钥 就生成一个
        self.sm4_key = kwargs.get("key", "")
        public_key = kwargs.get("pub_key")
        if not public_key:
            raise ValueError("必须传入公钥，加密对称密钥[encrypt_key]时需要使用")

        if not self.sm4_key:
            self.sm4_key = UtilsSign.generate_sm4_key()
        log.info("缓存请求使用的sm4_key:", self.sm4_key)

        # 使用平台方的公钥，加密对称密钥
        encrypt_sm4_key = UtilsSign.sm2_encrypt(bytes.fromhex(self.sm4_key), public_key, b64_encrypt=True)
        request["encrypt_key"] = encrypt_sm4_key

        # 加密报文
        content = request.get("biz_context")
        if content:
            biz_context = UtilsSign.encrypt_biz_content(json.dumps(content, ensure_ascii=False), self.sm4_key, sm4=True)
            request["biz_context"] = biz_context
        else:
            pass
            # null 、 空串等透传
        return request

    def _sm2_crypto(self, request: dict, **kwargs):
        # sm2加密只需要处理加密敏感字段
        return request

    def _crypto(self, request: dict, **kwargs):
        """大数据查询入口服务，报文加密"""
        self.encrypt_alg = request.get('encrypt_alg', "")
        if self.encrypt_alg == self.EncryptAlg.SM4:
            # sm4 全报文加密
            return self._sm4_crypto(request, **kwargs)
        elif self.encrypt_alg == self.EncryptAlg.SM2:
            # sm2 只有敏感信息加密
            return self._sm2_crypto(request, **kwargs)
        else:
            log.warn('加密类型未知，默认使用sm4进行报文加密')
            return self._sm4_crypto(request, **kwargs)

    def _sign(self, request: dict, **kwargs):
        """大数据查询入口服务，请求签名"""
        private_key = kwargs.get("private_key")

        sign_type = request.get("sign_type", AccessQuerySdkRequestFlow.SignType.SM3WITHSM2)
        if sign_type in [AccessQuerySdkRequestFlow.SignType.SM2, AccessQuerySdkRequestFlow.SignType.SM3WITHSM2]:
            sign_str = UtilsMsg.get_sign_context(request, "sign")
            sign = UtilsSign.sign_sm2(sign_str, private_key)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过签名")
            sign = ""
        self.sign_type = sign_type
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        """大数据查询入口服务，响应验签"""
        public_key = kwargs.get("public_key")
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")

        sign_type = response.get("sign_type", AccessQuerySdkRequestFlow.SignType.SM3WITHSM2)
        if sign_type in [AccessQuerySdkRequestFlow.SignType.SM2, AccessQuerySdkRequestFlow.SignType.SM3WITHSM2]:
            data = UtilsMsg.get_sign_context(response)
            UtilsSign.verify_sm2_sign(public_key, data, sign)
        else:
            log.warn(f"{sign_type} 签名类型暂不支持，跳过验签")
        return response

    def _sm4_decrypto(self, response: dict, **kwargs):
        biz_contenxt = response.get("biz_context")
        if not biz_contenxt:
            raise AssertionError("响应报文中不存在biz_context字段,请检查是否异常")
        self.lastresponse = UtilsSign.decrypt_biz_content(biz_contenxt, self.sm4_key, key_type='SM4')
        return self.lastresponse

    def _sm2_decrypto(self, response: dict, **kwargs):
        self.lastresponse = response
        return self.lastresponse

    def _decrypto(self, response: dict, **kwargs):
        """大数据查询入口服务，响应报文解密"""
        if self.encrypt_alg == self.EncryptAlg.SM4:
            # sm4 全报文解密
            return self._sm4_decrypto(response, **kwargs)
        elif self.encrypt_alg == self.EncryptAlg.SM2:
            # sm2 只有敏感信息解密
            return self._sm2_decrypto(response, **kwargs)
        else:
            log.warn('加密类型未知，默认使用sm4进行报文解密')
            return self._sm4_decrypto(response, **kwargs)


class HmacSha256RequestFlow(HttpRequestFlow):
    def _sign(self, request: dict, **kwargs):
        # app_secret 通过 private_key 参数传递过来
        app_secret = kwargs.get("private_key")

        sign_str = UtilsMsg.accp_account_sign_str(request)
        sign = UtilsSign.sign_hmac_sha256(app_secret, sign_str)
        request = UtilsMsg.sign_field_compare(request, sign)
        return request


class LedgerRequestFlow(HttpRequestFlow):
    class SignType(str, Enum):
        RSA256 = "0"
        SM2 = "1"
        SM3WithSM2WithDer = "SM3WithSM2WithDer"

    def _sign(self, request: dict, **kwargs):
        private_key = kwargs.get("private_key")

        sign_str = UtilsMsg.get_sign_context(request, hashmap_order=False)
        sign_type = request.get("sign_type", self.SignType.SM2)
        if sign_type == self.SignType.RSA256:
            sign = UtilsSign.sign_sha256(private_key, sign_str)
        elif sign_type in (self.SignType.SM2, self.SignType.SM3WithSM2WithDer):
            sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=True)
        else:
            # 默认SM2
            sign = UtilsSign.sign_sm2(sign_str, private_key, asn1=True)
        request["sign"] = sign
        return request

    def _verify(self, response: dict, **kwargs):
        public_key = kwargs.get("public_key")

        response = UtilsMsg.str_to_dict(response)
        sign = response.get("sign")
        if not sign:
            raise AssertionError("响应报文中不存在sign字段,请检查是否异常")
        sign_str = UtilsMsg.get_sign_context(response, hashmap_order=False)
        sign_type = response.get("sign_type", self.SignType.SM2)
        if sign_type == self.SignType.RSA256:
            UtilsSign.verify_256sign(public_key, sign_str, sign)
        elif sign_type in (self.SignType.SM2, self.SignType.SM3WithSM2WithDer):
            UtilsSign.verify_sm2_sign(public_key, sign_str, sign, asn1=True)
        else:
            # 默认SM2
            UtilsSign.verify_sm2_sign(public_key, sign_str, sign, asn1=True)

class CoopBankRequestFlow(HttpRequestFlow):
    class SignType(str, Enum):
        RSA256 = "0"
        SM2 = "1"
        SM3WithSM2WithDer = "SM3WithSM2WithDer"

    def _handle_response(self, resp: requests.Response, encoding: str = '') -> Union[dict, str]:
        log_request(resp)
        log_response(resp, encoding)
        return resp.text

    def _sign(self, request: dict, **kwargs):
        private_key = kwargs.get("private_key")
        sign = UtilsSign.sign_sm2(json.dumps(request), private_key)
        kwargs['headers']["x-jlpay-sign"] = sign
        kwargs['headers']["x-jlpay-sign-alg"] = 'SM3WithSM2WithDer'
        if 'app_id' not in request.keys():
            raise AssertionError("请求体中不存在app_id字段,请检查")
        kwargs['headers']["x-appid"] = request.get('app_id')
        return request

    def _verify(self, response: str, **kwargs):
        public_key = kwargs.get("public_key")
        sign = self.response_headers.get("x-jlpay-sign")
        if not sign:
            raise AssertionError("响应头中不存在x-jlpay-sign字段,请检查是否异常")
        UtilsSign.verify_sm2_sign(public_key, response, sign)


class HttpRequestFlowOpenPlatform(HttpRequestFlow):
    """开发接口统一签名方式
    https://jlpay.yuque.com/fsx9z5/regckm/gk8uuowzqv938qcp?singleDoc#shFvM
    """

    class SignType(str, Enum):
        RSA256 = 'RSA256'
        SM3WithSM2WithDer = 'SM3WithSM2WithDer'

    def _handle_response(self, resp: requests.Response, encoding: str = '') -> Union[dict, str]:
        log_request(resp)
        log_response(resp, encoding)
        return resp.text

    def _parse_private_key(self, private_key_asn_hex):
        hex_str_len = private_key_asn_hex[12:14]
        int_val = int(hex_str_len, 16)
        return private_key_asn_hex[14:(14 + int_val * 2)]

    def _sign(self, request: dict, **kwargs):
        """
        x-jlpay-appid 和 x-jlpay-key 是字段加解密需要的
        其他的sign nonce timestamp sign-alg是加验签需要的
        """
        org_pub_key_pem = kwargs.get('org_pub_key')
        org_pri_key_pem = kwargs.get('private_key')
        key = kwargs.get('key')

        sign_type = kwargs.get('sign_type', self.SignType.SM3WithSM2WithDer)
        method = kwargs.get('method', 'POST')
        uri = '/' + '/'.join(kwargs['url'].split('/')[3:])
        app_id = kwargs['app_id']
        time_stamp = str(int(time.time()))
        random_string = UtilsLibrary.get_random_string(32)
        request_body = self.last_request
        sign_body = f'{method}\n{uri}\n{time_stamp}\n{random_string}\n{json.dumps(request_body, ensure_ascii=False)}\n'
        log.info(f'加签body: {sign_body}')

        if sign_type == self.SignType.RSA256:
            log.info('RSA256加验签暂未实现')
        elif sign_type == self.SignType.SM3WithSM2WithDer:
            # 公钥pem格式转16进制
            org_pub_key_bytes = pem.unarmor(org_pub_key_pem.encode())
            org_pub_key_sm2 = sm2_crypto.SM2PublicKey.load(org_pub_key_bytes[2])
            org_pub_key = org_pub_key_sm2.x + org_pub_key_sm2.y

            log.info(f'公钥16进制: {org_pub_key}')

            # 私钥pem格式转16进制
            org_pri_key_bytes = pem.unarmor(org_pri_key_pem.encode())
            org_pri_key_sm2 = sm2_crypto.SM2PrivateKey.load(org_pri_key_bytes[2])
            org_pri_key = org_pri_key_sm2.value
            org_pri_key = self._parse_private_key(org_pri_key)

            log.info(f'私钥16进制: {org_pri_key}')

            # 加签
            crypt = sm2.CryptSM2(private_key=org_pri_key, public_key=org_pub_key, mode=1, asn1=True)
            sign_str = crypt.sign_with_sm3(sign_body.encode())
            sign_value = base64.b64encode(bytes.fromhex(sign_str)).decode()

            log.info(f'加签时签名: {sign_value}')

            kwargs['headers']['x-jlpay-appid'] = app_id
            kwargs['headers']['x-jlpay-nonce'] = random_string
            kwargs['headers']['x-jlpay-timestamp'] = time_stamp
            kwargs['headers']['x-jlpay-sign-alg'] = sign_type
            kwargs['headers']['x-jlpay-sign'] = sign_value
            kwargs['headers']['x-jlpay-key'] = key
            return request

    def _verify(self, response: str, **kwargs):
        jl_pub_key_pem = kwargs.get('public_key')
        sign_type = self.response_headers.get('x-jlpay-sign-alg')

        if sign_type == self.SignType.RSA256:
            log.info(f'RSA256加验签暂未实现')
        elif sign_type == self.SignType.SM3WithSM2WithDer:
            jl_pub_key_bytes = pem.unarmor(jl_pub_key_pem.encode())
            jl_pub_key_asn1, _ = decoder.decode(jl_pub_key_bytes[2])
            jl_pub_key = jl_pub_key_asn1[1].asOctets().hex()[2:]
            # 生成嘉联加签验签对象
            sm2_jl_crypt = sm2.CryptSM2(public_key=jl_pub_key, private_key=None, mode=1, asn1=True)

            sign_value = self.response_headers.get('x-jlpay-sign')
            time_stamp = self.response_headers.get('x-jlpay-timestamp')
            random_string = self.response_headers.get('x-jlpay-nonce')

            method = kwargs.get('method')
            uri = '/' + '/'.join(kwargs['url'].split('/')[3:])
            sign_body = f'{method}\n{uri}\n{time_stamp}\n{random_string}\n{response}\n'

            log.info(f'验签body: {sign_body}')
            log.info(
                f'验签结果: {sm2_jl_crypt.verify_with_sm3(base64.b64decode(sign_value).hex(), bytes(sign_body, encoding="utf8"))}')



