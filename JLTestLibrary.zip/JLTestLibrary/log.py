from robot.api import logger


def info(*data, html=False, also_console=False):
    logger.info(data[0] if len(data) == 1 else " ".join([str(d) for d in data]), html=html, also_console=also_console)


def error(*data, html=False):
    logger.error(data[0] if len(data) == 1 else " ".join([str(d) for d in data]), html=html)


def warn(*data, html=False):
    logger.warn(data[0] if len(data) == 1 else " ".join([str(d) for d in data]), html=html)


def info_type(msg, html=False, also_console=False):
    info(type(msg), msg, html=html, also_console=also_console)


def debug(*data, html=False):
    logger.debug(data[0] if len(data) == 1 else " ".join([str(d) for d in data]), html=html)
