sale_type = [
    ("1001", "0118"),
    ("1001", "0104"),
    ("1001", "1537"),
    ("1001", "1550"),
    ("1001", "1551"),
    ("1001", "1557"),
    ("1001", "1516"),
    ("1001", "1517"),
    ("1001", "1523"),
    ("1001", "1510"),
    ("1001", "1567"),
    ("1001", "0247"),
    ("1001", "1527"),
]
sale_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "SALE",
        "remark": "消费",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in sale_type
]

vsale_type = [("1001", "0106"), ("1001", "1539"), ("1001", "1553"), ("1001", "0120"), ("1001", "1559")]
vsale_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "VSALE",
        "remark": "消费撤销",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in vsale_type
]

refund_type = [
    ("1001", "0108"),
    ("1001", "1538"),
    ("1001", "1552"),
    ("1001", "1558"),
    ("1001", "1511"),
    ("1001", "1518"),
    ("1001", "1524"),
    ("1001", "1528"),
]
refund_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "REFUND",
        "remark": "退货",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in refund_type
]


auth_type = [("1001", "0109"), ("1001", "1571"), ("1001", "1581"), ("1001", "1582")]
auth_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "AUTH",
        "remark": "预授权",
        "amount": "1000",
        "fee": "0",
    }
    for busi_type, busi_sub_type in auth_type
]

vauth_type = [("1001", "0111"), ("1001", "1573")]
vauth_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "VAUTH",
        "remark": "预授权撤销",
        "amount": "1000",
        "fee": "0",
    }
    for busi_type, busi_sub_type in vauth_type
]

cauth_type = [("1001", "0113"), ("1001", "1572"), ("1001", "1583")]
cauth_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "CAUTH",
        "remark": "预授权完成",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in cauth_type
]

vcauth_type = [("1001", "0116"), ("1001", "1584")]
vcauth_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "VCAUTH",
        "remark": "预授权完成撤销",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in vcauth_type
]

rcauth_type = [("1001", "1585"), ("1001", "1586")]
rcauth_data = [
    {
        "busi_type": busi_type,
        "busi_sub_type": busi_sub_type,
        "trans_type": "RCAUTH",
        "remark": "预授权完成退款",
        "amount": "1000",
        "fee": "5",
    }
    for busi_type, busi_sub_type in rcauth_type
]
