from enum import Enum
from typing import List


class Status(str, Enum):
    """status"""

    SENT = "0"  # 已发送
    TO_CONFIRM = "1"  # 待确认
    SUCCESS = "2"  # 成功
    FAIL = "3"  # 失败
    CANCEL = "4"  # 已撤销
    REVERSAL = "5"  # 已冲正
    REFUND = "6"  # 已退货
    PRE_AUTH = "7"  # 预授权完成


trade_status_dealing = [Status.SENT, Status.TO_CONFIRM]
trade_status_success = [Status.SUCCESS, Status.CANCEL, Status.REFUND, Status.PRE_AUTH]
trade_status_fail = [Status.FAIL, Status.REVERSAL]

trade_status = [Status.SUCCESS, Status.CANCEL, Status.REFUND]
# trade_fee_calc_type=["01","02","03","04","05","30","31"]
# trade_busi_sub_type=["0104","0106","0108","1586","0111","0116","0109"]
trade_fee_calc_type = ["01", "02"]
trade_busi_sub_type = ["0104", "0106"]

fund_debit_credit_flag = ["C", "D"]


class OrderPayType(str, Enum):
    """paytypes"""

    WX_PAY = "wxpay"
    ALI_PAY = "alipay"
    UNION_PAY = "unionpay"
    BANK_PAY = "bankpay"


class FeeCalcType(str, Enum):
    WX_PAY = "30"
    ALI_PAY = "31"
    INTERNAL_DEBIT_CARD = "01"  # 内网借记卡
    INTERNAL_CREDIT_CARD = "02"  # 内网贷记卡
    UNION_PAY = "03"  # 银联二维码
    UNION_CREDIT_CARD = "04"  # 云闪付贷记卡
    UNION_DEBIT_CARD = "05"  # 云闪付借记卡


class BusiSubType(list, Enum):
    # 消费
    SALE = ["0104", "0118", "1516", "1517", "1523", "1510", "1567", "1537", "1550", "1551", "1557", "0247", "1527"]
    # 消费撤销
    VSALE = ["0106", "0120", "1539", "1553", "1559"]
    # 退货
    REFUND = ["0108", "1538", "1552", "1558", "1511", "1518", "1524", "1528"]
    # 预授权完成退款
    RCAUTH = ["1586"]
    # 预授权撤销
    VAUTH = ["0111", "1573", "1584"]
    # 预授权完成
    CAUTH = ["0113", "1572", "1583"]
    # 预授权完成撤销
    VCAUTH = ["0116"]
    # 预授权
    AUTH = ["0109", "1571", "1581", "1582"]
