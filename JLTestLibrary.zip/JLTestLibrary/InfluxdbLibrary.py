import json
from typing import Union

from influxdb import InfluxDBClient
from robot.api.deco import keyword

from . import log
from .UtilsMsg import UtilsMsg


class InfluxdbLibrary:
    def __init__(self) -> None:
        self.influxdb_client = None

    @keyword
    def influxdb_init_host(self, conn_config: Union[str, dict]):
        """初始化influxdb连接

        | Influxdb Init Host | {"host":"ts-wz9lbgyrvt25e14o6.influxdata.rds.aliyuncs.com","port":3242,"username":"admin","password":"admin#20220810","ssl":true} |

        - conn_config: 连接信息
        """
        config = UtilsMsg.str_to_dict(conn_config)
        host = config.get('host')
        port = config.get('port', 8086)
        username = config.get('username', 'root')
        password = config.get('password', 'root')
        database = config.get('database')
        ssl = config.get('ssl', False)
        timeout = config.get('timeout', 8)
        log.info(config)
        self.influxdb_client = InfluxDBClient(
            host=host, port=port, username=username, password=password, database=database, ssl=ssl, timeout=timeout
        )

    @keyword
    def influxdb_query(
        self,
        query: str,
        params: dict = {},
        bind_params: dict = {},
        database: str = "",
    ) -> list:
        """influxdb查询

        | ${result} | Influxdb Query | SELECT sum(AMOUNT)as amount, sum(CNT)as cnt FROM ads_pay_fin_ppr."180d".t_excess_reserves_trd_1h WHERE time >= '2023-03-12T20:00:00Z' and time <= '2023-03-12T23:59:59Z' tz('Asia/Shanghai') |
        | Log | ${result}[0][time] | |

        - query: the actual query string
        - params: additional parameters for the request, defaults to {}
        - bind_params: bind parameters for the query: any variable in the query written as '$var_name' will be replaced with bind_params['var_name']. Only works in the WHERE clause and takes precedence over params['params']
        - database: database to query, defaults to ""
        - raises RuntimeError: 未先初始化会报错
        - return: 返回查询的列表
        """
        if not self.influxdb_client:
            raise RuntimeError("请先使用关键字初始化 influxdb_client")
        result = self.influxdb_client.query(
            query=query,
            params=params,
            bind_params=bind_params,
            database=database,
        )
        points = list(result.get_points())
        log.info(f"Result: {points}")
        return points
