# import imp
# import json
# import traceback
# from typing import Union

# import requests
# from robot.api.deco import keyword

# from . import log
# from .UtilsLibrary import UtilsLibrary
# from .UtilsMsg import UtilsMsg


# class ApolloLibrary:
#     ROBOT_LIBRARY_SCOPE = "GLOBAL"

#     def __init__(self):
#         self.apl_url = ""
#         self.apl_header = {"Content-Type": "application/json;charset=UTF-8", "Authorization": ""}

#     @keyword
#     def init_config(self, url: str, token: str) -> None:
#         """初始化配置

#         - url:接口的url
#         - token:接口的令牌字段
#         """
#         self.apl_url = url
#         self.apl_header["Authorization"] = token

#     @keyword
#     def create_method_par(self, kwargs: Union[str, dict]) -> None:
#         """apollo创建参数

#         - kwargs:需要配置的参数
#         """
#         try:
#             resp_msg = {"ret_code": "01"}
#             kwargs = UtilsMsg.str_to_dict(kwargs)
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/items" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#             )
#             data = {
#                 "key": kwargs["key"],
#                 "value": kwargs["value"],
#                 "comment": kwargs["comment"],
#                 "dataChangeCreatedBy": kwargs["user"],
#             }
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             print(UtilsLibrary.time_strft(), "Request Data:", data)
#             msg = requests.post(url=req_url, headers=self.apl_header, data=json.dumps(data), timeout=5)

#             # 状态返回400，说明该参数已提交
#             if msg.status_code == 200 or msg.status_code == 400:
#                 resp_msg["ret_code"] = "00"
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo创建参数失败!: {str(e)}")

#     @keyword
#     def delete_method_par(self, kwargs: dict) -> None:
#         """apollo删除参数

#         - kwargs:需要删除的参数
#         """
#         try:
#             resp_msg = {"ret_code": "01"}
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/items/%s?operator=%s" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#                 kwargs["key"],
#                 kwargs["user"],
#             )
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             msg = requests.delete(url=req_url, headers=self.apl_header, timeout=5)
#             # 状态返回400，该参数已删除
#             if msg.status_code == 200 or msg.status_code == 400:
#                 resp_msg["ret_code"] = "00"
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo删除参数失败!: {str(e)}")

#     @keyword
#     def modify_method_par(self, kwargs: Union[str, dict]) -> dict:
#         """提供修改能力

#         使用该方法，需要在apollo上对该appid进行授权操作，否则访问直接报403错误码；

#         - kwargs:待修改的参数
#         - return:返回响应码 00表示修改成功
#         """
#         try:
#             resp_msg = {"ret_code": "01"}
#             kwargs = UtilsMsg.str_to_dict(kwargs)

#             data = {
#                 "key": kwargs["key"],
#                 "value": kwargs["value"],
#                 "comment": kwargs["comment"],
#                 "createIfNotExists": True,  # 当配置不存在时是否自动创建
#                 "dataChangeCreatedBy": kwargs["user"],
#                 "dataChangeLastModifiedBy": kwargs["user"],
#             }
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/items/%s" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#                 kwargs["key"],
#             )
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             print(UtilsLibrary.time_strft(), "Request Data:", data)
#             msg = requests.put(url=req_url, headers=self.apl_header, data=json.dumps(data), timeout=5)
#             if msg.content.decode() == "":
#                 # 生效操作
#                 resp_msg["ret_code"] = "00"
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)
#             return resp_msg

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo参数修改失败!: {str(e)}")

#     @keyword
#     def query_method_par(self, kwargs: Union[str, dict]):
#         """提供查询能力

#         - kwargs:待查询的参数
#         - return:查询返回的响应内容
#         """
#         try:
#             kwargs = UtilsMsg.str_to_dict(kwargs)
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/items/%s" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#                 kwargs["key"],
#             )
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             resp_msg = requests.get(url=req_url, headers=self.apl_header, timeout=5)
#             resp_msg = UtilsMsg.byte_to_dict(resp_msg.content)
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)
#             return resp_msg
#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo查询失败!: {str(e)}")

#     # 对修改配置，进行发布操作
#     @keyword
#     def modify_method_release(self, kwargs: Union[str, dict]):
#         try:
#             kwargs = UtilsMsg.str_to_dict(kwargs)
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/releases" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#             )
#             data = {
#                 "releaseTitle": kwargs["releaseTitle"],
#                 "releaseComment": kwargs["releaseComment"],
#                 "releasedBy": kwargs["user"],
#             }
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             print(UtilsLibrary.time_strft(), "Request Data:", data)
#             msg = requests.post(url=req_url, headers=self.apl_header, data=json.dumps(data), timeout=5)
#             resp_msg = UtilsMsg.byte_to_dict(msg.content)
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)
#             return resp_msg

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo参数生效失败!: {str(e)}")

#     # 对修改配置，进行发布操作
#     @keyword
#     def modify_method_release_latest(self, kwargs: Union[str, dict]):
#         try:
#             kwargs = UtilsMsg.str_to_dict(kwargs)
#             url = "/openapi/v1/envs/%s/apps/%s/clusters/%s/namespaces/%s/releases/latest" % (
#                 kwargs["env"],
#                 kwargs["appid"],
#                 kwargs["clusterName"],
#                 kwargs["namespaceName"],
#             )
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             msg = requests.get(url=req_url, headers=self.apl_header, timeout=5)
#             resp_msg = UtilsMsg.byte_to_dict(msg.content)
#             print(UtilsLibrary.time_strft(), "Response Msg:", resp_msg)
#             return resp_msg

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo参数生效失败!: {str(e)}")

#     @keyword
#     def modify_method_release_rollback(self, kwargs: Union[str, dict]) -> None:
#         """对已生效配置进行回滚操作"""
#         try:
#             kwargs = UtilsMsg.str_to_dict(kwargs)
#             url = "/openapi/v1/envs/%s/releases/%s/rollback" % (kwargs["env"], kwargs["releaseId"])
#             data = {"operator": kwargs["user"]}
#             req_url = self.apl_url + url
#             print(UtilsLibrary.time_strft(), "Request Url:", req_url)
#             print(UtilsLibrary.time_strft(), "Request Data:", data)
#             msg = requests.put(url=req_url, headers=self.apl_header, data=json.dumps(data), timeout=5)
#             print(UtilsLibrary.time_strft(), "Response Msg:", msg)

#         except Exception as e:
#             log.warn(traceback.format_exc())
#             raise RuntimeError(f"apollo已生效配置进行回滚操作失败!: {str(e)}")
