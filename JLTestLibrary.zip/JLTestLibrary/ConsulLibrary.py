import consul
from robot.api.deco import keyword


class ConsulLibrary:
    """可用性待确认"""

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        """初始化，连接consul服务器"""
        self.consul_connect = None
        self.consul_host = "172.20.20.34"
        self.consul_port = 8500

    @keyword
    def resp_consul_data(self):
        self.consul_connect = consul.Consul(self.consul_host, self.consul_port)
        data = self.consul_connect.kv.get("test-configuration/34.10-configuration")
        print(data[1]["Value"])


# test-configuration
if __name__ == "__main__":
    c = ConsulLibrary()
    c.resp_consul_data()
