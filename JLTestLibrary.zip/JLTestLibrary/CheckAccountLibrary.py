import os

from robot.api.deco import keyword

from . import log
from .FtpLibrary import FtpLibrary
from .RpcLibrary import RpcLibrary
from .ZkLibrary import ZkLibrary


class CheckAccountLibrary:
    """该库未完成"""

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def ftp_upload_file(self, path, localfilename):
        f = FtpLibrary()
        f.connect_to_ftp("172.20.20.114", "21", "ftp_admin", "111111")
        f.upload_file(localfilename, path + localfilename)

    def make_zip(self, data, filename, date):
        if os.path.exists(filename.format(date=date)):
            os.remove(filename.format(date=date))
        if os.path.exists(filename.format(date=date) + ".Z"):
            os.remove(filename.format(date=date) + ".Z")
        with open(filename.format(date=date), "w") as f:
            f.write(data)
        self.ftp_upload_file("/upay/source_file/48494900/20210705/", filename.format(date=date))

    def make_union_chn_bills(self, date):
        # path = 'D:/Workspace/20210705/'
        ACOMX = "48493000    00049992    104333 0705122810 6226552002699770    000001137500 000000000000  00000000000 0200 000000 5499 60407002 849305054991154 950571622415 00 000000 63030000    000000 00 042 000000000000 000000000068 D00000000005 1 000 0 0 0000000000 63030000    0 03     00000000000  00000224001                          411037943426950571622415                 0301                                                                                                                                     0                                                                                                                                                                                                                                                                                                                                     38210705448901043332                                                                                                                                                                         \n"  # 84941017011K0D4
        self.make_zip(ACOMX, "IND{date}01ACOMX", date)
        ACOMA = ""
        self.make_zip(ACOMA, "IND{date}32ACOMA", date)
        AERRA = ""
        self.make_zip(AERRA, "IND{date}32AERRA", date)
        AERRX = ""
        self.make_zip(AERRX, "IND{date}99AERRX", date)
        # ALFEE = '            0 02 08 3 0 7011             48494900    00049992    04012902    04012902    48494900    0200 000000 00 573908 0705121906 6251642018007601                                                              000000000000000000000084849490000800049992 01080209 84941017011K0D4 154602967357 000000010100              D00000000002                            2                                                                                                    \n'
        ALFEE = ""
        self.make_zip(ALFEE, "IND{date}99ALFEE", date)
        FCP = ""
        self.make_zip(FCP, "IND{date}99FCP", date)
        # B = '000800048494900   2021070520210705PROD000000010018000000000000200000000000000000000000000000000\n'
        B = ""
        self.make_zip(B, "INF{date}51B", date)
        OSUM = ""
        self.make_zip(OSUM, "INO{date}98OSUM", date)
        ZDPSUM = ""
        self.make_zip(ZDPSUM, "INO{date}99ZDPSUM", date)
        ZHACSUM = ""
        self.make_zip(ZHACSUM, "INO{date}99ZHACSUM", date)
        ZPSUM = ""
        self.make_zip(ZPSUM, "INO{date}99ZPSUM", date)

    def swiftpass_down_file(self, startDate, endDate, zk_host, node_url="/xdata/check/down-acc-file"):
        zk = ZkLibrary()
        log.info("zk地址: %s" % zk_host)
        zk.zk_init_hosts(zk_host)
        ip, port = zk.query_nodes(node_url)
        msg = "node:" + node_url + ";  rpc request address:" + ip + ":" + port
        log.info(msg)
        r = RpcLibrary()
        req_msg = {
            "command_id": "ftpUploadHdfsServer",
            "offset": 1,
            "endDate": endDate,
            "limit": 1,
            "isCheckAccount": "N",
            "chnOrgCode": "48494900",
            "startDate": startDate,
        }
        resp_msg = r.rpc_client_invoke(ip, int(port), req_msg)
        print(resp_msg)

    def union_all(self, beginDate, endDate, zk_host, node_url="/xdata/rpc/spark_task_new"):
        zk = ZkLibrary()
        log.info("zk地址: %s" % zk_host)
        zk.zk_init_hosts(zk_host)
        ip, port = zk.query_nodes(node_url)
        msg = "node:" + node_url + ";  rpc request address:" + ip + ":" + port
        log.info(msg)
        r = RpcLibrary()
        # req_msg = {"commandId":"spark_submit_task","taskParameter":{"beginDate":beginDate,"endDate":endDate,"serverName":"com.jlpay.action.union.command.UnionCommandAction","isAnewCheck":"Y","chnOrgCode":"48494900","sparkTaskId":"10000008"},"taskDetailId":"61","taskCode":"10000008"}
        req_msg = {
            "taskCode": "10000008",
            "taskParameter": {
                "beginDate": beginDate,
                "endDate": endDate,
                "serverName": "com.jlpay.action.union.command.UnionCommandAction",
                "isAnewCheck": "Y",
                "chnOrgCode": "48494900",
                "sparkTaskId": "10000008",
            },
            "commandId": "spark_submit_task",
            "taskDetailId": "61",
            "command_id": "spark_submit_task",
            "taskName": "银联-对账-ALL-高级别",
        }
        resp_msg = r.rpc_client_invoke(ip, int(port), req_msg)
        print(resp_msg)

    def query_union_status(self, zk_host, node_url="/xdata/rpc/spark_task_new"):
        zk = ZkLibrary()
        log.info("zk地址: %s" % zk_host)
        zk.zk_init_hosts(zk_host)
        ip, port = zk.query_nodes(node_url)
        msg = "node:" + node_url + ";  rpc request address:" + ip + ":" + port
        log.info(msg)
        r = RpcLibrary()
        req_msg = {"command_id": "spark_log_page_query", "taskCode": "10000008", "limit": "1"}
        resp_msg = r.rpc_client_invoke(ip, int(port), req_msg)
        print(resp_msg)


if __name__ == "__main__":
    c = CheckAccountLibrary()
    # c.make_union_chn_bills('210705')
    # c.swiftpass_down_file('20210705', '20210706', '172.20.20.37:2181')
    # time.sleep(5)
    # c.union_all('20210705', '20210706', '172.20.20.37:2181')
    c.query_union_status("172.20.20.37:2181")
