import traceback

import paramiko
from robot.api.deco import keyword

from JLTestLibrary.UtilsLibrary import UtilsLibrary
from JLTestLibrary.UtilsMsg import UtilsMsg

from . import log


class SSHLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.ssh = None
        self.ssh_transport = None

    @keyword
    def login_ssh(self, host_name, port, username, password):
        """SSH登录

        - hostname: 主机名
        - port: 端口
        - username: 用户名
        - password: 密码

        """
        try:
            # 实例化ssh客户端
            self.ssh = paramiko.SSHClient()
            # 创建默认的白名单
            policy = paramiko.AutoAddPolicy()
            # 设置白名单
            self.ssh.set_missing_host_key_policy(policy)
            # 链接服务器
            self.ssh.connect(
                hostname=host_name,  # 服务器的ip
                port=int(port),  # 服务器的端口
                username=username,  # 服务器的用户名
                password=password,  # 用户名对应的密码
            )
            if self.ssh is None:
                log.info("创建SSH链接失败！")
            else:
                log.info("ssh链接创建成功！")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"创建SSH链接失败!: {str(e)}")

    @keyword
    def ssh_command(self, command):
        """远程执行命令

        - command: 命令字符串

        """
        try:
            # 远程执行命令
            log.info("Command:", command)
            stdin, stdout, stderr = self.ssh.exec_command(command, timeout=30)
            output = stdout.read().decode()
            err_output = stderr.read().decode()
            log.info("Command Result:", output)
            if err_output:
                log.error("StdErr Result:", err_output)
            # 去掉返回消息体多余的"\n"
            result = output.strip()
            return result
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"执行命令失败!: {str(e)}")

    @keyword
    def sftp_connect(self, hostname, port, username, password):
        """建立SFTP连接

        - hostname: 主机名
        - port: 端口
        - username: 用户名
        - password: 密码

        """
        try:
            self.ssh_transport = paramiko.Transport((hostname, int(port)))
            self.ssh_transport.connect(username=username, password=password)
            self.sftp = paramiko.SFTPClient.from_transport(self.ssh_transport)

            if self.ssh is None:
                log.info("创建SFTP链接失败！")
            else:
                log.info("SFTP链接创建成功！")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"创建SFTP链接失败!: {str(e)}")

    @keyword
    def sftp_file_upload(self, localpath, remotepath):
        """文件上传功能

        - localpath: 本地文件路径
        - remotepath: 远程文件路径
        - return: None
        """
        try:
            self.sftp.put(localpath, remotepath)
            log.info(f"{localpath}, 上传文件成功！")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"sftp方式上传文件失败!: {str(e)}")
        finally:
            self.ssh_transport.close()

    @keyword
    def localpath_removefile(self, localpath):
        """对文件进行删除操作

        - localpath: 本地文件路径

        """
        UtilsMsg.os_file_remove(localpath)

    @keyword
    def query_namespace_pod(self, namespace, pod_name):
        """获取到该命令空间，对应的pod信息

        - namespace: 命令空间名字
        - pod_name: pod名字
        - return: podname [list] pod信息
        """
        cmd = "kubectl get pod -n " + namespace + " | grep " + pod_name
        log.info("Create command:{}", cmd)
        result = self.ssh_command(cmd)
        pod_name = result.split(" ")[0]
        return pod_name

    @keyword
    def ssh_shutdown_flink(
        self,
        flink_job_name: str,
        sub_job_name: str,
    ):
        """停止flink程序并删除缓存

        - flink_job_name: 例如 xdata-dws-pay
        - sub_job_name: 一般为 group

        例:
        | Login Ssh | 172.20.7.36 | 22 | cloudera | cdh#514 |
        | Ssh Shutdown Flink | xdata-dws-pay | group |

        """
        self.ssh_command(
            f"source /etc/profile && cd /home/cloudera/flink-1.13.2-k8s && flink_job_name={flink_job_name} sub_job_name={sub_job_name} && echo 'stop' | ./bin/kubernetes-session.sh -Dkubernetes.cluster-id=flink-${{flink_job_name}}-${{sub_job_name}} -Dexecution.attached=true -Dkubernetes.namespace=flink-session-cluster"
        )
        self.ssh_command(
            f"source /etc/profile && sudo -u hdfs hdfs dfs -rm -r  /user/flink/checkpoints/{flink_job_name}-{sub_job_name}"
        )
        self.ssh_command(
            f"source /etc/profile && sudo -u hdfs hdfs dfs -rm -r /user/flink/recovery/{flink_job_name}-{sub_job_name}"
        )
        self.ssh_command(
            f"source /etc/profile && sudo -u hdfs hdfs dfs -rm -r /user/flink/savepoints/{flink_job_name}-{sub_job_name}"
        )

    @keyword
    def ssh_start_flink(
        self,
        flink_job_name: str,
        sub_job_name: str,
        image_name: str = 'registry.jlpay.io/xdata/xdata-data-distribution-branch_exp:219131-a3b12b7d',
    ):
        """启动flink程序

        - flink_job_name: 例如 xdata-dws-pay
        - sub_job_name: 一般为 group
        - image_name: 容器镜像, 默认为registry.jlpay.io/xdata/xdata-data-distribution-branch_exp:219131-a3b12b7d

        例:
        | Login Ssh | 172.20.7.36 | 22 | cloudera | cdh#514 |
        | Ssh Shutdown Flink | xdata-dws-pay | group |
        | # 删除zk等 |
        | Ssh Start Flink | xdata-dws-pay | group |

        """
        self.ssh_command(
            f"""source /etc/profile && cd /home/cloudera/flink-1.13.2-k8s && flink_job_name={flink_job_name} && sub_job_name={sub_job_name} && timestamp=`date +%s` \
            ./bin/flink run-application \
            -t kubernetes-application \
            -Dkubernetes.namespace=flink-session-cluster \
            -Dkubernetes.jobmanager.service-account=flink \
            -Dkubernetes.cluster-id=flink-${{flink_job_name}}-${{sub_job_name}} \
            -Dkubernetes.container.image.pull-policy=IfNotPresent \
            -Dkubernetes.taskmanager.cpu=1 \
            -Dkubernetes.container.image={image_name} \
            -Dkubernetes.pod-template-file=pod-template.yaml \
            -Dkubernetes.jobmanager.node-selector='nodetype:flink' \
            -Dkubernetes.taskmanager.node-selector='nodetype:flink' \
            -Dkubernetes.jobmanager.tolerations='key:type,operator:Equal,value:xdata,effect:NoSchedule' \
            -Dkubernetes.taskmanager.tolerations='key:type,operator:Equal,value:xdata,effect:NoSchedule' \
            -Dstate.savepoints.dir=hdfs://nameserviceDEV/user/flink/savepoints/${{flink_job_name}}-${{sub_job_name}} \
            -Dstate.checkpoints.dir=hdfs://nameserviceDEV/user/flink/checkpoints/${{flink_job_name}}-${{sub_job_name}} \
            -Dmetrics.reporter.promgateway.jobName=flink-${{flink_job_name}}-${{sub_job_name}}-${{timestamp}} \
            -Denv.hadoop.conf.dir=/opt/flink/hadoop.conf.dev \
            -Dkubernetes.rest-service.exposed.type=NodePort \
            -Djobmanager.memory.process.size=2g \
            -Dtaskmanager.memory.process.size=3g \
            -Dtaskmanager.numberOfTaskSlots=3 \
            -Dtaskmanager.memory.network.fraction=0.1 \
            -Dtaskmanager.memory.network.min=128m \
            -Dtaskmanager.memory.network.max=128m \
            -Dclassloader.parent-first-patterns.default="java.;scala.;com.esotericsoftware.kryo;org.apache.hadoop.;javax.annotation.;org.slf4j;org.apache.log4j;org.apache.logging;org.apache.commons.logging;ch.qos.logback;org.xml;javax.xml;org.apache.xerces;org.w3c" \
            local:///opt/flink/usrlib/distribution-core-1.0.0.jar \
            --app.id XDATA.{flink_job_name}-{sub_job_name}"""
        )
