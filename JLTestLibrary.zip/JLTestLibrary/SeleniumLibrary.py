import json
import os
import sys
import time
import zipfile
from functools import wraps
from json import JSONDecodeError

import openpyxl
from robot.api.deco import keyword
from selenium import webdriver
from selenium.common.exceptions import (
    ElementClickInterceptedException,
    ElementNotInteractableException,
    NoSuchElementException,
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.select import Select

from . import log

PLATFORM = sys.platform
download_path = "D:\\"


def screenshot(func):
    """
    失败自动截图
    """

    @wraps(func)
    def inner(self, *args, **kwargs):
        try:
            f = func(self, *args, **kwargs)
            return f
        except (
            NoSuchElementException,
            ElementClickInterceptedException,
            ElementNotInteractableException,
            AssertionError,
        ) as err:
            self.web_get_screen_shot()
            raise err

    return inner


class SeleniumLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def _set_chrome_options(self, gui: bool = False):
        """配置chrome

        - gui: 是否有运行界面

        """

        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--ignore-certificate-errors")
        chrome_options.add_argument("--disable-infobars")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        prefs = {"download.default_directory": download_path}
        chrome_options.add_experimental_option("prefs", prefs)
        chrome_options.add_argument("--no-sandbox")
        if not gui:
            log.info("无界面运行: %s" % True, also_console=True)
            chrome_options.add_argument("--headless")
        if "linux" in PLATFORM:
            chrome_options.add_argument("--disable-dev-shm-usage")
        log.info(f"chrome options 配置：{chrome_options.arguments} {chrome_options.experimental_options}")
        return chrome_options

    def _set_firefox_options(self, gui: bool = False):
        """配置firefox

        - gui: 是否有运行界面

        """
        firefox_options = webdriver.FirefoxOptions()
        firefox_options.accept_insecure_certs = True
        firefox_prof = webdriver.FirefoxProfile(None)
        firefox_prof.set_preference("security.fileuri.strict_origin_policy", False)
        firefox_prof.set_preference("privacy.file_unique_origin", False)
        firefox_options.profile = firefox_prof
        if not gui:
            log.info("无界面运行: %s" % True, also_console=True)
            firefox_options.add_argument("--headless")
        log.info(f"firefox options 配置：{firefox_options.arguments}")
        return firefox_options

    def _remote_driver(self, remote_url: str, desired_capabilities: str, defaul_caps: dict, options: Options):
        """获取远程驱动

        - remote_url: 远端连接地址
        - desired_capabilities: 所需功能，https://github.com/SeleniumHQ/selenium/wiki/DesiredCapabilities
        - defaul_caps: 更新的功能参数
        - options: options.Options的实例对象

        """
        if remote_url:
            if desired_capabilities:
                try:
                    caps = json.loads(desired_capabilities)
                    defaul_caps.update(caps)
                except JSONDecodeError as e:
                    raise ValueError(f"{e.doc}: position {e.pos} {e.msg}")

            return webdriver.Remote(remote_url, defaul_caps, options=options)

    def _make_driver(self, browser: str, desired_capabilities: str, remote_url: str, options: Options):
        """创建WebDriver对象

        - brower: 浏览器类型
        - desired_capabilities: 所需功能，https://github.com/SeleniumHQ/selenium/wiki/DesiredCapabilities
        - remote_url: 远程连接地址
        - options: options.Options的实例对象

        """
        browser = browser.lower()
        default_caps = {}
        if browser == "headless_chrome":
            if not options:
                options = self._set_chrome_options()
            default_caps = DesiredCapabilities.CHROME.copy()
            if remote_url:
                return self._remote_driver(remote_url, desired_capabilities, default_caps, options)
            return webdriver.Chrome(options=options)
        if browser == "chrome":
            if not options:
                options = self._set_chrome_options(gui=True)
            default_caps = DesiredCapabilities.CHROME.copy()
            if remote_url:
                return self._remote_driver(remote_url, desired_capabilities, default_caps, options)
            return webdriver.Chrome(options=options)
        if browser == "headless_firefox":
            if not options:
                options = self._set_firefox_options()
            default_caps = DesiredCapabilities.FIREFOX.copy()
            if remote_url:
                return self._remote_driver(remote_url, desired_capabilities, default_caps, options)
            return webdriver.Firefox(options=options)
        if browser == "firefox":
            if not options:
                options = self._set_firefox_options(gui=True)
            default_caps = DesiredCapabilities.FIREFOX.copy()
            if remote_url:
                return self._remote_driver(remote_url, desired_capabilities, default_caps, options)
            return webdriver.Firefox(options=options)
        raise WebDriverException(f"测试库暂未支持浏览器 {browser}")

    @keyword
    def web_open_browser(
        self,
        url: str,
        browser: str = "headless_chrome",
        remote_url: str = None,
        desired_capabilities: str = None,
        options: Options = None,
    ):
        """打开浏览器 -> 打开url -> 等待页面加载成功

        - url: 远程连接地址

        - browser: 要使用的浏览器，如：chrome、firefox、headless_chrome、headless_firefox

        - remote_url: 远程Selenium Grid的URL

        - desired_capabilities: 所需功能，https://github.com/SeleniumHQ/selenium/wiki/DesiredCapabilities

        - options: options.Options的实例对象

        Examples:
        | `Open Browser` | http://example.com | Chrome  | gui=True                                |
        | `Open Browser` | http://example.com | Firefox | remote_url=http://127.0.0.1:4444/wd/hub |

        """
        if remote_url:
            log.info("使用远程server {2} 打开浏览器 {0} 并访问url {1}".format(browser, url, remote_url), also_console=True)
        else:
            log.info("打开浏览器 {0} 并访问url {1}".format(browser, url), also_console=True)
        self.driver = self._make_driver(browser, desired_capabilities, remote_url, options)
        self.driver.get(url)
        # self.driver.set_window_size(1024, 720)
        self.driver.maximize_window()
        self.__wait_for_ready_state_complete()

    def __wait_for_ready_state_complete(self, timeout=30):
        """
        等待页面加载完成

        Args:
            timeout: 超时时间
        Returns:
            bool
        """
        if timeout == "" or not timeout:
            timeout = 30
        start_ms = time.time() * 1000.0
        stop_ms = start_ms + (timeout * 1000.0)
        for x in range(int(timeout * 10)):
            try:
                ready_state = self.driver.execute_script("return document.readyState")
            except WebDriverException:
                time.sleep(0.03)
                return True
            if ready_state == "complete":
                time.sleep(0.05)
                return True
            else:
                now_ms = time.time() * 1000.0
                if now_ms >= stop_ms:
                    break
                time.sleep(0.1)
        return False

    @keyword
    def web_find_element(self, locator):
        """
        查找元素

        Args:
            locator: 定位器
        Returns:
            WebElement object
        """
        if "id:" in locator:
            preffix, by = "id:", By.ID
        elif "class:" in locator:
            preffix, by = "class:", By.CLASS_NAME
        elif "name:" in locator:
            preffix, by = "name:", By.NAME
        elif "xpath:" in locator:
            preffix, by = "xpath:", By.XPATH
        elif "text:" in locator:
            preffix, by = "text:", By.XPATH
        elif "css:" in locator:
            preffix, by = "css:", By.CSS_SELECTOR
        else:
            raise ValueError("定位器 %s 可能有误" % locator)
        try:
            value = locator.replace(preffix, "")
            if preffix == "text:":
                value = '//*[contains(text(), "{0}")]'.format(value)
            element = self.driver.find_element(by, value)
        except WebDriverException as err:
            msg = "元素 {0} 未找到".format(locator)
            err.args = (msg,)
            raise err
        return element

    @keyword
    def web_wait_for_element_visible(self, locator, timeout=10):
        """
        等待元素可见

        Args:
            locator: 定位器
            timeout: 超时时间
        Returns:
            WebElement object
        """
        if timeout == "" or not timeout:
            timeout = 10
        element = None
        is_present = False
        start_ms = time.time() * 1000.0
        if isinstance(timeout, str):
            timeout = int(timeout)
        stop_ms = start_ms + (timeout * 1000.0)
        for x in range(int(timeout * 10)):
            try:
                element = self.web_find_element(locator)
                is_present = True
                if element.is_displayed():
                    return element
                else:
                    element = None
                    raise Exception()
            except Exception as err:
                now_ms = time.time() * 1000.0
                if now_ms >= stop_ms:
                    break
                time.sleep(0.1)
        if not element:
            if not is_present:
                # element not exist in HTML
                message = "元素 {0} 在 {1} 秒后未出现".format(locator, timeout)
                raise NoSuchElementException(message)
            message = "元素 {0} 在 {1} 秒后未可见".format(locator, timeout)
            raise NoSuchElementException(message)
        return element

    @keyword
    def web_wait_for_element_present(self, locator, timeout=10):
        """
        等待元素出现

        Args:
            locator: 定位器
            timeout: 超时时间
        Returns:
            WebElement object
        """
        if timeout == "" or not timeout:
            timeout = 10
        element = None
        start_ms = time.time() * 1000.0
        if isinstance(timeout, str):
            timeout = int(timeout)
        stop_ms = start_ms + (timeout * 1000.0)
        for x in range(int(timeout * 10)):
            try:
                element = self.web_find_element(locator)
                return element
            except Exception:
                now_ms = time.time() * 1000.0
                if now_ms >= stop_ms:
                    break
                time.sleep(0.1)
        if not element:
            # element not exist in HTML
            message = "元素 {0} 在 {1} 秒后未出现".format(locator, timeout)
            raise NoSuchElementException(message)

    @screenshot
    @keyword
    def web_click_element(self, locator, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> 点击元素

        Args:
            locator: 定位器
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_visible(locator, timeout=timeout)
        msg = "点击元素 {0}".format(locator)
        log.info(msg, also_console=True)
        try:
            element.click()
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            log.info("Click after StaleElementReferenceException")
            element.click()
        except ElementClickInterceptedException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            log.info("Click after ElementClickInterceptedException")
            element.click()

    @screenshot
    @keyword
    def web_select_from_list_by_visible_text(self, locator, text, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> 下拉菜单选择

        Args:
            locator: 定位器
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        select = self.web_wait_for_element_visible(locator, timeout=timeout)
        msg = "下拉菜单 {0} 选择 {1}".format(locator, text)
        log.info(msg, also_console=True)
        try:
            Select(select).select_by_visible_text(text)
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            Select(select).select_by_visible_text(text)

    @screenshot
    @keyword
    def web_input_text(self, locator, text, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> 清空文本 -> 输入文本

        Args:
            locator: 定位器
            text: 要输入的文本
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_visible(locator, timeout=timeout)
        msg = "输入 {0} 到元素 {1} 中".format(text, locator)
        log.info(msg, also_console=True)
        log.info(repr(text))
        try:
            element.clear()
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.clear()
        try:
            element.send_keys(text)
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.send_keys(text)

    @keyword
    def web_switch_to_frame_of_element(self, locator):
        """
        遍历iframe -> 切换到元素所在的iframe

        Args:
            locator: 元素的定位器
        Returns:
            iframe_identifier: iframe的标识符
        """
        self.driver.switch_to.default_content()
        from bs4 import BeautifulSoup

        source = self.driver.page_source
        soup = BeautifulSoup(source, "html.parser")
        iframe_list = soup.select("iframe")
        for iframe in iframe_list:
            iframe_identifier = None
            if iframe.has_attr("name") and len(iframe["name"]) > 0:
                iframe_identifier = iframe["name"]
            elif iframe.has_attr("id") and len(iframe["id"]) > 0:
                iframe_identifier = iframe["id"]
            elif iframe.has_attr("class") and len(iframe["class"]) > 0:
                iframe_class = " ".join(iframe["class"])
                iframe_identifier = '[class="%s"]' % iframe_class
            else:
                continue
            try:
                log.info("切换到 %s" % iframe_identifier, also_console=True)
                self.driver.switch_to.frame(iframe_identifier)
                time.sleep(0.5)  # 有时候找不到元素，switch后加下等待
                self.__wait_for_ready_state_complete()
                element = self.web_find_element(locator)
                if element:
                    log.info("已切换到元素所在的iframe", also_console=True)
                    return iframe_identifier
            except Exception:
                pass
            self.driver.switch_to.default_content()

    @screenshot
    @keyword
    def web_input_calendar(self, locator, text, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> js移除readonly属性 -> 输入文本到日历

        Args:
            locator: 定位器
            text: 要输入的日期，参考格式：2021-01-01 00:00:00
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_visible(locator, timeout=timeout)
        self.driver.execute_script("arguments[0].removeAttribute('readonly');", element)
        msg = "输入 {0} 到日历 {1} 中".format(text, locator)
        log.info(msg, also_console=True)
        log.info(repr(text))
        time.sleep(0.5)
        try:
            element.clear()
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.clear()
        try:
            element.send_keys(text + "\r")
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.send_keys(text + "\r")

    @screenshot
    @keyword
    def web_get_text(self, locator, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> 获取元素文本

        Args:
            locator: 定位器
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_visible(locator, timeout=timeout)
        msg = "获取元素 {0} 的文本".format(locator)
        log.info(msg, also_console=True)
        try:
            element_text = element.text
        except StaleElementReferenceException:
            # 页面元素未刷新出来，就对元素进行捕获，因此引发该异常    处理方法：再等会
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element_text = self.web_get_text(locator)
        log.info("=====文本如下=====\n%s\n=====********=====" % element_text, also_console=True)
        return element_text

    @screenshot
    @keyword
    def web_element_text_should_be(self, locator, expected, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素可见 -> 断言元素文本

        Args:
            locator: 定位器
            expected: 期望的文本值
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        log.info("校验元素 {0} 的文本应该为 {1}".format(locator, expected), also_console=True)
        text = self.web_get_text(locator, timeout)
        if text != expected:
            msg = "元素 {0} 的文本应该为 {1} 而不是 {2}".format(locator, expected, text)
            raise AssertionError(msg)
        else:
            log.info("断言成功", also_console=True)

    @keyword
    def web_clean_file(self, prefix, suffix):
        if PLATFORM.startswith("win"):
            default_download_path = download_path
            for file in os.listdir(default_download_path):
                filename = file
                if filename.endswith(suffix) and filename.startswith(prefix):
                    log.info("删除文件 " + os.path.join(default_download_path, file), also_console=True)
                    os.remove(os.path.join(default_download_path, file))
        else:
            raise AssertionError("平台暂未支持")

    @keyword
    def web_check_excel(self, prefix, suffix):
        if PLATFORM.startswith("win"):
            default_download_path = download_path
            L = []
            for file in os.listdir(default_download_path):
                filename = file
                if filename.endswith(suffix) and filename.startswith(prefix):
                    L.append(os.path.join(default_download_path, file))
            if len(L) > 0:
                log.info("{} {} 文件存在".format(prefix, suffix), also_console=True)
                zip_file = zipfile.ZipFile(L[0])
                for names in zip_file.namelist():
                    zip_file.extract(names)
                    # 解压到了当前执行的目录
                zip_file.close()
                for file in os.listdir(os.getcwd()):
                    if file.endswith(".xlsx"):
                        # UserWarning: Workbook contains no default style, apply openpyxl's default warn("Workbook contains no default style, apply openpyxl's default")
                        # 忽略警告，因为excel是由Apache POI创建的，没有默认样式
                        import warnings

                        warnings.filterwarnings("ignore")
                        wb = openpyxl.load_workbook(file, read_only=False)
                        ws = wb.active
                        if ws.max_row > 1:
                            log.info("Excel 文件存在%s行数据(含标题行)" % ws.max_row, also_console=True)
                        else:
                            log.error("Excel 文件为空")
                        for row in ws.rows:
                            line = [col.value for col in row]
                            log.info(line, also_console=True)
                        os.remove(file)
            else:
                raise AssertionError("文件不存在，可能未下载")
        else:
            raise AssertionError("平台暂未支持")

    @keyword
    def web_get_attribute(self, locator, key, timeout=10):
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_visible(locator, timeout=timeout)
        return element.get_attribute(key)

    @keyword
    def web_close_browser(self):
        log.info("关闭浏览器")
        self.driver.close()

    @screenshot
    @keyword
    def web_input_file(self, locator, file, timeout=10):
        """
        等待页面加载完成 -> 切换到元素所在的iframe -> 等待元素出现 -> 清空文本 -> 输入文本

        Args:
            locator: 定位器
            file: 要输入的文件
            timeout: 超时时间
        Returns:
            None
        """
        if timeout == "" or not timeout:
            timeout = 10
        self.__wait_for_ready_state_complete()
        self.web_switch_to_frame_of_element(locator)
        element = self.web_wait_for_element_present(locator, timeout=timeout)
        log.info(file)
        file = eval("r'{}'".format(file).replace("\r", "\\r").replace("\c", "\\c"))
        msg = "输入 {0} 到元素 {1} 中".format(file, locator)
        log.info(msg, also_console=True)
        log.info(repr(file))
        try:
            element.clear()
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.clear()
        try:
            element.send_keys(file)
        except StaleElementReferenceException:
            self.__wait_for_ready_state_complete()
            time.sleep(0.1)
            element.send_keys(file)

    @keyword
    def web_get_screen_shot(self):
        # 不支持文件名中含有冒号
        # file_path = os.path.dirname(os.path.dirname(__file__))
        # png_name = file_path + '/selenium-screenshot-%s.png' % datetime.datetime.now().strftime(
        #     '%Y-%m-%d-%H-%M-%S.%f')
        log.info("开始截图...", also_console=True)
        # self.driver.save_screenshot(png_name)
        log.info(
            '</td></tr><tr><td colspan="3">'
            '<img alt="screenshot" class="robot-seleniumlibrary-screenshot" '
            'src="data:image/png;base64,{0}" width="{1}px">'.format(self.driver.get_screenshot_as_base64(), 800),
            html=True,
        )
