import random
import traceback
from typing import Tuple

from kazoo.client import KazooClient
from robot.api.deco import keyword

from . import log
from .UtilsMsg import UtilsMsg


class ZkClient(KazooClient):
    _instance_ = {}

    def __new__(cls, *args, **kwargs):
        key = str(args) + str(kwargs)
        if key not in cls._instance_:
            cls._instance_[key] = KazooClient(*args, **kwargs)
        return cls._instance_[key]


class ZkLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self._hosts: str = ""
        # mock启动，对mock对应的节点+IPPORT信息进行保存；
        self._rpc_node_tree = []
        self.http_node_tree = []

    @keyword
    def zk_init(self):
        try:
            self._zk = ZkClient(hosts=self._hosts)
            if not self._zk.connected:
                self._zk.start()
        except BaseException:
            raise AssertionError("zk Service Startup failed!")

    @keyword
    def zk_init_hosts(self, hosts):
        try:
            self._hosts = hosts
            self._zk = ZkClient(hosts=hosts)
            if not self._zk.connected:
                self._zk.start()
        except BaseException:
            raise AssertionError("zk Service Startup failed!")

    # 创建zk节点
    @keyword
    def zk_create_node(self, nodes):
        for i in nodes:
            if self._zk.exists(i):
                print(i, "node is exist")
            else:
                self.add_provider(i)

    @keyword
    def add_provider(self, serviceurl):
        urlpath = "/"
        url = serviceurl.split("/")
        for i in url:
            if i.strip() != "":
                urlpath = urlpath + i
                urlpath = urlpath + "/"
                if not self._zk.exists(urlpath):
                    self._zk.create(urlpath, b"service")
                    # print urlpath
        return {"ret_code": "00"}

    @keyword
    def add_node_provider(self, serviceurl, url_list):
        try:
            # 判断根节点是否存在，不存在则创建
            self.add_provider(serviceurl)

            # 判断子节点是否存在，不存在则创建
            for i in url_list:
                self._zk.create(serviceurl + "/" + i, b"")
            return {"ret_code": "00"}

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"add_node_provider替换节点发生异常!: {str(e)}")

    @keyword
    def zk_delete_node(self, nodes):
        for i in nodes:
            self.delete_provider(i)

    @keyword
    def delete_provider(self, serviceurl):
        if self._zk.exists(serviceurl):
            self._zk.delete(serviceurl, recursive=True)
            print(serviceurl, "节点进行删除操作!")

    @keyword
    def zk_node_exists(self, serviceurl):
        return self._zk.exists(serviceurl)

    @keyword
    def zk_stop(self):
        self._zk.stop()

    @keyword
    def query_nodes(self, url: str) -> Tuple[str, int]:
        """传入注册节点，返回rpc对应注册地址

        - url:
        - return: ip, port
        """
        if self._zk.exists(url):
            path = self._zk.get_children(url, None, False)
            children = random.choice(path) if path else ""
            if path and ":" in children:
                return children.split(":")
            else:
                raise ValueError(f"节点{url}下的注册地址数据异常:{path}")
        else:
            raise ValueError(f"节点{url}不存在")

    # 查询返回多个节点
    @keyword
    def query_nodes_list(self, url):
        try:
            path = ""
            if self._zk.exists(url):
                path = self._zk.get_children(url, None, False)
            else:
                print(url, "The node does not exist!")
            return path
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"query_nodes_list exception!: {str(e)}")

    # 获取zk信息，并设置当前服务信息，注册至zk上
    @keyword
    def exists_zk_node(self, node_url, new_ip, new_port):
        try:
            # 判断传入类型
            self.zk = ZkLibrary()
            self.zk.zk_init()
            ip, port = self.zk.query_nodes(node_url)

            # 为0情况，说明该节点不存在，则直接注册该节点，反之则删除该节点后再注册；
            node_url = UtilsMsg.str_append(node_url, node_url[-1], "/")

            if self.zk.zk_node_exists(node_url):
                # 删除节点
                # self..delete_provider(node_url)
                pass

            # 注册节点
            self.zk.add_node_provider(node_url, [f"{new_ip}:{new_port}"])
            print(node_url, "节点注册成功")

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"exists_zk_node exception!: {str(e)}")

    @keyword
    def del_exists_zk_node(self, node_url, new_ip, new_port):
        try:
            tree_node_str = ""

            # 判断传入类型
            self.zk = ZkLibrary()
            self.zk.zk_init()
            ip, port = self.zk.query_nodes(node_url)

            # 为0情况，说明该节点不存在，则直接注册该节点，反之则删除该节点后再注册；
            node_url = UtilsMsg.str_append(node_url, node_url[-1], "/")

            if self.zk.zk_node_exists(node_url):
                # 删除节点
                tree_node_str = node_url + new_ip + ":" + str(new_port)
                self.zk.delete_provider(tree_node_str)
                print(node_url, "删除节点成功")

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"del_exists_zk_node exception!: {str(e)}")
