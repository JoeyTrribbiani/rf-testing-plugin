import datetime
import json
import os
import re
import time
import traceback
from typing import List

import oracledb
import pymysql
from oracledb.connection import Connection as Oracle_Connection
from oracledb.connection import connect as oracle_connect
from oracledb.exceptions import DatabaseError as oracleDatabaseError
from oracledb.thick_impl import init_oracle_client
from pyhive import presto
from robot.api.deco import keyword

from . import jaydebeapi, log
from .UtilsLibrary import UtilsLibrary
from .UtilsSign import UtilsSign

os.environ["NLS_LANG"] = "SIMPLIFIED CHINESE_CHINA.UTF8"
utils = UtilsLibrary


class DBLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self._db_connections = {}
        self.db_switch = True
        self.db_no_tran = False

    def _parse_mysql_db_url(self, db_url: str) -> tuple:
        m = re.fullmatch(r"^(\w+)/([\s\S]+)@([\s\S]+):(\d{2,})/([\s\S]+)$", db_url)
        if not m:
            raise ValueError("db_url: %s 格式不正确" % db_url)
        user, password, host, port, database = m.groups()
        log.info(m.groups())
        return user, password, host, port, database

    def _parse_presto_db_url(self, db_url: str) -> tuple:
        m = re.fullmatch(r"^(\d{2,}.\d+.\d+.\d+):(\d{2,})$", db_url)
        if not m:
            raise ValueError("db_url: %s 格式不正确" % db_url)
        host, port = m.groups()
        log.info(m.groups())
        return host, port

    def _parse_oceanbase_db_url(self, db_url: str) -> tuple:
        m = re.fullmatch(r"^(jdbc:oceanbase://[\s\S]+:\d{2,}/[\s\S]+)\?([\s\S]+)&([\s\S]+)$", db_url)
        if not m:
            raise ValueError("db_url: %s 格式不正确" % db_url)
        jdbc_url, user, password = m.groups()
        log.info(m.groups())
        return jdbc_url, user, password

    @keyword
    def connect_to_database(self, db_type: str, db_url: str) -> None:
        """连接数据库
        | Connect To Database | cx_Oracle | trans_user/123456@172.20.34.10:1521/posplus |
        | Connect To Database | mysql | test/111111@172.20.5.69:3306/app_release |
        | Connect To Database | presto-hive | 172.20.7.35:8081 |
        | Connect To Database | oceanbase | jdbc:oceanbase://host:port/databasename?username&password |

        - db_type: cx_Oracle/mysql/presto-hive/oceanbase
        - db_url: 数据库连接地址
            - oceanbase: jdbc:oceanbase://host:port/databasename?username&password
        """
        try:
            if db_type in ["oceanbase"] or db_url.startswith('jdbc:oceanbase'):
                jdbc_url, user, password = self._parse_oceanbase_db_url(db_url)
                CUR_DIR = os.path.dirname(os.path.abspath(__file__))
                driver = 'com.alipay.oceanbase.jdbc.Driver'
                jar_file = os.path.join(CUR_DIR, 'java', 'jars', 'oceanbase-client-2.4.2.jar')
                self._db_connection = jaydebeapi.connect(
                    driver, jdbc_url, {"user": user, "password": password, "autocommit": "false"}, jar_file
                )
                self.db_no_tran = False
            elif db_type in ["cx_Oracle", "oracledb"]:
                log.info(db_url)
                init_oracle_client()
                self._db_connection = oracle_connect(db_url)
                self.db_no_tran = False
            elif db_type in ["mysql"]:
                user, password, host, port, database = self._parse_mysql_db_url(db_url)
                self._db_connection = pymysql.connect(
                    user=user, password=password, host=host, port=int(port), database=database, charset="utf8"
                )
                self.db_no_tran = False
            elif db_type in ["presto-hive"]:
                host, port = self._parse_presto_db_url(db_url)
                self._db_connection = presto.Connection(host=host, port=int(port))
                self.db_no_tran = True
            else:
                log.error("db_type: %s 暂不支持" % db_type)
            if self._db_connection:
                log.info("The database has been successfully connected!")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("Database connection failed!", str(e))

    @keyword
    def query(self, select_statement: str):
        cur = None
        try:
            cur = self.__execute_db_sql(select_statement)
            all_rows = cur.fetchall()
            return all_rows
        finally:
            if cur:
                self._db_connection.rollback()

    @keyword
    def query_to_dict(self, select_statement: str, upper: bool = False, query_flag=False, time_out = 25, time_out_sleep = 10) -> List[dict]:
        """查询数据库，返回字典类型的数据集

        使用前需要先使用`Connect To Database`连接数据库
        | ${queryResults} | Query To Dict | select first_name, last_name from person |
        | Log | ${queryResults[0]['first_name']}, ${queryResults[0]['last_name']} |
        """

        ##如果查询数据不到，重试2次。
        start_time = time.time()
        end_time = start_time + time_out

        if query_flag:
            while time.time() < end_time:
                query_data  = self.query_statement_to_dict(select_statement, upper)
                if len(query_data) > 0:
                    return  query_data
                else:
                    time.sleep(time_out_sleep)
        else:
            return self.query_statement_to_dict(select_statement, upper)

    def  query_statement_to_dict(self,select_statement: str, upper: bool = False)  -> List[dict]:
        cur = None
        try:
            log.info("select_statement: %s" % select_statement)
            cur = self._db_connection.cursor()
            self.__execute_sql(cur, select_statement)
            all_rows = cur.fetchall()

            mapped_rows = []
            table_desc = cur.description
            if table_desc:
                col_names = [c[0] for c in table_desc]
                for row_idx in range(len(all_rows)):
                    d = {}
                    for col_idx in range(len(all_rows[row_idx])):
                        # 如果非None或者非数字，才转换str
                        if upper:
                            key = col_names[col_idx].upper()
                        else:
                            key = col_names[col_idx].lower()
                        d[key] = (
                            str(all_rows[row_idx][col_idx])
                            if all_rows[row_idx][col_idx] is not None
                               and not isinstance(all_rows[row_idx][col_idx], (int, float))
                            else all_rows[row_idx][col_idx]
                        )
                    mapped_rows.append(d)
                counts = len(mapped_rows)
                log.info(f"查询到{counts}条数据:", json.dumps(mapped_rows, ensure_ascii=False, indent=2))
                return mapped_rows
            else:
                return []
        finally:
            if cur and not isinstance(cur, presto.Cursor):
                self._db_connection.rollback()


    @keyword
    def query_one(self, select_statement: str):
        """ """
        cur = None
        try:
            cur = self.__execute_db_sql(select_statement)
            row = cur.fetchone()
            log.info("查询结果：", row)
            return row
        finally:
            if cur:
                self._db_connection.rollback()

    @keyword
    def row_count(self, select_statement: str) -> int:
        """
        Uses the input `select_statement` to query the database and returns
        the number of rows from the query.

        For example, given we have a table `person` with the following data:
        | id | first_name  | last_name |
        |  1 | Franz Allan | See       |
        |  2 | Jerry       | Schneider |

        When you do the following:
        | ${row_count} | Row Count | select * from person |
        | Log | ${row_count} |

        You will get the following:
        2

        Also, you can do something like this:
        | ${row_count} | Row Count | select * from person where id = 2 |
        | Log | ${row_count} |

        And get the following
        1
        """
        cur = None
        try:
            cur = self.__execute_db_sql(select_statement)
            cur.fetchall()
            row_count = cur.rowcount
            log.info("查询结果：", row_count)
            return row_count
        finally:
            if cur:
                self._db_connection.rollback()

    @keyword
    def description(self, select_statement: str):
        """
        Uses the input `select_statement` to query a table in the db which
        will be used to determine the description.

        For example, given we have a table `person` with the following data:
        | id | first_name  | last_name |
        |  1 | Franz Allan | See       |

        When you do the following:
        | @{queryResults} | Description | select * from person |
        | Log Many | @{queryResults} |

        You will get the following:
        [Column(name='id', type_code=1043, display_size=None, internal_size=255, precision=None, scale=None, null_ok=None)]
        [Column(name='first_name', type_code=1043, display_size=None, internal_size=255, precision=None, scale=None, null_ok=None)]
        [Column(name='last_name', type_code=1043, display_size=None, internal_size=255, precision=None, scale=None, null_ok=None)]
        """
        cur = None
        try:
            cur = self.__execute_db_sql(select_statement)
            description = cur.description
            return description
        finally:
            if cur:
                self._db_connection.rollback()

    @keyword
    def delete_all_rows_from_table(self, table_name: str):
        """
        Delete all the rows within a given table.

        For example, given we have a table `person` in a database

        When you do the following:
        | Delete All Rows From Table | person |

        If all the rows can be successfully deleted, then you will get:
        | Delete All Rows From Table | person | # PASS |
        If the table doesn't exist or all the data can't be deleted, then you
        will get:
        | Delete All Rows From Table | first_name | # FAIL |
        """
        cur = None
        select_statement = "delete from %s;" % table_name
        try:
            newsql_statement = self._switch_db(select_statement)
            cur = self._db_connection.cursor()
            result = self.__execute_sql(cur, select_statement)
            if result is not None:
                return cur.fetchall()
            self._db_connection.commit()
        finally:
            if cur:
                self._db_connection.rollback()

    @keyword
    def execute_sql_string(self, sql_string: str):
        """执行sql语句
        sql 结束不要带";"或者"/"
        """
        cur = None
        try:
            cur = self._db_connection.cursor()
            log.info(f"{sql_string}")
            self.__execute_sql(cur, sql_string)
            # presto-hive，insert后需要fetch一下
            if isinstance(cur, presto.Cursor):
                cur.fetchone()
            if not self.db_no_tran:
                self._db_connection.commit()
        finally:
            if cur and not self.db_no_tran:
                self._db_connection.rollback()

    def __execute_sql(self, cur, sql_statement: str):
        return cur.execute(sql_statement)

    def __execute_db_sql(self, sql_statement: str):
        newsql_statement = self._switch_db(sql_statement)
        cur = self._db_connection.cursor()
        log.info(newsql_statement)
        cur.execute(newsql_statement)
        return cur

    # 数据源进行关闭
    @keyword
    def connect_close(self) -> None:
        if self._db_connection is not None:
            self._db_connection.close()
            log.info("connect_close:关闭数据源成功！")

    def _switch_db(self, sql_statement: str):
        # db_name.table_name的情况，这个没有用到
        if not self.db_switch:
            return sql_statement
        re_sql = re.compile(
            r"""select\s+.*?\s+from\s+(\w*\.*\w+)
                              |insert\s+into\s+(\w*\.*\w+)
                              |update\s+(\w*\.*\w+)
                              |delete\s+from\s+(\w*\.*\w+)
                              |select\s+.*?\s+into\s+(\w*\.*\w+)""",
            re.X,
        )
        ret = re_sql.match(sql_statement.lower())
        tb_name = ""
        if ret:
            for m in ret.groups():
                if m:
                    tb_name = m
                    break
            if tb_name and tb_name.count(".") != 0:
                db_name = tb_name.split(".")[0].lower()
                if db_name not in self._db_connections:
                    raise RuntimeError("DB not connected, please connect to db first! db_name: %s" % db_name)
                if self._db_connection != self._db_connections[db_name]:
                    try:
                        self._db_connection.commit()
                    except BaseException:
                        pass
                    self._db_connection = self._db_connections[db_name]
                # newtb_name = tb_name[len(db_name)+1:]
                # sql_statement = sql_statement.lower().replace(tb_name, newtb_name)
        return sql_statement

    @keyword
    def query_t_ofl_l_terminal_par_no(self, oracle_url: str, merchno: str, termno: str):
        """获取POS的批次号和凭证号"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            sql = "select MERCHNO,TERMNO,VOUCHNO,BATCHNO from T_OFL_L_TERMINAL_PAR where MERCHNO='{}' and TERMNO ='{}'".format(
                merchno, termno
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"查询 T_OFL_L_TERMINAL_PAR 表数据异常!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_out_qr_pay_order(self, oracle_url: str, order_id: str):
        """获取左端流水"""
        try:
            partition_id = UtilsSign.sha1_partition(order_id, 64)
            table_name = "_".join(["T_OUT_QR_PAY_ORDER", "01", partition_id])
            log.info(f"使用表[{table_name}]进行查询")
        except AssertionError as e:
            log.info(e, f"将使用默认表[T_OUT_QR_PAY_ORDER]进行查询")
            table_name = "T_OUT_QR_PAY_ORDER"
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            sql = (
                    "select ORDER_ID,ORG_CODE,MERCH_NO,FEE_CALC_TYPE,AMOUNT,BUSI_TYPE,BUSI_SUB_TYPE,ORI_ORDER_ID,STATUS,FEE,CHN_ORDER_NO,ORI_OUT_ORDER_ID,TERM_NO,CARD_NO,CARD_TYPE,CARD_FLAG,IS_INTERNAL_CARD,POSITON_INFO,RET_CODE,RET_MSG,CHANNEL_NO,LONGITUDE,LATITUDE,DISCOUNT_AMOUNT,DEVICE_SN,SUBJECT,AREA_CODE,COORD_SYSTEM,DESCRIPTION,SETTLE_TYPE,SETTLE_AMOUNT,EXTER_DISCOUNT_AMOUNT,FINNAL_AMOUNT,DISCOUNT_NAME,COUPON_INFO,OP_USER_ID,OP_SHOP_ID,IS_FORCE_POSITION,OUT_DEVICE_SN,QR_VERSION,PROFIT_SHARING,INIT_AMOUNT  from "
                    + table_name
                    + " where order_id = '"
                    + order_id
                    + "'"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"查询 T_OUT_QR_PAY_ORDER 表数据异常!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_merchno_balance(self, oracle_url: str, merch_no: str):
        """获取虚户金额"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = "select vir_account_no from t_acc_profile where merch_no = '" + merch_no + "' and account_type = 1"
            log.info("sql", sql)
            data = self.query_to_dict(sql)
            vir_account_no = data[0]["vir_account_no"]
            ## 根据虚户ID获取，外部户的金额与冻结金额 ##
            sql_b = (
                    "select balance,fz_balance,status from t_acc_balance where vir_account_no = '" + vir_account_no + "'"
            )
            data_b = self.query_to_dict(sql_b)
            return data_b[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"查询商户余额失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_auth_trans_list(self, oracle_url: str, trans_id: str):
        """获取鉴权数据列表"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select MERCH_NO,STATUS,RET_CODE,RET_MSG from t_auth_trans_list where trans_id = '"
                    + trans_id
                    + "' and rownum = '1'"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"查询鉴权流水记录失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_acc_trans_list(self, oracle_url: str, order_id: str):
        """账务记账流水信息"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select order_id,ori_order_id,amount,fee,status,update_status from t_acc_trans_list where order_id = '"
                    + order_id
                    + "'"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"账务记账流水信息失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_ocr_order(self, oracle_url: str, trans_id: str):
        """鉴权用户下，ocr表结构数据查询"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select MERCH_NO,STATUS,RET_CODE,RET_MSG from t_ocr_order where trans_id = '"
                    + trans_id
                    + "' order by create_time desc"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"账务记账流水信息失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_company_shareholder_list(self, oracle_url: str, trans_id: str):
        """鉴权用户下，股东信息查询流水"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select MERCH_NO,STATUS,RET_CODE,RET_MSG from t_company_shareholder_list where trans_id = '"
                    + trans_id
                    + "' order by create_time desc"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"股东信息查询流水失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_black_order(self, oracle_url: str, trans_id: str):
        """鉴权用户下，黑名单查询流水"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select MERCH_NO,STATUS,RET_CODE,RET_MSG from t_black_order where trans_id = '"
                    + trans_id
                    + "' order by create_time desc"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"黑名单查询流水失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_auth_ocr_face(self, oracle_url: str, trans_id: str):
        """鉴权用户下，人脸识别流水"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select MERCH_NO,STATUS,RET_CODE,RET_MSG from t_auth_ocr_face where trans_id = '"
                    + trans_id
                    + "' order by create_time desc"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"人脸识别流水查询失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_acc_month_merch_list_status(self, oracle_url: str, merch_no: str, status: str):
        """t_acc_month_merch_list月结商户表；只更新月结商户状态。"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = "update t_acc_month_merch_list set status = '" + status + "' where merch_no = '" + merch_no + "'"
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"更新月结流水表失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_fee_base_package(self, oracle_url: str, ruld_id: str, merch_no: str):
        """t_fee_base_package更新商户绑定费率关系。"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            sql = "update t_fee_base_package set rule_id = '" + ruld_id + "' where merch_no = '" + merch_no + "'"
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"更新商户绑定费率关系失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_rc_trade_params(self, oracle_url: str, merch_no: str, type: str):
        """_rc_trade_params 更新风控的基础数据。"""
        try:
            time = UtilsLibrary.get_trans_ymd()
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            s = '{"' + time + '":00":"{\\"amtDay\\":100,\\"numDay\\":3}","newest":"' + time + '"}'
            sql = "update T_RC_TRADE_PARAMS Set MERCH_STATISTICS='" + s + "' where ID='" + merch_no + ":" + type + "'"
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"更新风控的基础数据失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_rc_total_merch(self, oracle_url: str, merch_no: str, sub_type: str):
        """T_RC_TOTAL_MERCH 更新商户累计限额。"""
        try:
            time_ym = UtilsLibrary.get_trans_ym()
            time_day = UtilsLibrary.get_trans_day()
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "UPDATE T_RC_TOTAL_MERCH SET AMT_DAY"
                    + time_day
                    + " = ''  WHERE MERCH_NO = '"
                    + merch_no
                    + "' AND TRANS_TYPE = '"
                    + sub_type
                    + "' AND TRANS_YY_MM = '"
                    + time_ym
                    + "'"
            )
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"T_RC_TOTAL_MERCH 更新商户累计限额失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_order_info(self, oracle_url: str, order_id: str):
        """订单表数据查询"""
        try:
            time_ymd = UtilsLibrary.get_trans_ymd()
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select ORDER_ID,REAL_AMOUNT,DIS_AMOUNT,ACC_AMOUNT,BENEFIT_TYPE,CHN_DIS_AMOUNT,CHN_MER_DIS_AMOUNT,FEE_CALC_TYPE,ACCOUNT_FLAG from t_acc_detail_'"
                    + time_ymd
                    + "' where order_id = '"
                    + order_id
                    + "'"
            )
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"t_order_info 订单表处理失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_t_reliable_msg(self, oracle_url: str, msg_key: str, send_state: str):
        """可靠消息系统数据查询"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            sql = (
                    "select TYPE,MSG,MSG_KEY,TOPIC,CATEGORY,MSG,VERSION,RETRY,QUERY_TIMES,STATE,SEND_STATE,IDC,SOURCE from t_reliable_msg where msg_key = '"
                    + msg_key
                    + "' and send_state = '"
                    + send_state
                    + "'"
            )
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"t_reliable_msg 消息系统数据查询!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_t_rc_merch_param(self, oracle_url: str, merch_no: str, mcc_code: str, account_type: str):
        """风控系统设置商户的mcc_code和account_type"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            ## 根据商户号设置商户的mcc_code和account_type ##
            sql = (
                    "update t_rc_merch_param set mcc_code = '"
                    + mcc_code
                    + "',account_type ='"
                    + account_type
                    + "' where merch_no = '"
                    + merch_no
                    + "'"
            )
            log.info(sql)
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"t_rc_merch_param 风控商户表更新mccCode失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_oracle_autoscript(self, oracle_url: str, sql: str):
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            # 数据执行，要携带where条件，则认为处理失败；
            if "where" not in sql.lower():
                raise ValueError("传入sql,需要携带where条件!")
            data = self.query_to_dict(sql)
            return data[0]
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"执行SQL查询失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def update_oracle_autoscript(self, oracle_url: str, sql: str):
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            # 数据执行，要携带where条件，则认为处理失败；
            if "where" not in sql.lower():
                raise ValueError("传入sql,需要携带where条件!")
            data = self.execute_sql_string(sql)
            return data
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"执行SQL操作失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def query_merchno_balance_orderid(self, oracle_url: str, merch_no: str, order_id: str = ""):
        """获取虚户金额,并校验流水状态"""
        try:
            if oracle_url.startswith('jdbc:oceanbase'):
                self.connect_to_database("oceanbase", oracle_url)
            else:
                self.connect_to_database("cx_Oracle", oracle_url)
            # 根据商户号获取虚户ID，仅支持外部户获取 ##
            sql = (
                    "select * from t_acc_profile where (subject_code ='22020101' or subject_code = '22048001' or subject_code = '22020110') and account_type = 1 and merch_no = '"
                    + merch_no
                    + "'"
            )
            data = self.query_to_dict(sql)
            # ## 根据虚户ID获取，外部户的金额与冻结金额 ##
            vir_account_no = data[0]["vir_account_no"]
            sql_b = (
                    "select balance,fz_balance,status from t_acc_balance where vir_account_no = '" + vir_account_no + "'"
            )
            data_b = self.query_to_dict(sql_b)

            resp_msg = {
                "merch_no": data[0]["merch_no"],
                "ret_code": "00",  # 00成功，01失败
                "status": data[0]["status"],  # 账户状态:：0-正常；1-未激活；2-冻结；9-已销户
                "settle_type": data[0]["settle_type"],  # 清算方式（商户虚户使用）0-余额提现1-自动T+1清算 2-D0秒到 3-仅T+1清算 5-直联清算
                "hold_pay_flag": data[0]["hold_pay_flag"],  # 暂不付标志，1:暂不付，0:可以付
                "balance": data_b[0]["balance"],  # 帐户余额
                "fz_balance": data_b[0]["fz_balance"],  # 冻结资金
                "remark": "",
            }

            # 确认订单号查询
            if order_id:
                # sql = "select order_id from t_acc_trans_list where order_id = '" + order_id + "' and status = 1"
                sql = "select * from {table_name} where order_id='" + order_id + "'"
                data_c = self.query_to_dic_for_accp("t_acc_trans_list", order_id, order_id, sql)
                print("测试订单查询状态：", data_c)
                # data_c = self.query_to_dict(sql)
                log.info(data_c)
                if not data_c:
                    resp_msg["ret_code"] = "01"
                    resp_msg["remark"] = "查询订单失败"

            log.info("响应消息:", resp_msg)
            return resp_msg
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"查询商户余额失败!: {str(e)}")
        finally:
            self.connect_close()

    @keyword
    def execute_for_horizon(self, table, sql: str):
        """
        水平分表，表名结束为月日
        - table: 例:T_PAY_ORDER_%s，默认把表名转大写查找所有相关分表
        - sql: 例:select * from {table_name}
        - return: list
        """
        cur_table = table % time.strftime("%m%d", time.localtime())
        log.info(cur_table)
        cur_dic = {"table_name": cur_table}
        if isinstance(self._db_connection, Oracle_Connection):
            query_tables_sql = "SELECT TABLE_NAME FROM USER_TAB_COMMENTS WHERE TABLE_NAME LIKE upper('%s')" % table[:-1]
        else:
            query_tables_sql = (
                    "SELECT TABLE_NAME FROM information_schema.`TABLES` where TABLE_NAME like upper('%s');" % table[:-1]
            )
        tables = self.query_to_dict(query_tables_sql)
        res = []
        if sql.startswith(("insert ", "INSERT ")):
            real_sql = sql.format(**cur_dic)
            res = self.execute_sql_string(real_sql)
        elif sql.startswith(("select ", "SELECT ")):
            cur_index = tables.index(cur_dic)
            for i in range(cur_index + 1):
                table = tables[cur_index - i]
                real_sql = sql.format(**table)
                tmp = self.query_to_dict(real_sql)
                res.extend(tmp)
        else:
            for table in tables:
                real_sql = sql.format(**table)
                res = self.execute_sql_string(real_sql)
        return res

    @keyword
    def query_to_dic_for_accp(self, table: str, order_id: str, merch_no: str, sql: str):
        """
        账务水平分表查询

        - `table`：基础表表名
        - `order_id`：订单号
        - `merch_no`：商户号, 后面调整为使用订单号
        - `sql`：要查询的sql，其中表名部分使用{table_name}替代

        Sample usage :
          | ${queryResults} | Query to Dic For Accp | t_acc_trans_list | 411053881152094083481648 | 411053881152094083481648 | select * from {table_name} |
          | Log | ${queryResults}[0] |
        """
        try:
            year_month = UtilsLibrary.get_date_from_order_id(order_id)
            partition_id = UtilsSign.sha1_partition(merch_no)
            table_name = "".join([table, "_", year_month[2:], partition_id[1:]])
            log.info(f"使用表[{table_name}]进行查询")
        except AssertionError as e:
            log.info(e, f"将使用默认表[{table}]进行查询")
            table_name = table
        table_dic = {"table_name": table_name}
        real_sql = sql.format(**table_dic)
        return self.query_to_dict(real_sql)

    @keyword
    def execute_sql_for_accp(self, table: str, order_id: str, merch_no: str, sql: str):
        """
        账务水平分表操作数据

        - `table`：基础表表名
        - `order_id`：订单号
        - `merch_no`：商户号, 后面调整为使用订单号
        - `sql`：要执行的sql，其中表名部分使用{table_name}替代

        Sample usage :
          | Execute Sql For Accp | t_acc_trans_list | 411053881152094083481648 | 411053881152094083481648 | delete from {table_name} where order_id ='411053881152094083481648' |
        """
        try:
            year_month = UtilsLibrary.get_date_from_order_id(order_id)
            partition_id = UtilsSign.sha1_partition(merch_no)
            table_name = "_".join([table, year_month, partition_id])
            log.info(f"使用表[{table_name}]进行操作")
        except AssertionError as e:
            log.info(e, f"将使用默认表[{table}]进行操作")
            table_name = table
        table_dic = {"table_name": table_name}
        real_sql = sql.format(**table_dic)
        return self.execute_sql_string(real_sql)

    @keyword
    def execute_sql_for_create_table(self, table, sql: str, targettime=None):
        """
        创建数据库表

        - `table`：基础表表名
        - `sql`：要执行的sql，其中表名部分使用{table_name}替代
        - `targettime`:需要创建的表的时间，默认为当前时间+1天

        Sample usage :
          | Execute Sql For CreateTable | t_acc_trans_list |create table if not exists {table_name} (order_id    VARCHAR2(32) not null,create_time DATE) | targettime=MMDD |
        """
        if targettime:
            cur_table = (
                    table
                    + "_"
                    + (datetime.datetime.strptime(targettime, "%m%d") + datetime.timedelta(days=1)).strftime("%m%d")
            )
        else:
            cur_table = table + "_" + (datetime.datetime.now() + datetime.timedelta(days=1)).strftime("%m%d")
        log.info(cur_table)
        cur_dic = {"table_name": cur_table}

        if sql.startswith(("create ")):
            try:
                real_sql = sql.format(**cur_dic)
                self.execute_sql_string(real_sql)
            except oracledb.DatabaseError as e:
                log.info("数据库表创建异常: " + str(e))
            else:
                log.info(cur_table, "创建成功")
