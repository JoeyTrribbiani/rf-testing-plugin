import json
import ssl,os

from typing import Union
from kafka import KafkaConsumer, KafkaProducer
from robot.api.deco import keyword
from . import log
from .RedisLibrary import RedisLibrary
from .UtilsMsg import UtilsMsg
from kafka import KafkaProducer
from kafka.errors import KafkaError


class KafkaLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.kafka_server = ["172.20.35.57:9092", "172.20.35.57:9093", "172.20.35.58:9092"]
        self.kafka_topic_list = ["trade_kafka", "quques_trade_2", "quques_trade_1"]
        self.kafka_redis_node = (
            "172.20.20.37:6379,172.20.20.38:6379,172.20.20.39:6379,"
            "172.20.20.37:6380,172.20.20.38:6380,172.20.20.39:6380"
        )

    @keyword
    def kafka_consumer(self):
        print("kafka_consumer  listen start ....")
        consumer = KafkaConsumer(auto_offset_reset="latest", bootstrap_servers=self.kafka_server)
        consumer.subscribe(topics=self.kafka_topic_list)
        # consumer.poll(timeout_ms=600000)  # 从kafka获取消息
        for message in consumer:
            print(
                (
                    "%s:%d:%d: key=%s value=%s"
                    % (message.topic, message.partition, message.offset, message.key, message.value)
                )
            )
            self.kafka_insert_redis(message.key, message.value)

    @keyword
    def kafka_insert_redis(self, key, value):
        # 把对应取传值的key与value存入redis中，redis: kafka_message_data
        redis_client = RedisLibrary()
        redis_client.connect_redis_server_Cluster(self.kafka_redis_node)
        # 获取需要替换的参数
        kafka_message = redis_client.redis_get("kafka_message_data")
        if kafka_message is None:
            kafka_message = {}
        else:
            kafka_message = UtilsMsg.str_to_dict(kafka_message)
        kafka_message[key] = value
        kafka_message_str = json.dumps(kafka_message)
        redis_client.redis_set("kafka_message_data", kafka_message_str)
        print(kafka_message)

    @keyword
    def kafka_product(self, host: str, topic_value: str, value: Union[str, dict]):
        host_list = host.split(",")
        value = UtilsMsg.str_to_dict(value)
        producer = KafkaProducer(
            bootstrap_servers=host_list,  # kafka服务器的ip和端口号
            key_serializer=lambda k: json.dumps(k).encode("utf-8"),  # 假设生产的消息为json字符串
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        )  # 假设生产的消息为json字符串
        future = producer.send(topic_value, value=value, key=None, headers=None, partition=None, timestamp_ms=None)
        result = future.get(timeout=60)
        producer.close()
        log.info(f"result: {str(result)}")



    @keyword
    def aliyun_kafka_producer(self, aliyun_bootstrap_servers: str, topic_value: str, plain_username: str ,plain_password: str, value: Union[str, dict]):

        context = ssl.create_default_context()
        context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)

        ## The new python(2.7.8+) may cannot ignore the hostname check,
        ## you could set to ssl.CERT_NONE to walk around the problem,
        ## or you can change the client to confluent-python-demo

        # context.verify_mode = ssl.CERT_NONE
        context.verify_mode = ssl.CERT_REQUIRED

        context.check_hostname = False
        path = os.path.join(os.path.dirname(__file__), "cert/mix-4096-ca-cert")
        context.load_verify_locations(path)

        producer = KafkaProducer(bootstrap_servers= aliyun_bootstrap_servers,
                                 sasl_mechanism="PLAIN",
                                 ssl_context=context,
                                 security_protocol='SASL_SSL',
                                 api_version=(0, 10),
                                 retries=5,
                                 sasl_plain_username=plain_username,
                                 sasl_plain_password=plain_password)

        partitions = producer.partitions_for(topic_value)
        print('Topic下分区: %s' % partitions)
        print('bootstrap_servers: %s' % aliyun_bootstrap_servers)
        print('topic队列: %s' % topic_value)
        print('message:%s' %value)

        try:
            future = producer.send(topic_value, value.encode())
            future.get()
            print('send message succeed.')
            return 'OK'
        except KafkaError:
            print('send message failed.')
            print(KafkaError)
            return 'failed'

