import base64
import binascii
import json

import requests
from robot.api.deco import keyword

from . import log
from .iso import RespCodeDescriptions, iso_8583
from .RpcLibrary import RpcLibrary
from .UtilsLibrary import UtilsLibrary
from .UtilsMsg import UtilsMsg
from .ZkLibrary import ZkLibrary

utils = UtilsLibrary


class POSLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    """用于区分不同类型的报文，关键词暂不合并
    """

    @keyword
    def pos_balance_check(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """余额查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("余额查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送余额查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_transaction_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """交易查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0700"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("交易查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送交易查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_consumption(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """消费报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - info{-4:'30611000000029',2:'6217850800000011815',3:'000000',4:'000000000109',11:'${trace_no}',14:'2202',22:'072',23:'0001',25:'00',35:'6217850800000011815d5d6418a78218f3890',41:'60006323',42:'84914025813A000',47:'mcc=460&mnc=4&lac=9340&cid=4712',49:'156',53:'0610000000000000',55:'9f2608e2d789280dcc088d9f2701809f1013070f0103a00000010a0100000000007fc084619f3704ca55bbdd9f360212e3950500000000009a032105279c01009f02060000000000995f2a02015682027c009f1a0201569f03060000000000009f3303e0e9c89f34030000009f3501229f1e0832344530363637328408a0000003330101019f090200209f410400${trace_no}',59:'A206801002020201900000402JLG24E066720300601181504008DF63E3600500831100202',60:'22${batch_no}000601'}
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("消费报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送消费报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_consumption_dcc(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """消费报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - info{-4:'30611000000029',2:'6217850800000011815',3:'000000',4:'000000000109',11:'${trace_no}',14:'2202',22:'072',23:'0001',25:'00',35:'6217850800000011815d5d6418a78218f3890',41:'60006323',42:'84914025813A000',47:'mcc=460&mnc=4&lac=9340&cid=4712',49:'156',53:'0610000000000000',55:'9f2608e2d789280dcc088d9f2701809f1013070f0103a00000010a0100000000007fc084619f3704ca55bbdd9f360212e3950500000000009a032105279c01009f02060000000000995f2a02015682027c009f1a0201569f03060000000000009f3303e0e9c89f34030000009f3501229f1e0832344530363637328408a0000003330101019f090200209f410400${trace_no}',59:'A206801002020201900000402JLG24E066720300601181504008DF63E3600500831100202',60:'22${batch_no}000601'}
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0600"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("消费报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送消费报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_consumption_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """消费冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("消费冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送消费冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_consumption_cancel(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """消费撤销报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - info示例: {2:'6217850800000011815',3:'200000',4:'000000000109',11:'${trace_no_new}',14:'2202',22:'072',23:'0001',25:'00',35:'6217850800000011815d5d6418a78218f3890',37:'210735345661',41:'60006323',42:'84914025813A000',46:'-\\\\xbd\\\\xe8\\\\xbc\\\\xc7\\\\xbf\\\\xa8',47:'mcc=460&mnc=4&lac=9340&cid=4712',49:'156',53:'0610000000000000',60:'23${batch_no}000601',61:'${batch_no}${trace_no}',-4:'30611000000029'}
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("消费撤销报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送消费撤销报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_consumption_cancel_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """消费撤销冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("消费撤销冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送消费撤销冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_return(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """退货报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0220"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("退货报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送退货报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - info示例: {2:'6217850800000011815',3:'030000',4:'000000001000',11:'${trace_no}',14:'2202',22:'071',23:'0001',25:'06',26:'12',35:'6217850800000011815d5d6418a78218f3890',41:'60006323',42:'84914025813A000',47:'mcc=460&mnc=4&lac=9340&cid=4712',49:'156',52:'efad8c9d15f42ca3',53:'2610000000000000',55:'9f26087f3921efd566fd5d9f2701809f1013070f0103a00000010a010000000000f9d450b29f3704a35db75a9f360212f7950500000000009a032105289c01039f02060000000010005f2a02015682027c009f1a0201569f03060000000000009f3303e0e9c89f34030000009f3501229f1e0832344530363637328408a0000003330101019f090200209f410400000900',59:'A206801002020201900000402JLG24E066720300601181504008DF63E36005008311002',60:'10${batch_no}00060',-4:'30611000000029'}
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0100"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_cancel(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权撤销报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0100"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权撤销报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权撤销报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_cancel_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权撤销冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权撤销冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权撤销冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_completion_request(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权完成（请求）报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权完成（请求）报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权完成（请求）报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_completion_notify(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权完成（通知）报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0220"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权完成（通知）报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权完成（通知）报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_completion_request_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权完成（请求）冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权完成（请求）冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权完成（请求）冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_completion_cancel(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权完成撤销报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权完成撤销报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权完成撤销报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_pre_authorization_completion_cancel_reversal(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """预授权完成撤销冲正报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0400"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("预授权完成撤销冲正报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送预授权完成撤销冲正报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_checkin(self, url, info, info_replace=None, alg_type="0"):
        """签到报文

        - url: posp-proxy服务的请求地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0800"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("签到报文参数: %s" % dic)
        pack = self.dic2pack(dic, output=True)
        log.info("发送签到报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_checker_points_checkin(self, url, info, info_replace=None, alg_type="0"):
        """收银员积分签到报文

        - url: posp-proxy服务的请求地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0820"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("收银员积分签到报文参数: %s" % dic)
        pack = self.dic2pack(dic, output=True)
        log.info("发送收银员积分签到报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_checkout(self, url, info, info_replace=None, alg_type="0"):
        """签退报文

        - url: posp-proxy服务的请求地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0820"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("签退报文参数: %s" % dic)
        pack = self.dic2pack(dic, output=True)
        log.info("发送签退报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_batch_settlement(self, url, info, info_replace=None, alg_type="0"):
        """批结算报文

        - url: posp-proxy服务的请求地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - info示例: {48:'000000005555001000000000000000000000000000000000000000000000000000000000000000000000000000000',41:'60006323',42:'84914025813A000',11:'000876',60:'00000018201',49:'156',-4:'30601000000029',63:'01'}
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0500"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("批结算报文参数: %s" % dic)
        pack = self.dic2pack(dic, output=True)
        log.info("发送批结算报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def xgd_ack(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """确认报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0720"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("确认报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送确认报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def xgd_order_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """订单查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("订单查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送订单查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def xgd_exchange_rate_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """银联卡汇率查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0200"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("银联卡汇率查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送银联卡汇率查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def xgd_dcc_exchange_rate_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """外币卡DCC汇率查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0600"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("外币卡DCC汇率查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送外币卡DCC汇率查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_c2b_consumption(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """微信支付宝银联二维码交易，POS被扫支付/查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0600"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("POS被扫支付/查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送POS被扫支付/查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_withdraw_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """提现查询报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0620"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("提现查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送提现查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_withdraw_application(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """提现申请报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0620"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("提现申请报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送提现申请报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_qrtransaction_query(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """查询报文
        4.9.6.6.	POS主扫交易结果查询接口,码付查询-老版本
        4.9.6.7.	POS任意笔交易结果查询接口,自动查询-新版本

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0240"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("查询报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送查询报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def pos_electronic_signature_submission(self, url, zk_host, info, info_replace=None, alg_type="0"):
        """电签上送报文

        - url: posp-proxy服务的请求地址
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - info: 字典，需要填-4域：报文头，2-63域：需要的数据
        - return: 8583报文对应的字典
        """
        dic = str_eval_dict(info)  # 入参字典，直接str_eval_dict
        dic.update({-5: "6000010000", -3: "0820"})
        if info_replace:
            info_replace = str_eval_dict(info_replace)
            dic = UtilsMsg.para_replace(dic, info_replace)
        log.info("电签上送报文参数: %s" % dic)
        pack = self.dic2packwithmac(dic, zk_host, alg_type=alg_type)
        log.info("发送电签上送报文: %s" % pack)
        dic = self.send_posp_invoke(pack, url)
        self.parse_response(dic)
        return dic

    @keyword
    def get_unionpay_scan_pay_code(self):
        """获取银联被扫二维码（银行卡号）
        - return: json string
        """
        url = "https://open.unionpay.com/ajweb/help/qrcodeFormPage/sendOk"
        params = {
            "puid": "34",
            "requestType": "coverSweepReceiverApp",
            "sendtype": "C2B码申请",
            "sendData": '[{"fid":523,"keyword":"issCode","value":"90880019"},{"fid":525,"keyword":"backUrl","value":"http://101.231.204.84:8091/sim/notify_url2.jsp"},{"fid":526,"keyword":"qrType","value":""},{"fid":527,"keyword":"reqAddnData","value":""},{"fid":646,"keyword":"emvCodeIn","value":""},{"fid":528,"keyword":"accNo","value":"6216261000000002485"},{"fid":529,"keyword":"name","value":"宋小"},{"fid":530,"keyword":"cardAttr","value":"01"},{"fid":531,"keyword":"acctClass","value":"1"},{"fid":881,"keyword":"mobile","value":""},{"fid":1781,"keyword":"issCode_payerinfo","value":""}]',
        }
        s = requests.Session()
        res = s.get(url=url, params=params)
        log.info("响应结果: %s" % res.text)
        res_dic = {}
        if res.text:
            lst = res.text.replace("{", "").replace("}", "").replace(", ", "=").split("=")
            for i in range(0, len(lst), 2):
                res_dic[lst[i]] = lst[i + 1]
        if "qrNo" in res_dic:
            res_dic["qrNo-6"] = res_dic["qrNo"][-6:]
        return json.dumps(res_dic)

    @keyword
    def parseb64(self, data):
        """调试用，b64解析为8583报文的字典

        - data: Base64字符串
        - return: 8583报文的字典
        """
        data = binascii.hexlify(base64.b64decode(data)).decode()
        message = iso_8583("jlpos_head", "jlpos", data)
        dic = message.unpack(output=True)
        print(data)
        print(dic)
        if dic.get(46):
            print(dic.get(46))
        return dic

    @keyword
    def parse(self, data):
        """解析响应报文

        - data: 8583报文(hexstring)
        - return: 8583报文的字典
        """
        message = iso_8583("jlpos_head", "jlpos", data)
        dic = message.unpack(output=True)
        return dic

    @keyword
    def parse_response(self, dic):
        """解析响应报文的字典，处理39域应答码相关

        - dic: 8583报文所对应的字典
        - return: 39域应答码、56域交易提示信息
        """
        response_code = dic.get(39)
        trans_info = dic.get(56)
        if RespCodeDescriptions.get(response_code):
            log.info("[39]应答码 %s => %s" % (response_code, RespCodeDescriptions[response_code]))
        if trans_info:
            log.warn("[56]交易提示信息: %s" % trans_info)
        return response_code, trans_info

    @keyword
    def dic2pack(self, dic, output=False, set64=False):
        """dic字典转8583报文

        - dic: dic字典
        - set64: bitmap中设置64域存在
        - output: 是否调试打印
        - return: 8583报文(hexstring)
        """
        pack = iso_8583("jlpos_head", "jlpos")
        for domain, v in dic.items():
            if isinstance(domain, int) and domain != -6:
                pack.set_bit(domain, v)
        for domain, v in dic.items():
            if isinstance(domain, str):
                # 组装子域，后放到主域的键值下
                sub_dic = dic[domain]
                # 避免dic中同时包含key55和'55'，以'55'为主
                pack.set_bit(int(domain), "")
                for sub_k, sub_v in sub_dic.items():
                    pack.set_sub_bit(domain, sub_k, sub_v)
                domain_v = pack.pack_sub_body(domain, output=output)
                pack.set_bit(int(domain), domain_v)
        content = pack.pack(output=output, set64=set64)
        log.debug(pack._8583_dic)
        return content

    @keyword
    def dic2packwithmac(self, dic, zk_host, node_url="/posp/crypto_svc_adapter", alg_type: str = "0"):
        """dic字典转8583报文，调用rpc计算64域mac值
        ip, port = '172.20.20.31', '37124'

        - alg_type: 默认0 国际，4是国密算mac
        - dic: dic字典
        - zk_host: /posp/crypto_svc_adapter注册的zookeeper地址
        - node_url: /posp/crypto_svc_adapter
        - return: 8583报文(hexstring)
        """
        ice = ZkLibrary()
        log.info("zk地址: %s" % zk_host)
        ice.zk_init_hosts(zk_host)
        ip, port = ice.query_nodes(node_url)
        msg = "node:" + node_url + ";  rpc request address:" + ip + ":" + port
        log.info(msg)

        # pack1 从MTI（-3）域到63域，及子域
        dic1 = {k: v for k, v in list(dic.items()) if k in range(-3, 64) or isinstance(k, str)}
        field_59 = dic1.get("59", {})
        # 59域A1、59域Z1，rpc接口算的结果就是binary转ascii后的，需要转回去，再组包
        if field_59.get("A1"):
            dic1["59"]["A1"] = binascii.a2b_hex(dic1["59"]["A1"])
        if field_59.get("Z1"):
            dic1["59"]["Z1"] = binascii.a2b_hex(dic1["59"]["Z1"])
        if field_59.get("Z2"):
            dic1["59"]["Z2"] = binascii.a2b_hex(dic1["59"]["Z2"])
        pack1 = self.dic2pack(dic1, output=False, set64=True)
        data = pack1[4:]
        merch_no = dic.get(42)
        term_no = dic.get(41)
        req_msg = {
            "cmd_id": "4001",
            "data": data,
            "merch_no": merch_no,
            "mode": 1,
            "term_no": term_no,
            "alg_type": alg_type,
        }
        log.info(req_msg)
        r = RpcLibrary()
        resp_msg = r.rpc_client_invoke(ip, int(port), req_msg)
        if resp_msg and resp_msg.get("ret_code") == "00":
            domain64 = resp_msg.get("result")
            # 更新mac
            dic.update({64: domain64})
            pack2 = self.dic2pack(dic, output=True)
            return pack2
        else:
            raise Exception("rpc调用失败，无法计算64域mac值")

    @keyword
    def send_posp_invoke(self, message, url):
        """发送posp_invoke请求

        - message: 8583报文(hexstring)
        - url: posp-proxy服务的请求地址
        - return: 8583报文对应的dic字典
        """
        s = requests.Session()
        s.headers.update(
            {"User-Agent": "Test Http 0.1", "Cache-Control": "no-cache", "Content-Type": "x-ISO-TPDU/x-auth"}
        )
        data = binascii.unhexlify(message)
        log.info("请求内容: %s" % base64.b64encode(data).decode())
        res = requests.post(url=url, data=data)
        log.info("响应内容: %s" % base64.b64encode(res.content).decode())
        resp = binascii.hexlify(res.content).decode()
        log.info("响应报文: %s" % resp)
        dic = self.parse(resp)
        log.info("报文解析后: %s" % dic)
        return dic


def str_eval_dict(info):
    try:
        obj = eval(info)
        return obj
    except SyntaxError as e:
        e.msg = "str转dict出错: %s" % info
        raise e
