import platform
import sys

from robotlibcore import DynamicCore

from . import log
from .ActiveMqLibrary import ActiveMqLibrary

# from .AndroidLibrary import AndroidLibrary
# from .ApolloLibrary import ApolloLibrary
from .AzkabanLibrary import AzkabanLibrary
from .ChaosLibrary import ChaosLibrary
from .ConsulLibrary import ConsulLibrary
from .DBLibrary import DBLibrary
from .EsLibrary import EsLibrary
from .FakeLibrary import FakeLibrary
from .FtpLibrary import FtpLibrary
from .HbaseLibrary import HbaseLibrary

# from .IOSLibrary import IOSLibrary
from .InfluxdbLibrary import InfluxdbLibrary
from .KafkaLibrary import KafkaLibrary
from .KubernetesLibrary import KubernetesLibrary
from .POSLibrary import POSLibrary
from .ProfitLibrary import ProfitLibrary
from .RedisLibrary import RedisLibrary
from .RequestLibrary import RequestLibrary
from .RpcLibrary import RpcLibrary

# from .SeleniumLibrary import SeleniumLibrary
from .SSHLibrary import SSHLibrary
from .UtilsLibrary import UtilsLibrary
from .UtilsMsg import UtilsMsg
from .UtilsSign import UtilsSign
from .ZkLibrary import ZkLibrary

plat = sys.platform
can_rocketmq = platform.machine() == 'x86_64' and plat in {'linux', 'darwin'}
if can_rocketmq:
    from .RocketMqLibrary import RocketMqLibrary

__version__ = "1.0.0"


class JLTestLibrary(DynamicCore):
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    ROBOT_LIBRARY_VERSION = __version__

    def __init__(self):
        libraries = [
            # AndroidLibrary(),
            ActiveMqLibrary(),
            # ApolloLibrary(),
            AzkabanLibrary(),
            ChaosLibrary(),
            ConsulLibrary(),
            DBLibrary(),
            FakeLibrary(),
            FtpLibrary(),
            ZkLibrary(),
            # IOSLibrary(),
            InfluxdbLibrary(),
            KafkaLibrary(),
            KubernetesLibrary(),
            RequestLibrary(),
            POSLibrary(),
            ProfitLibrary(),
            RedisLibrary(),
            RpcLibrary(),
            # SeleniumLibrary(),
            SSHLibrary(),
            UtilsLibrary(),
            UtilsMsg(),
            UtilsSign(),
            HbaseLibrary(),
            EsLibrary(),
        ]
        if can_rocketmq:
            libraries.append(RocketMqLibrary())
        DynamicCore.__init__(self, libraries)

    def run_keyword(self, name, args, kwargs=None):
        log.info("正在运行关键字 '%s' : 使用位置参数 %s 和关键字参数 %s" % (name, args, kwargs))
        return DynamicCore.run_keyword(self, name, args, kwargs)
