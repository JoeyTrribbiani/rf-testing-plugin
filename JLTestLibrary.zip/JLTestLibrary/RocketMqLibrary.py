import ctypes
import datetime
import json
import time
import traceback
import uuid
from ctypes import POINTER, c_int

import pymysql
from robot.api.deco import keyword
from robot.utils import ConnectionCache
from rocketmq.client import (
    Message,
    Producer,
    PullConsumer,
    PushConsumer,
    RecvMessage,
    _to_bytes,
)
from rocketmq.exceptions import ffi_check
from rocketmq.ffi import _CMessageQueue, _CPullStatus, dll

from . import log
from .base_data.trade_bill import (
    auth_data,
    cauth_data,
    rcauth_data,
    refund_data,
    sale_data,
    vauth_data,
    vcauth_data,
    vsale_data,
)
from .UtilsMsg import UtilsMsg


class RocketMqLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        # config for mysql
        self.rmq_host = "172.20.6.22"
        self.rmq_port = 3308
        self.rmq_database = "mock_service"
        self.rmq_user = "root"
        self.rmq_password = "123456"
        self.rmq_cache = ConnectionCache("No Rmq Client Create!")

    def get_producer(self, namesrv_addr, group_id):
        key = f"{namesrv_addr}:{group_id}"
        try:
            producer = self.rmq_cache[key]
            log.info(f"使用缓存中的producer {producer} for {key}")
            return producer
        except RuntimeError:
            log.info(f"新建producer for {key}")
            producer = Producer(group_id)
            producer.set_namesrv_addr(namesrv_addr)
            producer.start()
            self.rmq_cache.register(producer, key)
            return self.rmq_cache[key]

    @keyword
    def rocketmq_producer(self, namesrv_addr, group_id, topic_name, msg_body, para_replace=None, tag=''):
        """生产者，对需要发送rocketmq队列
        - namesrv_addr: Specify name server addresses.
        - group_id: Instantiate with a producer group name.
        - topic_name: send topic name.
        - msg_body: send message body.
        - para_replace:
        """
        key = str(uuid.uuid4())
        try:
            producer = self.get_producer(namesrv_addr, group_id)
            # 判断para_replace参数,对传入参数进行替换操作
            if para_replace:
                msg_body = UtilsMsg.str_to_dict(msg_body)
                para_replace = UtilsMsg.str_to_dict(para_replace)
                msg_body = UtilsMsg.para_replace(msg_body, para_replace)

            if isinstance(msg_body, dict):
                msg_body = json.dumps(msg_body, ensure_ascii=False)
            log.info(msg_body)
            # set topic name
            msg = Message(topic_name)

            msg.set_keys("autotest:" + key)
            msg.set_tags(tag)
            msg.set_body(msg_body)

            ret = producer.send_sync(msg)
            log.info((ret.status, ret.msg_id, ret.offset))
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("rocketmq 发送消息异常!", str(e))

    @keyword
    def rocketmq_push_consumer(self, namesrv_addr, consumer_group, topic_name):
        """消费者 Language:CPP Version:V3_1_8"""

        def callback(msg):
            log.info((msg.id, msg.body))

            consumer = PushConsumer(group_id=consumer_group)
            try:
                consumer.set_namesrv_addr(namesrv_addr)
                consumer.subscribe(topic_name, callback)
                consumer.start()

                while True:
                    time.sleep(3600)
            except Exception as e:
                log.warn(traceback.format_exc())
                raise RuntimeError("rocketmq 消费消息异常!", str(e))
            finally:
                consumer.shutdown()

    @keyword
    def rocketmq_pull_consumer(self, namesrv_addr, consumer_group, topic_name):
        """消费者"""
        db = pymysql.connect(
            user=self.rmq_user,
            password=self.rmq_password,
            host=self.rmq_host,
            database=self.rmq_database,
            port=self.rmq_port,
        )
        cursor = db.cursor()
        log.info(f"rockermq 连接地址：{namesrv_addr}")
        log.info(f"消费的topic名称：{topic_name}")
        consumer = JLPullConsumer(group_id=consumer_group)
        key = str(uuid.uuid4())
        msg_tag = "autotest:" + key
        try:
            consumer.set_namesrv_addr(namesrv_addr)
            log.info(f"消费组 {consumer_group} 启动...")
            consumer.start()

            for broker_name, msg in consumer.pull(topic_name, cursor):
                queue_id = msg.queue_id
                msg_id = msg.id
                msg_body = msg.body.decode("utf-8")
                msg_key = msg.keys.decode("utf-8")
                msg_store_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(msg.store_timestamp // 1000))
                queue_offset = msg.queue_offset
                log.info((broker_name, queue_id, queue_offset, msg_id, msg_key, msg_body, msg_store_datetime))
                sql = f"""INSERT INTO t_rocketmq_consume_record
                (topic_name, consumer_group, broker_name, queue_id, queue_offset, msg_id, msg_key, msg_body, msg_store_datetime, msg_tag)
                VALUES ('{topic_name}','{consumer_group}','{broker_name}','{queue_id}','{queue_offset}','{msg_id}','{msg_key}','{msg_body}','{msg_store_datetime}','{msg_tag}')"""
                cursor.execute(sql)
                db.commit()
            db.close()
            return {"code": "00", "msg_tag": msg_tag}
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError("rocketmq 消费消息异常!", str(e))
        finally:
            consumer.shutdown()

    @keyword
    def mock_data_to_order_data_push_mq(
        self,
        rocketmq_address,
        merch_no: str = "849AUTOTEST0001",
        term_no: str = "70006425",
        trans_date="2022-09-30",
        topic="order_data_publish_succ",
    ):
        date = datetime.datetime.strptime(trans_date, "%Y-%m-%d")
        base_type = []
        base_type.extend(sale_data)
        base_type.extend(vsale_data)
        base_type.extend(refund_data)
        base_type.extend(auth_data)
        base_type.extend(vauth_data)
        base_type.extend(cauth_data)
        base_type.extend(vcauth_data)
        base_type.extend(rcauth_data)

        for hour in range(24):
            date = date.replace(hour=hour)
            for index, item in enumerate(base_type):
                date = date.replace(second=index + 1)
                ts = int(date.timestamp() * 1000)
                base_temp = {
                    "add_fee": "0",
                    "agent_id": "642",
                    "amount": 1000,
                    "area_code": "350105",
                    "busi_sub_type": item["busi_sub_type"],
                    "busi_type": item["busi_type"],
                    "create_time": str(date),
                    "expire_time": str(date),
                    "fee": 5,
                    "fee_type": "02",
                    "fund_type": "1",
                    "is_internal_card": "Y",
                    "location": "trans_ip=222.76.2.58&areacode=350105&trans_address=福建省福州市马尾区镇冰路靠近全季酒店(福州马尾自贸区店)&mcc=460&mnc=1&lac=22791&cid=26219680",
                    "merch_no": merch_no,
                    "order_id": f'{term_no}{item["busi_sub_type"]}{ts}',
                    "ori_order_id": f'{term_no}{item["busi_sub_type"]}{ts}',
                    "pay_method": "2",
                    "pay_token": "6212142500000000151",
                    "pay_type": "bankpay",
                    "print_merch_name": "自动化测试fake数据",
                    "pwd_free": "",
                    "ret_code": "00",
                    "ret_msg": "交易成功",
                    "sources": "posp/as_posp_sdk",
                    "status": "2",
                    "term_no": term_no,
                    "term_sn": "JLZFAUTOTEST",
                    "trans_time": str(date),
                    "trans_type": item["trans_type"],
                    "update_time": str(date),
                }
                self.rocketmq_producer(rocketmq_address, "auto_test", topic, msg_body=base_temp)


class JLPullConsumer(PullConsumer):
    def __init__(self, group_id):
        super().__init__(group_id)
        self.consumer_group = group_id

    def _get_mq_key(self, mq):
        key = "%s@%s@%s" % (mq.topic, mq.brokerName.decode(), mq.queueId)
        return key

    def pull(self, topic, cursor, expression="*", max_num=32):
        message_queue = POINTER(_CMessageQueue)()
        queue_size = c_int()
        ffi_check(
            dll.FetchSubscriptionMessageQueues(
                self._handle, _to_bytes(topic), ctypes.pointer(message_queue), ctypes.pointer(queue_size)
            )
        )
        queue_list = []
        for i in range(int(queue_size.value)):
            mq = message_queue[i]
            queue_list.append((mq.brokerName.decode(), mq.queueId))
        log.info(queue_list)

        for i in range(int(queue_size.value)):
            mq = message_queue[i]
            queue_id = mq.queueId
            brokerName = mq.brokerName.decode()
            timeout_flag = 0
            sql = f"""select queue_offset from t_rocketmq_consume_record
            where topic_name='{topic}' and consumer_group ='{self.consumer_group}' and queue_id={queue_id} and broker_name='{brokerName}'
            order by queue_offset desc"""
            cursor.execute(sql)
            queryset = cursor.fetchone()
            tmp_offset = queryset[0] + 1 if queryset else ctypes.c_longlong(self.get_message_queue_offset(mq))
            log.info(f"<{brokerName} queueId={queue_id} queueOffset={tmp_offset}>")

            has_new_msg = True
            while has_new_msg:
                pull_res = dll.Pull(
                    self._handle,
                    ctypes.pointer(mq),
                    _to_bytes(expression),
                    tmp_offset,
                    max_num,
                )
                if pull_res.pullStatus != _CPullStatus.BROKER_TIMEOUT:
                    tmp_offset = pull_res.nextBeginOffset
                    self.set_message_queue_offset(mq, tmp_offset)

                if pull_res.pullStatus == _CPullStatus.FOUND:
                    for i in range(int(pull_res.size)):
                        yield brokerName, RecvMessage(pull_res.msgFoundList[i])
                elif pull_res.pullStatus == _CPullStatus.NO_MATCHED_MSG:
                    pass
                elif pull_res.pullStatus == _CPullStatus.NO_NEW_MSG:
                    has_new_msg = False
                elif pull_res.pullStatus == _CPullStatus.OFFSET_ILLEGAL:
                    pass
                else:
                    log.info(f"pulling broker {brokerName} on queue {queue_id} , start at offset {tmp_offset}")
                    if pull_res.pullStatus == _CPullStatus.BROKER_TIMEOUT:
                        log.info("pullStatus is BROKER_TIMEOUT !!!")
                        timeout_flag += 1
                        if timeout_flag > 2:
                            break
                dll.ReleasePullResult(pull_res)  # NOTE: No need to check ffi return code here
        ffi_check(dll.ReleaseSubscriptionMessageQueue(message_queue))
