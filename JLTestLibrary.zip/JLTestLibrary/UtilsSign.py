import base64
import binascii
import hashlib
import hmac
import json
import secrets
import traceback
import urllib.parse
from hashlib import sha256
from typing import Union

import OpenSSL
from Crypto.Cipher import AES
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1_v1_5
from Crypto.Hash import SHA, SHA256
from Crypto.IO import PEM, PKCS8
from Crypto.Math.Numbers import Integer
from Crypto.PublicKey import (  # noqa
    RSA,
    _create_subject_public_key_info,
    _expand_subject_public_key_info,
)
from Crypto.Signature import PKCS1_v1_5
from Crypto.Signature import PKCS1_v1_5 as Signature_pkcs1_v1_5
from Crypto.Util.asn1 import DerInteger, DerObjectId, DerOctetString, DerSequence
from Crypto.Util.py3compat import bord
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)
from gmssl import func
from gmssl.sm2 import CryptSM2
from gmssl.sm3 import sm3_hash, sm3_kdf
from gmssl.sm4 import SM4_DECRYPT, SM4_ENCRYPT, CryptSM4
from OpenSSL.crypto import FILETYPE_PEM, PKey
from pyasn1.codec.der.decoder import decode
from robot.api.deco import keyword

from . import log
from .asn1.sm2 import SM2Sequence
from .UtilsLibrary import UtilsLibrary

utils = UtilsLibrary


class UtilsSign:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @staticmethod
    @keyword
    def sign_sha256(pri_key: str, data: str, passphrase: str = "") -> str:
        """SHA256withRSA（RSA2）签名算法

        - pri_key: 私钥
        - data: 待签字符串
        - return: base64 signature
        """
        try:
            if not pri_key.startswith("-----"):
                pri_key = "-----BEGIN PRIVATE KEY-----\n" + pri_key.strip() + "\n-----END PRIVATE KEY-----"
            key = RSA.importKey(pri_key, passphrase)
            data_bytes = data.encode("utf-8")
            h = SHA256.new(data_bytes)
            signer = PKCS1_v1_5.new(key)
            signature = signer.sign(h)  # noqa
            return base64.b64encode(signature).decode("utf-8")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"sign_sha256 Exception: {str(e)}")

    @staticmethod
    @keyword
    def parse_private_key(private_key_asn_hex):
        hex_str_len = private_key_asn_hex[12:14]
        int_val = int(hex_str_len, 16)
        return private_key_asn_hex[14:(14 + int_val * 2)]

    @staticmethod
    @keyword
    def sign_hmac_sha256(app_secret: str, data: str) -> str:
        """HMAC-SHA256算法

        - app_secret: 密钥 "123456789123456".encode('utf-8')
        - data: 待加密数据 "84961018062A003|5000|1001010420200611175138000222|2020-06-11 17:51:38".encode('utf-8')
        - return: signature[:16]
        """
        try:
            app_secret_bytes = app_secret.encode("utf-8")
            data_bytes = data.encode("utf-8")
            # 获取十六进制加密数据
            signature = hmac.new(app_secret_bytes, data_bytes, digestmod=sha256).hexdigest()
            # 只取前16位密文 大写(大鹏与java交互，定义只取前16位字段)
            signature = signature[:16].upper()
            return signature
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"sign_hmac_sha256 Exception: {str(e)}")

    @staticmethod
    @keyword
    def sign_sha(pri_key: str, data: str) -> str:
        """SHAwithRSA（RSA）签名算法

        - pri_key: 私钥
        - data: 待签字符串
        - return: base64 signature
        """
        try:
            if not pri_key.startswith("-----"):
                pri_key = "-----BEGIN PRIVATE KEY-----\n" + pri_key.strip() + "\n-----END PRIVATE KEY-----"
            key = RSA.importKey(pri_key)
            if isinstance(data, str):
                data_bytes = data.encode("utf-8")
            h = SHA.new(data_bytes)  # noqa
            signer = PKCS1_v1_5.new(key)
            signature = signer.sign(h)
            return base64.b64encode(signature).decode()
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"sign_sha Exception: {str(e)}")

    @staticmethod
    @keyword
    def verify_256sign(pubkey: str, data: str, sign: str) -> bool:
        """SHA256withRSA（RSA2）验签算法

        - pubkey: 公钥
        - data: 待签字符串
        - sign: base64 signature
        - return: True or False
        """
        try:
            key = RSA.importKey(base64.b64decode(pubkey))
            verifier = Signature_pkcs1_v1_5.new(key)
            digest = SHA256.new()
            digest.update(data.encode("utf8"))
            is_verify = verifier.verify(digest, base64.b64decode(sign))  # noqa
            log.info("RSA2 验签结果:", is_verify)
            if not is_verify:
                raise AssertionError("RSA2 验签失败")
            return is_verify
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"verify_256sign Exception: {str(e)}")

    @staticmethod
    @keyword
    def verify_sign(pubkey: str, data: str, sign: str) -> bool:
        """SHAwithRSA（RSA）验签算法

        - pubkey: 公钥
        - data: 待签字符串
        - sign: base64 signature
        - return: True or False
        """
        try:
            rsa_key = RSA.importKey(base64.b64decode(pubkey))
            verifier = Signature_pkcs1_v1_5.new(rsa_key)
            _bytes = data.encode("utf8")
            digest = SHA.new()  # noqa
            digest.update(_bytes)
            is_verify = verifier.verify(digest, base64.b64decode(sign))
            log.info("RSA 验签结果:", is_verify)
            if not is_verify:
                raise AssertionError("RSA 验签失败")
            return is_verify
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"verify_256sign Exception: {str(e)}")

    @staticmethod
    @keyword
    def sha1_partition(key: str, maxPartitionNum: int = 32) -> str:
        """账务数据库，水平分表算法。根据订单号获取分表id

        - key: 方案调整后这里通常传入order_id
        - return: 分表ID
        """
        sha = hashlib.sha1(key.encode("utf-8"))
        encrypt = sha.hexdigest().upper()
        log.info("{} sha1 hex: {}".format(key, encrypt))
        preffix = "0x" + encrypt[:8]
        num = int(preffix, 16)
        result = str(num % maxPartitionNum + 1).rjust(3, "0")
        log.info("{} ==> {}".format(preffix, result))
        return result

    @staticmethod
    def _pad(data: Union[str, bytes], padding: bytes = b"") -> bytes:
        """PKCS5Padding, block_size为16

        - 默认补充位索引（填充数据为填充字节的长度）
        - padding（可选）: 需要补0x00时，padding=b'\x00'

        """
        if isinstance(data, str):
            data = data.encode("utf-8")
        if padding:
            while len(data) % AES.block_size != 0:
                data += padding
        else:
            pad_len = AES.block_size - (len(data) % AES.block_size)
            data += bytes([pad_len] * pad_len)
        return data

    @staticmethod
    def _unpad(data: Union[str, bytes], padding: bytes = b"") -> bytes:
        """PKCS5Padding

        - 默认删除位索引（填充数据为填充字节的长度）
        - padding（可选）: 需要删除结尾0x00时，padding=b'\x00'

        """
        if isinstance(data, str):
            data = data.encode("utf-8")
        if padding:
            data = data.replace(padding, b"")
        else:
            # if len(data) % AES.block_size != 0:
            pad_len = data[-1]
            data = data[:-pad_len]
        return data

    @staticmethod
    @keyword
    def aes_ecb_decrypt(content: bytes, key: bytes, padding: bytes = b"") -> str:
        """AES/ECB/PKCS5Padding 解密算法

        - content: AES密文
        - key: 对称密钥
        - padding: 可选参数, defaults to None
        - return : 解密后的明文
        """

        aes = AES.new(key, AES.MODE_ECB)
        decrypted = aes.decrypt(content)
        decrypted_text = UtilsSign._unpad(decrypted, padding)
        return decrypted_text.decode("utf-8")

    @staticmethod
    @keyword
    def aes_ecb_encrypt(text: Union[str, bytes], key: bytes, padding: bytes = b"") -> bytes:
        """AES/ECB/PKCS5Padding 加密算法

        - text: 待加密的明文
        - key: 对称密钥
        - padding: 可选参数, defaults to None
        - return : 加密后的AES密文
        """
        aes = AES.new(key, AES.MODE_ECB)
        encrypt_aes = aes.encrypt(UtilsSign._pad(text, padding))
        return encrypt_aes

    @staticmethod
    @keyword
    def aes_cbc_decrypt(content: bytes, key: bytes, iv: bytes) -> str:
        """AES/CBC/PKCS5Padding 解密算法

        - content: AES密文
        - key: 对称密钥
        - return: 解密后的明文
        """
        aes = AES.new(key, AES.MODE_CBC, iv=iv)
        decrypted = aes.decrypt(content)
        decrypted_text = UtilsSign._unpad(decrypted)
        return decrypted_text.decode("utf-8")

    @staticmethod
    @keyword
    def aes_cbc_encrypt(text: Union[str, bytes], key: bytes, iv: bytes) -> bytes:
        """AES/CBC/PKCS5Padding 加密算法

        - text: 待加密的明文
        - key: 对称密钥
        - return: 加密后的AES密文
        """
        aes = AES.new(key, AES.MODE_CBC, iv)
        encrypt_aes = aes.encrypt(UtilsSign._pad(text))
        return encrypt_aes

    @staticmethod
    @utils._method_logging
    def _agent_encrypt_param_context(
        request_common: dict, request_token: str, request_param: dict, agent_aes_key: str = "U6woFMMEYEjgb+Ep"
    ):
        """agent-web/agent-query 密文内容

        - request_common: 请求的common
        - request_token: 请求的token
        - request_param: 请求参数
        - agent_aes_key: 加密key
        - return: base64编码后的密文
        """
        request_common = json.dumps(request_common, separators=(",", ":"))
        request_param = json.dumps(request_param, separators=(",", ":"))
        context_encode = ""
        context_encode += "common=" + urllib.parse.quote_plus(request_common)
        context_encode += "&"
        context_encode += "token=" + urllib.parse.quote_plus(request_token)
        context_encode += "&"
        context_encode += "param=" + urllib.parse.quote_plus(request_param)
        log.info(f"加密前内容:", context_encode)
        key = AesKeyUtils.convert(0, agent_aes_key.encode("utf-8"))
        encrypted = UtilsSign.aes_ecb_encrypt(context_encode, key, padding=b"\x00")
        # 这里就使用encodebytes，Encode a bytestring into a bytes object containing multiple lines
        #     of base-64 data.
        encrypt_context_encode = base64.encodebytes(encrypted).decode("utf-8")
        return encrypt_context_encode

    @staticmethod
    @utils._method_logging
    def _agent_decrypt_param_context(
        encrypt_context: str, agent_aes_key: str = "U6woFMMEYEjgb+Ep", url_decode: bool = False
    ):
        """agent-web/agent-query 密文解密

        - response: 响应体
        - agent_aes_key: 用于解密的key
        - url_decode: 是否需要url decode
        - return: 解密后的报文
        """
        key = AesKeyUtils.convert(0, agent_aes_key.encode("utf-8"))
        decrypt_context_encode = UtilsSign.aes_ecb_decrypt(
            base64.b64decode(encrypt_context.encode("utf-8")), key, padding=b"\x00"
        )
        if url_decode:
            decrypt_context = urllib.parse.unquote_plus(decrypt_context_encode, "utf-8")
        else:
            decrypt_context = decrypt_context_encode
        return decrypt_context

    @staticmethod
    @keyword
    def get_to_sign_param_str(param: dict, sign_field="paramSign"):
        """agent-web/agent-query 获取待签串

        - param: 参数
        - return: 待签名的字符串
        """
        if not param:
            return None
        to_sign_param_str = []
        key_list = sorted(param.keys())
        for key in key_list:
            if key == sign_field:
                continue
            value = param.get(key)
            if isinstance(value, str):
                if not value:
                    continue
                else:
                    to_sign_param_str.append(f"{key}={value}")
        sign_str = "&".join(to_sign_param_str)
        log.info("签名前内容:", sign_str)
        return sign_str

    @staticmethod
    @keyword
    def get_to_sign_param_str_md5(param: dict, sign_field="paramSign"):
        sign_str_md5 = UtilsSign.md5(UtilsSign.get_to_sign_param_str(param, sign_field))
        log.info("签名前内容(MD5)为", sign_str_md5)
        return sign_str_md5

    @staticmethod
    @keyword
    def _agent_verify_form_param(param, pub_key):
        """agent-web/agent-query param验签
        not used

        - param: 即将验签的参数
        - pub_key: 用于验签的key
        - return: 验签后的参数
        """
        params = json.loads(param.replace("\n", ""))
        sign = params.pop("paramSign")
        to_sign_param_str = UtilsSign.get_to_sign_param_str(params)
        m = hashlib.md5(to_sign_param_str.encode("utf-8"))
        md5_hex_str = m.hexdigest()
        assert UtilsSign.verify_256sign(pub_key, md5_hex_str, sign) is True
        return params

    @staticmethod
    @utils._method_logging
    def _agent_verify_sign_response(text, pub_key):
        """agent-web/agent-query 响应验签

        - text:
        - pub_key:
        - return:
        """
        json_object = json.loads(text)
        if json_object.get("rows"):
            param = json.dumps(json_object.get("rows"))
        elif json_object.get("data"):
            param = json.dumps(json_object.get("data"))
        else:
            log.info("data或rows都不存在，不做签名验证")
            return text
        params = json.loads(param.replace("\n", ""))
        if isinstance(params, dict):
            if not params.get("paramSign"):
                log.warn("签名不存在，无法校验，请检查响应信息")
                return text
            sign = params.pop("paramSign")
            to_sign_param_str = UtilsSign.get_to_sign_param_str(params)
            m = hashlib.md5(to_sign_param_str.encode("utf-8"))
            md5_hex_str = m.hexdigest()
            assert UtilsSign.verify_256sign(pub_key, md5_hex_str, sign) is True
            return params

    @staticmethod
    def _agent_sign_form_param(params: Union[str, dict], pri_key: str, sign_field: str = "paramSign") -> dict:
        """agent-web/agent-query param加签

        - param: 加签前参数
        - pri_key: 加签用的私钥
        - return: 加签后的参数
        """
        if isinstance(params, str):
            params = json.loads(params)
        to_sign_param_str = UtilsSign.get_to_sign_param_str(params, sign_field)
        m = hashlib.md5(to_sign_param_str.encode("utf-8"))
        md5_hex_str = m.hexdigest()
        sign = UtilsSign.sign_sha256(pri_key, md5_hex_str)
        params[sign_field] = sign
        return params

    @staticmethod
    def _get_private_key(pkcs_12_file, password):
        """获取证书ID、和私钥

        - password: 私钥密码
        - pkcs_12_file: .pfx文件
        - return: 证书ID和私钥的字典
        """
        cert = {}
        with open(pkcs_12_file, "rb") as f:
            print(pkcs_12_file)
            certs = OpenSSL.crypto.load_pkcs12(f.read(), password)
            x509data = certs.get_certificate()
            cert["certid"] = x509data.get_serial_number()
            cert["pkey"] = certs.get_privatekey()
            print("cert_id", cert["certid"])
            # pkcs_8_pri_key = cert['pkey'].to_cryptography_key().private_bytes(Encoding.PEM,
            #                                                                   PrivateFormat.PKCS8,
            #                                                                   NoEncryption())
            # print('pkcs#8_pri_key:', pkcs_8_pri_key, sep='\n')
            pkcs_1_pri_key = (
                cert["pkey"]
                .to_cryptography_key()
                .private_bytes(Encoding.PEM, PrivateFormat.TraditionalOpenSSL, NoEncryption())
            )
            print("pkcs#1_pri_key:", pkcs_1_pri_key, sep="\n")

        return cert

    @staticmethod
    def _get_public_key(pkcs_12_file: str):
        """获取证书ID、和公钥

        - pkcs_12_file: .cer文件
        - return: 证书ID和公钥的字典
        """
        cert = {}
        with open(pkcs_12_file, "rb") as f:
            print(pkcs_12_file)
            x509data = OpenSSL.crypto.load_certificate(FILETYPE_PEM, f.read())
            cert["certid"] = x509data.get_serial_number()
            cert["key"] = x509data.get_pubkey()
            pkcs_1_pub_key = x509data.get_pubkey().to_cryptography_key().public_bytes(Encoding.PEM, PublicFormat.PKCS1)
            print("cert_id", cert["certid"])
            print("pkcs#1_pub_key:", pkcs_1_pub_key, sep="\n")
        return cert

    @staticmethod
    def _get_sm2_private_key(sm2_file: str, password: str):
        """获取sm2证书ID、和私钥

        - password: 私钥密码
        - sm2_file: .sm2文件
        - return: sm2的证书ID、和私钥
        """
        if not password:
            raise ValueError("sm2_file password should not be null")
        with open(sm2_file, "rb") as f:
            print(sm2_file)
            data = base64.b64decode(f.read())
            sm2_cert, res = decode(data, asn1Spec=SM2Sequence())
            print(sm2_cert)
            encryptedData = sm2_cert["privateInfo"]["key"]._value
            hash = bytes.fromhex(sm3_kdf(password.encode("utf8").hex().encode(), 32))
            iv, sm4 = hash[:16], hash[16:]
            crypt_sm4 = CryptSM4()
            crypt_sm4.set_key(sm4, SM4_DECRYPT)
            d = crypt_sm4.crypt_cbc(iv, encryptedData).hex()
            print("sm2 pri_key", d)
            sm2_signer = SM2Signer(private_key=d, public_key=None)
            print("cal sm2 pub_key", sm2_signer._get_pub_point())

        return d

    @staticmethod
    def _get_sm2_public_key(cer_file: str):
        """获取sm2证书ID、和公钥

        - password: 私钥密码
        - cer_file: .cer文件
        - return: sm2证书ID、和公钥的字典
        """
        with open(cer_file, "rb") as f:
            print(cer_file)
            data = base64.b64decode(f.read())
            pass

    @staticmethod
    @keyword
    def union_fq_sign(data: str, pri_key: str) -> str:
        """银联分期码回调加签

        - data: 待签名字符串
        - pri_key: 不带密码的私钥 pkcs#1格式
        - return: 签名后的base64字符串
        """
        data_bytes = data.encode("utf-8")
        sha_256 = hashlib.sha256(data_bytes).hexdigest()
        pri_key_bytes = pri_key.encode("utf-8")
        private_key = serialization.load_pem_private_key(pri_key_bytes, password=None, backend=None)
        private = OpenSSL.crypto.sign(PKey.from_cryptography_key(private_key), sha_256, "sha256")
        sign = base64.b64encode(private).decode("utf-8")
        return sign

    @staticmethod
    @keyword
    def union_sign(data: str, pri_key: str) -> str:
        """银联二维码回调加签

        - data: 待签名字符串
        - pri_key: 不带密码的私钥 pkcs#1格式
        - return: utf-8解码后的加签结果
        """
        data_bytes = data.encode("utf-8")
        sha_1 = hashlib.sha1(data_bytes).hexdigest()
        pri_key_bytes = pri_key.encode("utf-8")
        private_key = serialization.load_pem_private_key(pri_key_bytes, password=None, backend=None)
        private = OpenSSL.crypto.sign(PKey.from_cryptography_key(private_key), sha_1, "sha1")
        sign = base64.b64encode(private).decode("utf-8")
        return sign

    @staticmethod
    @keyword
    def decrypt_login_pwd(payload: dict) -> str:
        """参考CFCA密码控件SDK，解密密码

        - payload: login dict
        - return: 明文密码
        """
        default_key = "ABCDEF5840484900"
        pwd_mode = payload.get("pwdMode")
        login_pwd = payload.get("loginPwd")
        server_random_id = payload.get("serverRandomId")
        client_random = payload.get("clientRandom")

        # aes ecb 解密server random id为server random
        server_random = UtilsSign.aes_ecb_decrypt(binascii.unhexlify(server_random_id), default_key.encode("utf-8"))
        server_random = server_random.encode("utf-8")
        log.info("server random", server_random)
        private_key = "085F71A93E7057F944925867F63FBE995BA04548B6D2C2636A60E4673BF00FE5"
        public_key = "3975934088F90CBD31705166D5EFCE5219E0B2FA26F78121FC6A3142A51EDCDA5976CD802E7A5B3D213F348CA3CFDA81BC1C04009EC8C056183A44D642E7102E"

        # sm2 使用h5PasswordCert.SM2的私钥，解密client random
        sm2_crypt = CryptSM2(public_key=public_key, private_key=private_key)
        encrypted_rc = base64.b64decode(client_random.encode("utf-8"))
        encrypted_data = base64.b64decode(login_pwd.encode("utf-8"))
        client_random = sm2_crypt.decrypt(encrypted_rc)
        # sm4 使用server_random和client_random解密密文，得到登录密码
        key = server_random[:8] + client_random[:8]
        iv = server_random[8:] + client_random[8:]
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key, SM4_DECRYPT)
        encrypt_value = crypt_sm4.crypt_cbc(iv, encrypted_data)
        return encrypt_value.decode("utf-8")

    @staticmethod
    @keyword
    def encrypt_login_pwd(
        pwd: str,
        pwd_mode: int = 1,
        server_random_id: str = "",
        camel_case: bool = True,
        agent: bool = False,
        digital_cash: bool = False,
    ):
        """参考CFCA密码控件SDK，加密密码

        - pwd: 密码
        - pwd_mode: 0 rsa公钥加密，1 cfca sm2公钥加密
        - agent: 可选参数，合伙人登录时为True
        - digital_cash: 可选参数，数字货币提现密码时为True
        - return: 加密后密码
        """
        default_key = "ABCDEF5840484900"
        # 16位 byte
        client_random = secrets.token_bytes(16)
        # 16位 base64 字符串
        if not server_random_id:
            server_random = base64.b64encode(secrets.token_bytes(10)).decode("utf-8")
        else:
            server_random = UtilsSign.aes_ecb_decrypt(bytes.fromhex(server_random_id), default_key.encode("utf-8"))
        # sm4 使用server_random和client_random加密登录密码
        key = server_random.encode("utf-8")[:8] + client_random[:8]
        iv = server_random.encode("utf-8")[8:] + client_random[8:]
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key, SM4_ENCRYPT)
        encrypted_data = crypt_sm4.crypt_cbc(iv, pwd.encode("utf-8"))
        login_pwd = base64.b64encode(encrypted_data).strip().decode("utf-8")

        # aes ecb 加密server random为server random id
        # 增加位索引
        server_random = server_random.encode("utf-8")
        log.info("server random", server_random)
        server_random_id = (
            UtilsSign.aes_ecb_encrypt(server_random.decode("utf-8"), default_key.encode("utf-8")).hex().upper()
        )

        private_key = "085F71A93E7057F944925867F63FBE995BA04548B6D2C2636A60E4673BF00FE5"
        public_key = "3975934088F90CBD31705166D5EFCE5219E0B2FA26F78121FC6A3142A51EDCDA5976CD802E7A5B3D213F348CA3CFDA81BC1C04009EC8C056183A44D642E7102E"
        sm2_crypt = CryptSM2(public_key=public_key, private_key=private_key)
        encrypted_rc = sm2_crypt.encrypt(client_random)
        base64_encrypted_rc = base64.b64encode(encrypted_rc).decode("utf-8")
        pwd_key = ("userpwd", "userpwd") if agent else ("loginPwd", "login_pwd")
        pwd_key = ("password", "password") if digital_cash else ("loginPwd", "login_pwd")
        if camel_case:
            result = {
                pwd_key[0]: login_pwd,
                "serverRandomId": server_random_id,
                "clientRandom": base64_encrypted_rc,
                "pwdMode": pwd_mode,
            }
        else:
            result = {
                pwd_key[1]: login_pwd,
                "server_random_id": server_random_id,
                "client_random": base64_encrypted_rc,
                "pwd_mode": pwd_mode,
            }
        return result

    @staticmethod
    @keyword
    def rsa_ecb_decrypt(content: Union[str, bytes], pri_key: str, b64: bool = False):
        """RSA/ECB/PKCS1Padding解密算法

        - content: 解密前的内容
        - pri_key: 用于解密的key
        - return:
        """
        if b64:
            content = base64.b64decode(content)
        if isinstance(content, str):
            content = content.encode("utf-8")
        if not pri_key.startswith("-----"):
            pri_key = "-----BEGIN PRIVATE KEY-----\n" + pri_key.strip() + "\n-----END PRIVATE KEY-----"
        priv_key = RSA.importKey(pri_key)
        cipher = Cipher_pkcs1_v1_5.new(priv_key)
        decrypted_text = cipher.decrypt(content, "Any")
        return decrypted_text.decode("utf-8")

    @staticmethod
    @keyword
    def rsa_ecb_encrypt(content: Union[str, bytes], pubkey: str, b64: bool = False) -> Union[bytes, str]:
        """RSA/ECB/PKCS1Padding加密算法

        - content: 加密前内容
        - pubkey: 用于加密的公钥
        - return: 加密后的文本
        """
        if isinstance(content, str):
            content = content.encode("utf-8")
        if not pubkey.startswith("-----"):
            pubkey = "-----BEGIN RSA PUBLIC KEY-----\n" + pubkey + "\n-----END RSA PUBLIC KEY-----"
        pubkey_bytes = RSA.importKey(pubkey)
        cipher = Cipher_pkcs1_v1_5.new(pubkey_bytes)
        encrypted_text = cipher.encrypt(content)
        if b64:
            return base64.b64encode(encrypted_text).decode("utf-8")
        return encrypted_text

    @staticmethod
    @keyword
    def rsa_decrypt_login_pwd(login_pwd: str, pri_key: str) -> str:
        """RSA解密登录密码

        - payload: 登录请求体
        - pri_key: 解密私钥
        - return: 解密后的密码
        """
        if not login_pwd:
            return ""
        if not pri_key.startswith("-----"):
            pri_key = "-----BEGIN RSA PRIVATE KEY-----\n" + pri_key + "\n-----END RSA PRIVATE KEY-----"
        decrypted = UtilsSign.rsa_ecb_decrypt(base64.b64decode(login_pwd), pri_key)
        # 密码先RSA解密,再除去后十位随机数
        decrypted_text = decrypted[:-10]
        return decrypted_text

    @staticmethod
    @keyword
    def rsa_encrypt_login_pwd(pwd: str, pub_key: str, md5: bool = False) -> dict:
        """RSA加密登录密码
        manage-user MngUserServiceImpl preLogin方法，需要先md5

        - pwd: 登录密码
        - pub_key: 加密用的公钥
        - return: 加密后的密码
        """
        if md5:
            pwd = UtilsSign.md5(pwd)
        login_pwd = pwd + "".join([str(secrets.randbelow(10)) for _ in range(10)])
        if not pub_key.startswith("-----"):
            pub_key = "-----BEGIN RSA PUBLIC KEY-----\n" + pub_key + "\n-----END RSA PUBLIC KEY-----"
        encrypted = UtilsSign.rsa_ecb_encrypt(login_pwd, pub_key)
        base64_encrypted = base64.b64encode(encrypted).decode("utf-8")
        return base64_encrypted

    @staticmethod
    @keyword
    def rsa_encrypt_agent_login_pwd(account: str, pwd: str, pub_key: str) -> str:
        """RSA加密登录密码

        - pwd: 加密前的密码
        - pub_key: 加密公钥
        - return: 加密后的密码
        """
        login_pwd = account[:-4] + pwd + "".join([str(secrets.randbelow(10)) for _ in range(10)])
        if not pub_key.startswith("-----"):
            pub_key = "-----BEGIN RSA PUBLIC KEY-----\n" + pub_key + "\n-----END RSA PUBLIC KEY-----"
        encrypted = UtilsSign.rsa_ecb_encrypt(login_pwd, pub_key)
        base64_encrypted = base64.b64encode(encrypted).decode("utf-8")
        return base64_encrypted

    @staticmethod
    @keyword
    def sm2_encrypt_data(data: str, pub_key: str) -> str:
        """SM2加密手机号/密码

        - data: 加密前手机号/密码
        - pub_key: 加密公钥
        - return: 加密后手机号/密码
        """
        login_data = data + "".join([str(secrets.randbelow(10)) for _ in range(10)])
        log.info(f"待加密串:{login_data}")
        sm2_crypt = SM2Signer(public_key=pub_key, private_key=None)
        encrypted = sm2_crypt.encrypt(login_data.encode("utf-8"))
        base64_encrypted = base64.b64encode(encrypted).decode("utf-8")
        return base64_encrypted

    @staticmethod
    @keyword
    def sm2_encrypt(data: Union[str, bytes], pub_key: str, b64_content: bool = False, b64_encrypt: bool = True) -> str:
        """SM2加密算法

        - data: 加密前字符串
        - pub_key: 加密用的公钥
        - b64_content: 加密前明文是否base64编码, 默认值为False
        - b64_encrypt: 加密后密文是否base64编码, 默认值为True
        - return: 加密后字符串
        """
        if isinstance(data, bytes):
            data_bytes = data
        else:
            data_bytes = data.encode("utf-8")
        if b64_content:
            data_bytes = base64.b64decode(data_bytes)
        sm2_crypt = SM2Signer(public_key=pub_key, private_key=None)
        encrypted = sm2_crypt.encrypt(data_bytes)
        if b64_encrypt:
            return base64.b64encode(encrypted).decode("utf-8")
        return encrypted.hex()

    @staticmethod
    @keyword
    def sm2_decrypt(base64_data: str, pri_key: str, b64_content: bool = False) -> str:
        """SM2解密算法

        - data: 解密前密文
        - pri_key: 解密私钥
        - b64_content: 解密后明文是否需要base64编码, 默认值为False
        - return: 解密后密码
        """
        data = base64.urlsafe_b64decode(base64_data)
        sm2_crypt = SM2Signer(public_key=None, private_key=pri_key)
        encrypted = sm2_crypt.decrypt(data)
        return base64.b64encode(encrypted).decode("utf-8") if b64_content else encrypted.decode("utf-8")

    @staticmethod
    @utils._method_logging
    def decrypt_busi_key(gate_aes_key: str, busi_key: str) -> str:
        """AES/CBC/PKCS5Padding解密得到明文的aes_key

        - gate_aes_key: OPEN_GATEWAY_USER.T_APP_ENC_CONFIG 表里，就是加密了的gate_aes_key
        - busi_key: CRYPTO_USER.T_BUSI_KEY 表里, 或直接调用/posp/crypto_svc_adapter cmd=1101获取,表里的key也是加密的，使用rpc拿更好
        """
        gate_aes_key_bytes = base64.b64decode(gate_aes_key)
        busi_key_bytes = bytes.fromhex(busi_key)
        dec_key = UtilsSign.aes_cbc_decrypt(gate_aes_key_bytes, busi_key_bytes, iv=b"\x00" * 16)
        return dec_key

    @staticmethod
    @utils._method_logging
    def decrypt_biz_content(biz_content: str, app_key: str, key_type: str = "AES", padding=None) -> str:
        """APP全报文解密方法

        - biz_content: 解密前内容
        - app_key: 解密用的密钥, key_type为AES时传入对称密钥, key_type为其他时传入RSA的私钥
        - key_type: 可选, 默认值为AES
        - padding: 可选, 默认值为None
        - return: 解密后的明文
        """
        encrypt_datas = base64.b64decode(biz_content)
        if key_type == "AES":
            key = AesKeyUtils.convert(0, app_key.encode("utf-8"))
            original = UtilsSign.aes_ecb_decrypt(encrypt_datas, key, padding=padding)
        elif key_type == "SM4":
            key = bytes.fromhex(app_key)
            original = UtilsSign._sm4_ecb_decrypt(encrypt_datas, key)
        else:
            # RSA 私钥解密
            original = UtilsSign.rsa_ecb_decrypt(encrypt_datas, app_key)
        return original

    @staticmethod
    @utils._method_logging
    def encrypt_biz_content(original: str, app_key: str, sm4: bool = False) -> str:
        """APP全报文加密方法

        - original: 加密前的明文
        - app_key: AES对称密钥
        - return: 加密后报文
        """
        if sm4:
            return UtilsSign.sm4_ecb_encrypt(original, app_key, b64_content=False, b64_encrypt=True)
        else:
            key = AesKeyUtils.convert(0, app_key.encode("utf-8"))
            encrypt_datas = UtilsSign.aes_ecb_encrypt(original, key)
            biz_content = base64.b64encode(encrypt_datas)
            return biz_content.decode("utf-8")

    @staticmethod
    @keyword
    def password_aes_encrypt(pwd: str, aes_key: str) -> str:
        """立刷登录密码加密

        - pwd: 立刷登录密码
        - aes_key: 加密AES公钥
        - return:
        """
        user_pwd = UtilsSign.aes_ecb_encrypt(pwd, AesKeyUtils.convert(0, aes_key.encode("utf-8")))
        user_pwd = base64.b64encode(user_pwd).decode("utf-8")
        return user_pwd

    @staticmethod
    @keyword
    def sha256_base64(data: str) -> str:
        """sha256摘要算法

        - data: 待hash加密的明文
        - return: base64编码后的密文
        """
        sha256_hex = sha256(data.encode("utf-8")).hexdigest()
        return base64.b64encode(sha256_hex.encode("utf-8")).decode("utf-8")

    @staticmethod
    @keyword
    def sign256_base64(data: str) -> str:
        sha256_data = sha256(data.encode("utf-8")).digest()
        return base64.b64encode(sha256_data).decode("utf-8")

    @staticmethod
    @keyword
    def hash_phone(phone: str) -> str:
        """立刷登录手机号混淆

        - phone: 立刷登录手机号
        - return: SHA256的混淆结果
        """
        user_mp = phone if len(phone.strip()) != 11 else UtilsSign.sha256_base64(phone)
        return user_mp

    @staticmethod
    @keyword
    def get_sha1prng_key(key: str) -> str:
        """SHA1PRNG算法

        - key: 需要加密的key
        - return: 加密后签名
        """
        signature = hashlib.sha1(key.encode("utf-8")).digest()
        signature = hashlib.sha1(signature).digest()
        return "".join(["%02x" % i for i in signature]).upper()[:32]

    @staticmethod
    @keyword
    def sign_sm2(data: Union[str, bytes], private_key: str, asn1: bool = True, with_id: str = "") -> str:
        """SM3withSM2签名算法

        - data: 需要签名数据
        - private_key: hex格式的sm2私钥
        - asn1: 可选, sm2签名结果是否需要asn1编码(der编码), 默认为True
        - with_id: 可选, 如果需要指定用户id签名时传入, 默认为None
        - return: base64编码的签名
        """
        if isinstance(data, str):
            data = data.encode("utf-8")
        sm2_signer = SM2Signer(private_key=private_key, public_key=None, asn1=asn1)
        sm2_sign = sm2_signer.sign_with_sm3(data, with_id=with_id)
        if not asn1:
            sm2_sign = bytes.fromhex(sm2_sign)
        sm2_sign_b64 = base64.b64encode(sm2_sign).decode("utf-8")
        return sm2_sign_b64

    @staticmethod
    @keyword
    def verify_sm2_sign(
        public_key: str, data: Union[str, bytes], sign: str, asn1: bool = True, with_id: str = ""
    ) -> bool:
        """SM3withSM2验签算法

        - public_key: hex格式的sm2公钥
        - data: 验签数据
        - sign: base64编码的签名
        - asn1: 可选, sm2签名结果是否需要asn1编码(der编码), 默认为True
        - with_id: 可选, 如果需要指定用户id签名时传入, 默认为None
        - return: 是否验签成功
        """
        if isinstance(data, str):
            data = data.encode("utf-8")
        sm2_sign = base64.b64decode(sign.encode("utf-8"))
        if not asn1:
            sm2_sign = sm2_sign.hex()
        sm2_crypt = SM2Signer(private_key=None, public_key=public_key, asn1=asn1)
        is_verify = sm2_crypt.verify_with_sm3(sm2_sign, data, with_id)
        log.info("SM3withSM2验签结果:", is_verify)
        if not is_verify:
            raise AssertionError("SM3withSM2验签失败")
        return is_verify

    @staticmethod
    def sm3_hash_with_z(data_bytes: bytes, z_bytes: bytes):
        return sm3_hash(func.bytes_to_list(z_bytes + data_bytes))

    @staticmethod
    @keyword
    def sm3_hash_with_zbase64(data: str, zbase64: str):
        data_bytes = data.encode('utf-8')
        z_bytes = base64.b64decode(zbase64)
        return UtilsSign.sm3_hash_with_z(data_bytes, z_bytes)

    @staticmethod
    @keyword
    def sm3_get_hash(data: str):
        hash = hashlib.new('sm3', data.encode('utf-8')).digest()
        value = hash.hex()
        return value

    @staticmethod
    @keyword
    def sm2_pri_pem_to_hex(pem_str: str) -> str:
        """SM2私钥pem字符串转hex字符串

        参考Crypto.PublicKey.ECC

        - pem_str: SM2私钥的pem格式
        - return: hex格式
        """
        # PEM 转 PKCS8
        der_encoded, marker, enc_flag = PEM.decode(pem_str, passphrase=None)
        algo_oid, private_key, params = PKCS8.unwrap(der_encoded, passphrase=None)
        # We accept id-ecPublicKey, id-ecDH, id-ecMQV without making any
        # distiction for now.
        unrestricted_oid = "1.2.840.10045.2.1"
        ecdh_oid = "1.3.132.1.12"
        ecmqv_oid = "1.3.132.1.13"
        if algo_oid not in (unrestricted_oid, ecdh_oid, ecmqv_oid):
            raise RuntimeError("Unsupported ECC purpose (OID: %s)" % algo_oid)
        log.info("algo_oid: ", algo_oid)
        curve_oid = DerObjectId().decode(params).value
        log.info("curve_oid: ", curve_oid)
        # PKCS8 转 ECC private key
        # ECPrivateKey ::= SEQUENCE {
        #           version        INTEGER { ecPrivkeyVer1(1) } (ecPrivkeyVer1),
        #           privateKey     OCTET STRING,
        #           parameters [0] ECParameters {{ NamedCurve }} OPTIONAL,
        #           publicKey  [1] BIT STRING OPTIONAL
        #    }
        ecc_private_key = DerSequence().decode(private_key, nr_elements=[3, 4])  # noqa
        if ecc_private_key[0] != 1:
            raise ValueError("Incorrect ECC private key version")
        try:
            # TODO: parameters和publicKey解析
            parameters = DerObjectId(explicit=0).decode(ecc_private_key[2]).value
            curve_oid = parameters
        except ValueError:
            pass

        if curve_oid is None:
            raise ValueError("No curve found")

        scalar_bytes = DerOctetString().decode(ecc_private_key[1]).payload
        d = Integer.from_bytes(scalar_bytes)
        hex_private_key = scalar_bytes.hex()
        log.info("hex_private_key:", hex_private_key)
        return hex_private_key

    @staticmethod
    @keyword
    def sm2_pub_pem_to_hex(pem_str: str) -> str:
        """SM2公钥pem字符串转hex字符串

        - pem_str: SM2公钥pem格式
        - return: hex格式
        """
        # PEM 转 PKCS8
        der_encoded, marker, enc_flag = PEM.decode(pem_str, passphrase=None)
        oid, ec_point, params = _expand_subject_public_key_info(der_encoded)
        unrestricted_oid = "1.2.840.10045.2.1"
        ecdh_oid = "1.3.132.1.12"
        ecmqv_oid = "1.3.132.1.13"

        if oid not in (unrestricted_oid, ecdh_oid, ecmqv_oid):
            raise RuntimeError("Unsupported ECC purpose (OID: %s)" % oid)
        log.info("oid:", oid)

        # Parameters are mandatory for all three types
        if not params:
            raise ValueError("Missing ECC parameters")

        # ECParameters ::= CHOICE {
        #   namedCurve         OBJECT IDENTIFIER
        #   -- implicitCurve   NULL
        #   -- specifiedCurve  SpecifiedECDomain
        # }
        #
        # implicitCurve and specifiedCurve are not supported (as per RFC)
        curve_oid = DerObjectId().decode(params).value
        log.info("curve_oid:", curve_oid)

        # The first byte is:
        # - 0x02:   compressed, only X-coordinate, Y-coordinate is even
        # - 0x03:   compressed, only X-coordinate, Y-coordinate is odd
        # - 0x04:   uncompressed, X-coordinate is followed by Y-coordinate
        #
        # PAI is in theory encoded as 0x00.

        # modulus_bytes = curve.p.size_in_bytes()
        modulus_bytes = 32
        point_type = bord(ec_point[0])

        # Uncompressed point
        if point_type == 0x04:
            x = ec_point[1 : modulus_bytes + 1].hex()
            y = ec_point[modulus_bytes + 1 :].hex()
            log.info("hex_public_key:", x + y)
            return x + y
        # Compressed point
        elif point_type in (0x02, 0x3):
            raise RuntimeWarning("Unsupport EC point encoding")
        else:
            raise ValueError("Incorrect EC point encoding")

    @staticmethod
    @keyword
    def sm2_pri_hex_to_pem(hex_str: str) -> str:
        """SM2私钥hex字符串转pem字符串

        - hex_str: SM2私钥的hex格式
        - return: pem格式
        """
        scalar_bytes = bytes.fromhex(hex_str)
        d_der = DerOctetString(scalar_bytes)
        ecc_private_key_version = DerInteger(1)
        # TODO: parameters和publicKey目前未组到ec_private_key中
        ec_private_key = DerSequence([ecc_private_key_version, d_der])
        curve_oid = DerObjectId("1.2.156.10197.1.301")
        algo_oid = "1.2.840.10045.2.1"
        der_encoded = PKCS8.wrap(ec_private_key.encode(), algo_oid, key_params=curve_oid)
        pem_str = PEM.encode(der_encoded, "EC PRIVATE KEY")
        log.info(pem_str)
        return pem_str

    @staticmethod
    @keyword
    def sm2_pub_hex_to_pem(hex_str: str) -> str:
        """SM2公钥hex字符串转pem字符串

        - hex_str: SM2公钥hex格式
        - return: SM2公钥的pem格式
        """
        hex_str = hex_str[-128:] if len(hex_str) > 128 else hex_str.rjust(128, "0")
        un_compressed_point = b"\x04" + binascii.unhexlify(hex_str[-128:])
        curve_oid = DerObjectId("1.2.156.10197.1.301")
        algo_oid = "1.2.840.10045.2.1"
        der_encoded = _create_subject_public_key_info(algo_oid, un_compressed_point, curve_oid)
        pem_str = PEM.encode(der_encoded, "PUBLIC KEY")
        log.info(pem_str)
        return pem_str

    @staticmethod
    @keyword
    def sm4_ecb_encrypt(text: str, key: str, b64_content: bool = False, b64_encrypt: bool = False) -> str:
        """SM4/ECB/PKCS5Padding加密算法

        - text: 待加密明文
        - key: SM4对称加密密钥, hexstr 或者base64str
        - b64: 可选, 加密结果是否需要base64编码, 默认为False
        - return: 加密后的密文
        """
        data = text.encode("utf-8")
        if b64_content:
            key_bytes = base64.b64decode(key)
        else:
            key_bytes = binascii.unhexlify(key)
        assert len(key_bytes) == 16, "SM4 Key长度不对，请检查"
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key_bytes, SM4_ENCRYPT)
        encrypt = crypt_sm4.crypt_ecb(data)
        return base64.b64encode(encrypt).decode("utf-8") if b64_encrypt else binascii.hexlify(encrypt).decode("utf-8")

    @staticmethod
    @keyword
    def sm4_ecb_decrypt(content: str, key: str, b64: bool = False):
        """SM4/ECB/PKCS5Padding解密算法

        - content: 密文
        - key: SM4对称加密密钥
        - b64: 传入的密文是否为base64编码, 默认为False
        - return: 解密后的明文
        """
        if b64:
            data = base64.b64decode(content.encode("utf-8"))
            key_bytes = base64.b64decode(key)
            # key_bytes = key.encode("utf-8")
        else:
            data = binascii.unhexlify(content.encode("utf-8"))
            key_bytes = binascii.unhexlify(key)
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key_bytes, SM4_DECRYPT)
        decrypt = crypt_sm4.crypt_ecb(data)
        return decrypt.decode("utf-8")

    
    @staticmethod
    @keyword
    def sm4_ecb_decrypt_merch(content: str, key: str, b64: bool = False):
        """SM4/ECB/PKCS5Padding解密算法

        - content: 密文
        - key: SM4对称加密密钥
        - b64: 传入的密文是否为base64编码, 默认为False
        - return: 解密后的明文
        """
        if b64:
            data = base64.b64decode(content.encode("utf-8"))
            key_bytes = key.encode("utf-8")
        else:
            data = binascii.unhexlify(content.encode("utf-8"))
            key_bytes = binascii.unhexlify(key)
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key_bytes, SM4_DECRYPT)
        decrypt = crypt_sm4.crypt_ecb(data)
        return decrypt.decode("utf-8")

    @staticmethod
    def _sm4_ecb_decrypt(data_bytes: bytes, key_bytes: bytes):
        """SM4/ECB/PKCS5Padding解密算法"""
        crypt_sm4 = CryptSM4()
        crypt_sm4.set_key(key_bytes, SM4_DECRYPT)
        decrypt = crypt_sm4.crypt_ecb(data_bytes)
        return decrypt.decode("utf-8")

    @staticmethod
    @keyword
    def md5(data: Union[str, bytes]) -> str:
        """数据转换为md5格式的十六进制字符串摘要

        - data: 需要转换的数据
        """
        if isinstance(data, str):
            data = data.encode("utf8")
        m = hashlib.md5()
        m.update(data)
        return m.hexdigest()

    @staticmethod
    @keyword
    def b64_encode(data: str) -> str:
        """base64加密

        - data: 需要转换的数据
        """
        data_bytes = data.encode("utf-8")
        return base64.b64encode(data_bytes).decode("utf-8")

    @staticmethod
    @keyword
    def b64_decode(data: str, encoding: str = "utf-8") -> str:
        """base64解密

        - data: 需要转换的数据
        - encoding: 默认解码为utf-8编码字符串，需要其他编码时传入
        """
        return base64.b64decode(data).decode(encoding)

    @staticmethod
    @keyword
    def generate_sm4_key(b64=False) -> str:
        """生成sm4对称加密密钥

        :param b64: _description_, defaults to False
        :return: 默认返回hex格式字符串
        """
        key_bytes = secrets.token_bytes(16)
        if b64:
            result = base64.b64encode(key_bytes).decode('utf-8')
        else:
            result = key_bytes.hex()
        log.info(f'生成SM4密钥: {result}')
        return result

    @staticmethod
    def print_bytes(data: bytes) -> None:
        """打印数据，同java中的byte[]的toString方法

        - data:
        """
        lst = []
        for c in data:
            if c > 127:
                c = c - 256
            lst.append(c)
        log.info("[" + ", ".join([str(i) for i in lst]) + "]")


class AesKeyUtils:
    """AES 加密key变换"""

    SINGLE_MODE = 0
    DOUBLE_MODE = 1
    x = binascii.unhexlify(
        "a0b22de90fc937cbf2e548c7b1f744610349a7386b23d44362dea98056b67d500122ca9386992ff6e19fc01f8a215ebef816f5ea1b76095a6425d5fb699179df83c52b7b466dba6a4155957a68ce29e3c671879e07cd9bfd4f4596d3e720fe9c2a59ff589aaf7ff98e246eb05cd08f8247aed953fa89321752da94734dbba83f8be61ea41177268d6692ad9808a68cb497a113883e1adbf331d8c460c1a3c3d6a2002ce09d3b78810ab90d3d0414ec1dccbc6c8410eef185b5304cef4e0502a5d142b34adc15edacc2fc0e1cf074064b3c12eb5f724019bd636f18d2bf5175b82e5d28277cabc8b7f4e20c57905433353ae436ddd75b65cfaae870390b67347e"
    )
    y = binascii.unhexlify(
        "e0da3e5b5011a925be3595c84eea6792c4eb0bc13fbc29fe8034581fb94c76634b8c41d442c0dedb1d5572fa1346cccfe2e308919cd7d0c7024f863bf7cea31a00fb65c5a874047326f28561cd6dee318a70a784d8143819563df47f0fc9375787ae7e8183ffe1690375d2d38d3af971a57a391c97e718595daa98e5b11047489d20ef7c0db7d5a4064360e93699b0f5c2ddabf12f7b1e8ff8f378155a30b645fd219694ad405c1b24a02b126c329fbd93a12e62510eed9b2abf6b526f4a332368b35316ba4db8afd1bb5e64b507b2c349285f2de66eac8b8e9e776a897d0a05a2e4272c82c6e8fcdcd944cbca9aecb49001dff03c172266a688d60cf6095479"
    )

    @staticmethod
    @keyword
    def convert(mode: int, key: bytes):
        """
        - mode: SINGLE_MODE: 0;DOUBLE_MODE: 1
        - key: bytes
        - return:
        """
        if not key:
            return None
        var0 = bytearray(len(key) * 2)

        for var2 in range(len(key)):
            var1 = (var2 % 16 << 4) | (key[var2] >> 4) & 0x0F
            var0[var2 * 2] = AesKeyUtils.x[var1]
            var1 = (var2 % 16 << 4) | (key[var2] & 0x0F)
            var0[var2 * 2 + 1] = AesKeyUtils.y[var1]

        if mode == AesKeyUtils.DOUBLE_MODE:
            return var0
        elif mode == AesKeyUtils.SINGLE_MODE:
            var3 = bytearray(len(key))
            for i in range(len(key)):
                var3[i] = var0[i] ^ var0[i + len(key)]
            return var3
        else:
            return None


class SM2Signer(CryptSM2):
    """SM2withSM3签名算法，对接Java"""

    def __init__(self, *args, asn1=True, **kwargs):
        public_key = kwargs.get("public_key")
        if not public_key:
            kwargs['public_key'] = "04"
        super().__init__(*args, **kwargs)
        self.asn1 = asn1

    def _get_pub_point(self):
        d = int(self.private_key, 16)
        return self._kg(d, self.ecc_table["g"])

    def _sm3_z(self, for_sign: bool, data, with_id: str = ""):
        """
        SM3WITHSM2 签名规则:  SM2.sign(SM3(Z+MSG)，PrivateKey)
        其中: z = Hash256(Len(ID) + ID + a + b + xG + yG + xA + yA)
        默认 0080 + 31323334353637383132333435363738
        """
        if for_sign:
            pub_point = self._get_pub_point()
        else:
            pub_point = self.public_key
        user_id = with_id.encode("utf-8").hex() if with_id else "31323334353637383132333435363738"
        length = len(user_id) * 4
        entl = bytearray([length >> 8 & 0xFF, length & 0xFF])
        # print(entl.hex(), user_id)
        z = entl.hex() + user_id + self.ecc_table["a"] + self.ecc_table["b"] + self.ecc_table["g"] + pub_point
        z = binascii.a2b_hex(z)
        Za = sm3_hash(func.bytes_to_list(z))
        # print('z', Za)
        M_ = (Za + data.hex()).encode("utf-8")
        E = sm3_hash(func.bytes_to_list(binascii.a2b_hex(M_)))
        return E

    def sign_with_sm3(self, data, random_hex_str=None, with_id=None):
        if isinstance(data, str):
            data = data.encode("utf-8")
        E = self._sm3_z(True, data, with_id)

        e = int(E, 16)
        d = int(self.private_key, 16)

        if random_hex_str is None:
            random_hex_str = secrets.token_hex(self.para_len // 2)
        k = int(random_hex_str, 16)

        P1 = self._kg(k, self.ecc_table["g"])

        x = int(P1[0 : self.para_len], 16)
        R = (e + x) % int(self.ecc_table["n"], base=16)
        if R == 0 or R + k == int(self.ecc_table["n"], base=16):
            return None
        d_1 = pow(d + 1, int(self.ecc_table["n"], base=16) - 2, int(self.ecc_table["n"], base=16))
        S = (d_1 * (k + R) - R) % int(self.ecc_table["n"], base=16)

        if S == 0:
            return None
        elif self.asn1:
            return DerSequence([DerInteger(R), DerInteger(S)]).encode()
        else:
            return "%064x%064x" % (R, S)

    def verify_with_sm3(self, sign, data, with_id):
        e_hash = self._sm3_z(False, data, with_id)
        if self.asn1:
            seq_der = DerSequence()
            r, s = seq_der.decode(sign)
        else:
            r = int(sign[0 : self.para_len], 16)
            s = int(sign[self.para_len : 2 * self.para_len], 16)
        e = int(e_hash, 16)
        t = (r + s) % int(self.ecc_table["n"], base=16)
        if t == 0:
            return 0

        P1 = self._kg(s, self.ecc_table["g"])
        P2 = self._kg(t, self.public_key)
        if P1 == P2:
            P1 = "%s%s" % (P1, 1)
            P1 = self._double_point(P1)
        else:
            P1 = "%s%s" % (P1, 1)
            P1 = self._add_point(P1, P2)
            P1 = self._convert_jacb_to_nor(P1)

        x = int(P1[0 : self.para_len], 16)
        return r == ((e + x) % int(self.ecc_table["n"], base=16))

    def encrypt(self, data):
        # 加密函数，data消息(bytes)
        msg = data.hex()  # 消息转化为16进制字符串
        k = func.random_hex(self.para_len)
        # PC||x1||y1，其中PC为单一字节且PC=04，仍记为C1
        C1 = "04" + self._kg(int(k, 16), self.ecc_table["g"])
        xy = self._kg(int(k, 16), self.public_key)
        x2 = xy[0 : self.para_len]
        y2 = xy[self.para_len : 2 * self.para_len]
        ml = len(msg)
        t = sm3_kdf(xy.encode("utf8"), ml / 2)
        if int(t, 16) == 0:
            return None
        else:
            form = "%%0%dx" % ml
            C2 = form % (int(msg, 16) ^ int(t, 16))
            C3 = sm3_hash([i for i in bytes.fromhex("%s%s%s" % (x2, msg, y2))])
            return bytes.fromhex("%s%s%s" % (C1, C3, C2))

    def decrypt(self, data):
        # 解密函数，data密文（bytes）
        data = data.hex()
        # PC||x1||y1，其中PC为单一字节且PC=04，这里java的密文包含04，所以长度需要+2才能把C1取到
        len_2 = 2 + 2 * self.para_len
        len_3 = len_2 + 64
        C1 = data[0:len_2]
        C3 = data[len_2:len_3]
        C2 = data[len_3:]
        if C1.startswith("04"):
            C1 = C1[2:]
        xy = self._kg(int(self.private_key, 16), C1)
        # print('xy = %s' % xy)
        x2 = xy[0 : self.para_len]
        y2 = xy[self.para_len : len_2]
        cl = len(C2)
        t = sm3_kdf(xy.encode("utf8"), cl / 2)
        if int(t, 16) == 0:
            return None
        else:
            form = "%%0%dx" % cl
            M = form % (int(C2, 16) ^ int(t, 16))
            u = sm3_hash([i for i in bytes.fromhex("%s%s%s" % (x2, M, y2))])
            return bytes.fromhex(M)
