# import serial
# from serial import SerialException
# from serial.tools import list_ports


# class SerialLibrary:
#     def __init__(self):
#         pass

#     def connect_serial(self):
#         """连接串口

#         - return: Comm串行通信端口的连接对象

#         """
#         for com in list_ports.comports(True):
#             name = com.name
#             desc = com.description
#             if desc.startswith("Prolific USB-to-Serial Comm Port"):
#                 print(desc)
#                 ser = serial.Serial(name, 115200, timeout=5)
#                 return ser
#             else:
#                 print("COM not found")


# if __name__ == "__main__":
#     s = SerialLibrary()
#     ser = s.connect()
#     if ser:
#         try:
#             ser.write("\r".encode("utf-8"))
#             print("***res***")
#             for i in range(5):
#                 a = ser.readline()
#                 print(a.decode("utf-8"))
#             print("***end***")
#         except SerialException as err:
#             print(err.message.split("'")[-2])
#         ser.close()
