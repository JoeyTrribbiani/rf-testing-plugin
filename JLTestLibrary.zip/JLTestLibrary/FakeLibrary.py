#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time : 2021/9/13 17:38
# @Author : Joey Xu
# @File : FakeLibrary.py
import faker
from faker import generator
from robot.api.deco import keyword

from . import log
from .fake import BankCard, social_credit_code
import random
import os

class FakeLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.faker = faker.Faker(locale="zh-CN")
        gen = generator
        self.bankcard = BankCard.LSProvider(gen)
        self.credit_code = social_credit_code.ScocialCreaditCodeProvider(gen)

    def test_ssn(self, min_age, max_age, gender):
        """
        - min_age:
        - max_age:
        - gender: F for female  M for male  None for default.
        - return: str.
        """
        new_ssn = self.faker.ssn(min_age, max_age, gender)
        return new_ssn

    def test_phone(self):
        new_phone = self.faker.phone_number()
        return new_phone

    def test_name(self):
        new_name = self.faker.name()
        return new_name

    def test_credit_card(self, credit_card_num, card_type="discover") -> list:
        """
        - credit_card_num: int. How many cards you want for once.
        - card_type: maestro,mastercard,visa16,visa13,visa19,amex,discover,diners,jcb15,jcb16
        - return: List. Random credit card list.
        """
        credit_cards = []
        for i in range(credit_card_num):
            credit_cards.append(self.bankcard.credit_card_number(card_type))
        return credit_cards

    def test_str(self, min_chars, max_chars):
        """
        :min_chars: int
        :max_chars: int
        - return: String.Random of random length between min and max characters.
        """

        rd_str = self.faker.pystr(min_chars, max_chars)
        return rd_str

    def test_text(self, max_nb_chars, ext_word_list):
        """
        :max_nb_chars :字数
        :ext_word_list: 参考文本
        - return:
        """
        if isinstance(ext_word_list, str):
            ext_word_list = ext_word_list.split(",")
        new_text = self.faker.text(max_nb_chars, ext_word_list)
        return new_text

    def test_ipv6(self, ip_num: int) -> list:
        """
        Generate fake IPv6 addresses.
        :param ip_num: Number of IPv6 addresses to generate.
        :return: List of fake IPv6 addresses.
        """
        rd_ipv6 = []
        for _ in range(ip_num):
            rd_ipv6.append(self.faker.ipv6())
        return rd_ipv6

    def test_ipv4(self, ip_num: int) -> list:
        """
        Generate fake IPv4 addresses.
        :param ip_num: Number of IPv4 addresses to generate.
        :return: List of fake IPv4 addresses.
        """
        rd_ipv4 = []
        for _ in range(ip_num):
            rd_ipv4.append(self.faker.ipv4())
        return rd_ipv4

    def test_address(self, encoding, file_path: str = None) -> str:
        """
        生成随机地址
        :param encoding: 文件编码
        :param file_path: 地址模板文件路径
        :return: 生成的地址
        """
        # 如果没有提供文件路径，使用默认的相对路径
        if file_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(current_dir, "fake", "address.txt")

        cities_map = {}
        provinces = [
        '黑龙江省',
        '青海省',
        '陕西省',
        '重庆',
        '辽宁省',
        '贵州省',
        '西藏自治区',
        '福建省',
        '甘肃省',
        '湖南省',
        '湖北省',
        '海南省',
        '浙江省',
        '河南省',
        '河北省',
        '江西省',
        '江苏省',
        '新疆维吾尔自治区',
        '广西壮族自治区',
        '广东省',
        '山西省',
        '山东省',
        '安徽省',
        '宁夏回族自治区',
        '天津',
        '四川省',
        '吉林省',
        '北京',
        '内蒙古自治区',
        '云南省',
        '上海']

        if encoding is None:
            encoding = "utf-8"
        # 增加encoding缓存,如果有缓存不进行重复读取
        if encoding not in cities_map:
            try:  
                with open(file_path, mode="r", encoding=encoding) as f:
                    cities_map[encoding] = {}
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        parts = line.split("\t")
                        if len(parts) == 2:
                            province, cities = parts
                            cities_map[encoding][province] = cities.split(",")
            except FileNotFoundError:
                print(f"文件未找到: {file_path}")
                return
            except Exception as e:
                print(f"读取文件错误: {e}")
                return

        if encoding in cities_map and provinces:
            province_key = random.choice(provinces)
            if province_key in cities_map[encoding]:
                cities = cities_map[encoding][province_key]
                city = random.choice(cities)
                return f"{province_key}{city}"
  
        # 如果省份不在映射中或没有省份数据，返回None或抛出异常
        return None # 或者你可以选择抛出一个更具体的异常

    @keyword
    def fake_setup(self, data_type, **kwargs):
        """
        - data_type: 生成数据的类型
        - credit_card_num: 银行卡 数量
        - return:
        """
        card_type = str(kwargs.get("card_type", "ccb_debit16")) if data_type == "bank_card" else None
        credit_card_num = int(kwargs.get("credit_card_num", 1)) if data_type == "bank_card" else None
        ssn_min_age = int(kwargs.get("ssn_min_age", 18)) if data_type == "ssn" else None
        ssn_max_age = int(kwargs.get("ssn_max_age", 65)) if data_type == "ssn" else None
        ssn_gender = kwargs.get("ssn_gender") if data_type == "ssn" else None
        str_min_chars = int(kwargs.get("str_min_chars", 20)) if data_type == "str" else None
        str_max_chars = int(kwargs.get("str_max_chars", 20)) if data_type == "str" else None
        text_max_chars = int(kwargs.get("text_max_chars", 70)) if data_type == "text" else None
        text_templete_list = kwargs.get("text_templete_list") if data_type == "text" else None
        address_encoding = kwargs.get("encoding") if data_type == "address" else None
        address_num = int(kwargs.get("num", 1)) if data_type == "address" else None
        ip_num = int(kwargs.get("ip_num", 1)) if data_type in ["ipv4", "ipv6"] else None
        data = None
        if data_type == "ssn":
            data = self.test_ssn(min_age=ssn_min_age, max_age=ssn_max_age, gender=ssn_gender)
        elif data_type == "name":
            data = self.test_name()
        elif data_type == "str":
            data = self.test_str(min_chars=str_min_chars, max_chars=str_max_chars)
        elif data_type == "text":
            data = self.test_text(max_nb_chars=text_max_chars, ext_word_list=text_templete_list)
        elif data_type == "bank_card":
            data = self.test_credit_card(card_type=card_type, credit_card_num=credit_card_num)
        elif data_type == "tel":
            data = self.test_phone()
        elif data_type == "address":
            return [self.test_address(encoding=address_encoding) for _ in range(address_num)]
        elif data_type == "ipv4":
            return self.test_ipv4(ip_num=ip_num)
        elif data_type == "ipv6":
            return self.test_ipv6(ip_num=ip_num)
        return data

    @keyword
    def fake_credit_code(self):
        """
        统一社会信用代码/营业执照注册号
        """
        return self.credit_code.gen_random_credit_code()

    @keyword
    def fake_idcard(self):
        """
        随机身份证号

        默认18-90岁, 性别任意
        """
        return self.faker.ssn()
