from pyasn1.type import namedtype, univ


class PriSequence(univ.Sequence):
    componentType = namedtype.NamedTypes(
        namedtype.NamedType("dataId", univ.ObjectIdentifier()),
        namedtype.NamedType("OID", univ.ObjectIdentifier()),
        namedtype.NamedType("key", univ.OctetString()),
    )


class PubSequence(univ.Sequence):
    componentType = namedtype.NamedTypes(
        namedtype.NamedType("dataId", univ.ObjectIdentifier()), namedtype.NamedType("key", univ.OctetString())
    )


class SM2Sequence(univ.Sequence):
    componentType = namedtype.NamedTypes(
        namedtype.NamedType("id", univ.Integer()),
        namedtype.NamedType("privateInfo", PriSequence()),
        namedtype.NamedType("publicInfo", PubSequence()),
    )
