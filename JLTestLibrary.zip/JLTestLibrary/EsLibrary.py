import calendar
import datetime
import math
import random
import time
import traceback
from itertools import product
from typing import List, Set, Union

import elasticsearch
from elasticsearch import VERSION, Elasticsearch
from robot.api.deco import keyword

from . import log
from .base_data.merch_trade_bill import BusiSubType, FeeCalcType, Status
from .DBLibrary import DBLibrary
from .UtilsLibrary import UtilsLibrary
from .UtilsMsg import UtilsMsg

utils = UtilsLibrary


class EsLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword
    def es_init_host(self, host: str = "http://172.20.20.184:9200,http://172.20.20.183:9200,http://172.20.11.23:9200"):
        """

        - host: 默认为http://172.20.20.184:9200,http://172.20.20.183:9200,http://172.20.11.23:9200

        | es_init_host | # 默认为http://172.20.20.184:9200,http://172.20.20.183:9200,http://172.20.11.23:9200 |
        | es_init_host | xxx.xxx.xxx.xxx |
        """
        self.es_client = Elasticsearch(hosts=host.split(","), timeout=3600)  # 超时时间

    @keyword
    def es_select_data(self, index, doc_type, query):
        value = self.es_client.search(index=index, doc_type=doc_type, body=query)
        return value

    @keyword
    def es_insert_data(
        self,
        table_name: str,
        doc_type: str,
        data: Union[str, dict],
        row_key: str = "",
        update_data: Union[str, dict] = {},
    ):
        """
        - table_name: 表名
        - doc_type:
        - data: 插入的数据
        - row_key: 主键
        - update_data: 更新数据
        - return: 插入后的返回码
        """
        if not row_key:
            row_key = "%s%s" % (str(time.strftime("%Y%m%d%H%M%S")), str(random.randint(1, 10)))
        insert_data = UtilsMsg.str_to_dict(data)
        if update_data:
            update_data = UtilsMsg.str_to_dict(update_data)
            insert_data.update(update_data)
        log.info(f"插入数据内容：{insert_data}")
        index = table_name.lower()
        ret = self.es_client.index(index=index, id=row_key, body=insert_data, doc_type=doc_type)
        log.info(f"返回结果：{ret}")
        return ret

    @keyword
    def transfer_data_from_oracle_to_es(
        self, oracle_url: str, merch_no: str, trans_date: str, delete_history: bool = False
    ):
        """将oracle数据库中的数据大批量自动转移到es数据库，数据源映射xdata-dw-qrt

        - oracle_url: oracle数据库的连接地址，如 accp_user/123456@172.20.34.10:1521/posplu
        - merch_no: 要完成大批量数据转移的商户号，如 AG0800050267783
        - trans_date: 该商户号的交易年月日，如 2022-07-14
        - delete_history: 默认为False，为True时删除脚本之前插入的数据
        """

        db = None
        try:
            date = datetime.datetime.strptime(trans_date, "%Y-%m-%d")  # 通过传入的交易年月，获得要插入数据库的表的表名
            postfix = "%04d%02d" % (date.year, date.month)
            index = "t_full_trade_bill_" + postfix

            db = DBLibrary()  # 构建和oracle数据库的链接
            db.connect_to_database("cx_Oracle", oracle_url)

            select_from_t_ofl_l_trans_list_sql = """
                select to_char(CREATE_TIME,'yyyy-mm-dd') ACCOUNTING_DATE,
                    ACCOUNT_FLAG,
                    AGENT_ID AGT_ID,
                    AMOUNT AMT,
                    BUSI_SUB_TYPE,
                    BUSI_TYPE,
                    CARD_NO,
                    CHANNEL_NO CHN_NO,
                    DISCOUNT_AMOUNT DISCOUNT_AMT,
                    FEE_AMOUNT FEE_AMT,
                    FEE_CALC_TYPE,
                    IS_INTERNAL_CARD INTERNAL_FLAG,
                    LMERCH_NAME LMER_NAME,
                    LMERCH_NO LMER_NO,
                    LREFER_NO,
                    LTERM_NO,
                    LVOUCH_NO,
                    ORDER_ID,
                    ORI_AMOUNT ORI_AMT,
                    ORI_ORDER_ID,
                    PRINT_MERCH_NAME PMER_NAME,
                    QR_PAY_CODE,
                    STATUS,
                    TERM_SN,
                    TRANS_TIME,
                    UPDATE_TIME,
                    USER_ORDER_ID
                    from T_OFL_L_TRANS_LIST
                    where LMERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )  # SQL语句，选出同年同月同日的所有数据

            select_from_t_qr_pay_order_sql = """
                select to_char(CREATE_TIME, 'yyyy-mm-dd') ACCOUNTING_DATE,
                    AMOUNT AMT,
                    APP_ID APPID,
                    BUSI_SUB_TYPE,
                    BUSI_TYPE,
                    DISCOUNT_AMOUNT DISCOUNT_AMT,
                    MERCH_NO LMER_NO,
                    TERM_NO LTERM_NO,
                    ORDER_ID,
                    ORI_ORDER_ID,
                    STATUS,
                    TRANS_TIME,
                    UPDATE_TIME
                    from T_QR_PAY_ORDER
                    where MERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )

            select_from_t_guarantee_trans_list_sql = """
                select to_char(CREATE_TIME, 'yyyy-mm-dd') ACCOUNTING_DATE,
                    AMOUNT AMT,
                    BUSI_SUB_TYPE,
                    BUSI_TYPE,
                    CHANNEL_NO CHN_NO,
                    FEE_AMOUNT FEE_AMT,
                    MERCH_NAME LMER_NAME,
                    MERCH_NO LMER_NO,
                    ORDER_ID,
                    ORI_AMOUNT ORI_AMT,
                    ORI_ORDER_ID,
                    SOURCE,
                    STATUS,
                    TERM_SN,
                    TRANS_TIME,
                    UPDATE_TIME
                    from T_GUARANTEE_TRANS_LIST
                    where MERCH_NO='%s' and to_char(CREATE_TIME,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )

            data_t_ofl_l_trans_list = db.query_to_dict(select_from_t_ofl_l_trans_list_sql, upper=True)
            data_t_qr_pay_order = db.query_to_dict(select_from_t_qr_pay_order_sql, upper=True)
            data_t_guarantee_trans_list = db.query_to_dict(select_from_t_guarantee_trans_list_sql, upper=True)

            total_list = []
            total_list.extend(data_t_ofl_l_trans_list)
            total_list.extend(data_t_qr_pay_order)
            total_list.extend(data_t_guarantee_trans_list)
            doc_type = "xdata"
            mapping_keys = self._es_get_mappings(index)
            if delete_history:
                self.es_delete_history(
                    index,
                    doc_type,
                    {
                        "bool": {
                            "filter": {"term": {"LMER_NO": merch_no}},
                            "must": {
                                "range": {
                                    "TRANS_TIME": {"gte": str(date), "lte": str(date + datetime.timedelta(days=1))}
                                }
                            },
                        }
                    },
                )
            index_bodys: List = []
            for row in total_list:
                data = {k: str(v) for k, v in row.items() if k in mapping_keys and v}
                index_bodys.append({"index": {"_id": data["ORDER_ID"][::-1] + "_" + data["LMER_NO"]}})
                index_bodys.append(data)
            ret = self.es_client.bulk(body=index_bodys, index=index, doc_type=doc_type)
            log.info(f"插入结果：{ret}")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"从oracle数据库转移账单数据到es数据库失败！: {str(e)}")
        finally:
            if db is not None:
                db.connect_close()

    @keyword
    def transfer_data_from_oracle_to_es_merch(
        self, oracle_url: str, merch_no: str, trans_date: str, delete_history: bool = False
    ):
        """将oracle数据库中的数据大批量自动转移到es数据库，数据源映射xdata-realtime-etl/src/main/resources/mapper.xml

        - oracle_url: oracle数据库的连接地址，如 accp_user/123456@172.20.34.10:1521/posplu
        - merch_no: 要完成大批量数据转移的商户号，如 AG0800050267783
        - trans_date: 该商户号的交易年月日，如 2022-07-14
        - delete_history: 默认为False，为True时删除脚本之前插入的数据
        """

        db = None
        try:
            date = datetime.datetime.strptime(trans_date, "%Y-%m-%d")  # 通过传入的交易年月，获得要插入数据库的表的表名
            postfix = "%04d%02d" % (date.year, date.month)
            index = "t_mer_trans_list_" + postfix

            db = DBLibrary()  # 构建和oracle数据库的链接
            db.connect_to_database("cx_Oracle", oracle_url)

            select_from_t_ofl_l_trans_list_sql = """
                select order_id,
                    ori_order_id,
                    busi_type,
                    busi_sub_type,
                    fee_amount mer_fee,
                    busi_sub_type trade_type,
                    card_no,
                    amount amt,
                    term_sn,
                    lmerch_no lmer_no,
                    lmerch_name lmer_name,
                    print_merch_no pmer_no,
                    print_merch_name pmer_name,
                    lterm_no,
                    term_device_serial_no dev_no,
                    lbatch_no,
                    lvouch_no,
                    lrefer_no,
                    auth_code auth_no,
                    pos_entry_mode entry_mode,
                    ori_lbatch_no,
                    ori_lvouch_no,
                    ori_lrefer_no,
                    chn_order_id,
                    card_type,
                    card_name,
                    ccy_code,
                    card_flag,
                    pwd_sign_free_flag pwdfree,
                    is_internal_card internal_flag,
                    area_code,
                    standard_route std_route,
                    channel_no chn_no,
                    trans_time,
                    trans_time sett_date,
                    status,
                    ret_code,
                    ret_msg,
                    fee_amount fee_amt,
                    bank_code,
                    qr_channel_id qr_chn_id,
                    agent_id,
                    exter_card_flag ex_card_flag,
                    flush_flag,
                    confirm_flag,
                    card_organization card_org,
                    billing_amount dcc_amt,
                    billing_ccycode,
                    conversion_rate dcc_rate,
                    term_device_type ldev_type,
                    term_app_version term_version,
                    ori_amount ori_amt,
                    user_order_id,
                    create_time c_time,
                    update_time u_time,
                    batchup_flag,
                    batchup_flag batchup_update_time,
                    stock_flag,
                    qr_pay_code,
                    fee_calc_type,
                    position_info,
                    acq_code,
                    discount_amount discount_amt,
                    exter_discount_amount ex_discount_amt,
                    finnal_amount real_amt,
                    discount_settle_type discount_sett_type,
                    remark,
                    update_time
                    from trans_user.t_ofl_l_trans_list
                    where lmerch_no='%s' and to_char(create_time,'yyyy-mm-dd')='%s'
            """ % (
                merch_no,
                trans_date,
            )  # SQL语句，选出同年同月同日的所有数据

            select_from_t_qr_pay_order_sql = """
                select order_id,
                    ori_order_id,
                    busi_type,
                    busi_sub_type,
                    trans_type trade_type,
                    amount amt,
                    amount ramt,
                    merch_no lmer_no,
                    term_no lterm_no,
                    refer_no lrefer_no,
                    auth_code qr_pay_code,
                    channel_order_id chn_order_id,
                    channel_id chn_no,
                    trans_time,
                    settle_date sett_date,
                    ret_code,
                    ret_msg,
                    channel_id qr_chn_id,
                    channel_merch_id rmer_no,
                    term_no rterm_no,
                    chn_trans_time transmsn_time,
                    refer_no rrefer_no,
                    status rstatus,
                    discount_amount discount_amt,
                    create_time c_time,
                    update_time u_time,
                    pay_info,
                    settle_key,
                    area_info,
                    channel_agent chn_code,
                    trans_time rtrans_time,
                    sub_openid openid,
                    sub_appid appid
                    from trans_user.t_qr_pay_order
                    where merch_no='%s' and to_char(update_time,'yyyy-mm-dd')='%s'
                        """ % (
                merch_no,
                trans_date,
            )

            select_from_t_guarantee_trans_list_sql = """
                select order_id,
                    busi_type,
                    busi_sub_type,
                    amount amt,
                    merch_no lmer_no,
                    merch_name lmer_name,
                    term_no lterm_no,
                    term_sn,
                    trans_time,
                    subject,
                    status,
                    ret_code,
                    ret_msg,
                    remark,
                    trans_ip,
                    trans_area_code area_code,
                    position_info,
                    qrcode qr_pay_code,
                    update_time,
                    auth_code auth_no,
                    channel_no chn_no,
                    trans_type trade_type,
                    chn_order_id,
                    sub_open_id openid,
                    fee_amount fee_amt,
                    fee_amount mer_fee
                    from trans_user.t_guarantee_trans_list
                    where merch_no='%s' and to_char(update_time,'yyyy-mm-dd')='%s'
                        """ % (
                merch_no,
                trans_date,
            )

            data_t_ofl_l_trans_list = db.query_to_dict(select_from_t_ofl_l_trans_list_sql, upper=True)
            data_t_qr_pay_order = db.query_to_dict(select_from_t_qr_pay_order_sql, upper=True)
            data_t_guarantee_trans_list = db.query_to_dict(select_from_t_guarantee_trans_list_sql, upper=True)

            total_list = []
            total_list.extend(data_t_ofl_l_trans_list)
            total_list.extend(data_t_qr_pay_order)
            total_list.extend(data_t_guarantee_trans_list)
            doc_type = "merch"
            mapping_keys = self._es_get_mappings(index)
            if delete_history:
                self.es_delete_history(
                    index,
                    doc_type,
                    {
                        "bool": {
                            "filter": {"term": {"LMER_NO": merch_no}},
                            "must": {
                                "range": {
                                    "TRANS_TIME": {"gte": str(date), "lte": str(date + datetime.timedelta(days=1))}
                                }
                            },
                        }
                    },
                )
            index_bodys: List = []
            for row in total_list:
                data = {k: str(v) for k, v in row.items() if k in mapping_keys and v}
                index_bodys.append({"index": {"_id": data["ORDER_ID"][::-1] + "_" + data["LMER_NO"]}})
                index_bodys.append(data)
            ret = self.es_client.bulk(body=index_bodys, index=index, doc_type=doc_type)
            log.info(f"插入结果：{ret}")

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"从oracle数据库转移账单数据到es_merch失败！: {str(e)}")
        finally:
            if db is not None:
                db.connect_close()

    @keyword
    def mock_data_to_es_merch(
        self,
        lmer_no: str = "84944035812A00G",
        lterm_no: str = "12341234",
        trans_date: str = "2022-09-30",
        delete_history: bool = False,
    ):
        date = datetime.datetime.strptime(trans_date, "%Y-%m-%d")  # 通过传入的交易年月，获得要插入数据库的表的表名
        postfix = "%04d%02d" % (date.year, date.month)
        index = "t_mer_trans_list_" + postfix
        mapping_keys = self._es_get_mappings(index)
        doc_type = "merch"
        if delete_history:
            self.es_delete_history(
                index,
                doc_type,
                {
                    "bool": {
                        "filter": {"term": {"LMER_NO": lmer_no}},
                        "must": {
                            "range": {"TRANS_TIME": {"gte": str(date), "lte": str(date + datetime.timedelta(days=1))}}
                        },
                    }
                },
            )
        mock_datas = []
        trade_statuses = [status.value for status in Status]
        fee_calc_types = [fee_calc_type.value for fee_calc_type in FeeCalcType]
        forward_list: List[str] = []
        forward_list.extend(BusiSubType.SALE)
        forward_list.extend(BusiSubType.VSALE)
        forward_list.extend(BusiSubType.AUTH)
        forward_list.extend(BusiSubType.VAUTH)
        forward_list.extend(BusiSubType.CAUTH)
        forward_list.extend(BusiSubType.VCAUTH)
        forward_list.extend(BusiSubType.RCAUTH)
        forward_list.extend(BusiSubType.REFUND)

        for hour in range(24):
            date = date.replace(hour=hour)
            i = 0
            for status, fee_calc_type, busi_sub_type in product(trade_statuses, fee_calc_types, forward_list):
                i += 1
                date = date.replace(second=1)
                ts = int(date.timestamp() * 1000) + i
                base_temp = {
                    "ORDER_ID": f"{lterm_no}{busi_sub_type}{ts}",
                    # "ORI_ORDER_ID": "",
                    "BUSI_TYPE": "1001",
                    "BUSI_SUB_TYPE": busi_sub_type,
                    "AMT": "1000",
                    "FEE_AMT": "5",
                    "FEE_CALC_TYPE": fee_calc_type,
                    "LMER_NO": lmer_no,
                    "LTERM_NO": lterm_no,
                    "TRANS_TIME": str(date),
                    "RET_CODE": "00",
                    "RET_MSG": "成功",
                    "U_TIME": str(date),
                    "STATUS": status,
                }
                data = {k: str(v) for k, v in base_temp.items() if k in mapping_keys and v}
                mock_datas.append(data)

        index_bodys: List = []
        for data in mock_datas:
            index_bodys.append({"index": {"_id": data["ORDER_ID"][::-1] + "_" + data["LMER_NO"]}})
            index_bodys.append(data)
        log.info(f"即将开始插入 {i} * 24 = {i * 24}条数据...")
        ret = self.es_client.bulk(body=index_bodys, index=index, doc_type=doc_type)
        log.info("插入结果：", {"took": ret.get("took"), "errors": ret.get("errors")})

    @keyword
    def mock_data_to_es_trade(
        self,
        lmer_no: str = "84931015812A00N",
        lterm_no: str = "60016260",
        start_trans_date: str = "2022-09-25",
        end_trans_date: str = "2022-09-26",
        delete_history: bool = False,
    ):
        """
        向es中批量插入交易账单相关数据
        - param lmer_no: 商户号
        - param lterm_no: 终端号
        - param start_trans_date: 开始交易日期
        - param start_trans_date: 结束交易日期
        - param delete_history: 插入前是否删除旧数据
        - return: 返回es中所插入的数据和ids
        """
        start_date = datetime.datetime.strptime(start_trans_date, "%Y-%m-%d")  # 通过传入的交易年月，获得要插入数据库的表的表名
        end_date = datetime.datetime.strptime(end_trans_date, "%Y-%m-%d")

        start_postfix = "%04d%02d" % (start_date.year, start_date.month)
        end_postfix = "%04d%02d" % (end_date.year, end_date.month)
        start_index = "t_mer_trans_list_" + start_postfix
        end_index = "t_mer_trans_list_" + end_postfix
        log.info("这是传入的交易日期", start_trans_date, end_trans_date)
        log.info("开始向es中插入数据...")
        es_index_list = [start_index, end_index]
        es_index_tuple = tuple(set(es_index_list))
        log.info("这是es插入的表名", es_index_tuple)
        doc_type = "merch"

        # 获取开始月的最后一天和获取结束月的第一天
        weekDay, monthCountDay = calendar.monthrange(start_date.year, start_date.month)

        # 获取当前月份最后一天
        lastDay = datetime.date(start_date.year, start_date.month, day=monthCountDay)
        lastDay = datetime.datetime.strptime(str(lastDay), "%Y-%m-%d")

        # 获取结束月份第一天
        firstDay = datetime.date(end_date.year, end_date.month, day=1)
        firstDay = datetime.datetime.strptime(str(firstDay), "%Y-%m-%d")

        delete_history_time_dict = dict()
        relation_dict = dict()
        if start_postfix == end_postfix:
            delete_history_time_dict[start_date] = end_date + datetime.timedelta(hours=23, minutes=59, seconds=59)
            relation_dict[start_date] = es_index_tuple[0]
        else:
            delete_history_time_dict[start_date] = lastDay + datetime.timedelta(hours=23, minutes=59, seconds=59)
            relation_dict[start_date] = es_index_tuple[0]
            delete_history_time_dict[firstDay] = end_date + datetime.timedelta(hours=23, minutes=59, seconds=59)
            relation_dict[firstDay] = es_index_tuple[1]
        if delete_history:
            for key in delete_history_time_dict:
                self.es_delete_history(
                    relation_dict[key],
                    doc_type,
                    {
                        "bool": {
                            "filter": {"term": {"LMER_NO": lmer_no}},
                            "must": {
                                "range": {"TRANS_TIME": {"gte": str(key), "lte": str(delete_history_time_dict[key])}}
                            },
                        }
                    },
                )

        insert_datas = dict()
        insert_ids = dict()
        for key in delete_history_time_dict:
            mapping_keys = self._es_get_mappings(relation_dict[key])
            mock_datas = []

            tmp_date = key
            date_count = 0
            while tmp_date <= delete_history_time_dict[key]:
                date_count = date_count + 1
                from .base_data.merch_trade_bill import (
                    trade_busi_sub_type,
                    trade_fee_calc_type,
                    trade_status,
                )

                trade_statuses = [status.value for status in trade_status]
                fee_calc_types = trade_fee_calc_type
                forward_list: List[str] = trade_busi_sub_type

                for hour in range(3):
                    tmp_date = tmp_date.replace(hour=hour)
                    i = 0
                    for status, fee_calc_type, busi_sub_type in product(trade_statuses, fee_calc_types, forward_list):
                        i += 1
                        tmp_date = tmp_date.replace(second=1)
                        ts = int(tmp_date.timestamp() * 1000) + i
                        base_temp = {
                            "ORDER_ID": f"411001{busi_sub_type}{ts}",
                            "BUSI_TYPE": "1001",
                            "BUSI_SUB_TYPE": busi_sub_type,
                            "AMT": "1000",
                            "FEE_AMT": "5",
                            "FEE_CALC_TYPE": fee_calc_type,
                            "LMER_NO": lmer_no,
                            "LTERM_NO": lterm_no,
                            "TRANS_TIME": str(tmp_date),
                            "RET_CODE": "00",
                            "RET_MSG": "成功",
                            "U_TIME": str(tmp_date),
                            "STATUS": status,
                        }
                        data = {k: str(v) for k, v in base_temp.items() if k in mapping_keys and v}
                        mock_datas.append(data)
                tmp_date = tmp_date + datetime.timedelta(days=1)
            insert_datas[relation_dict[key]] = mock_datas

            index_bodys: List = []
            id_list = []
            for data in insert_datas[relation_dict[key]]:
                index_bodys.append({"index": {"_id": data["ORDER_ID"][::-1] + "_" + data["LMER_NO"]}})
                id_list.append(data["ORDER_ID"][::-1] + "_" + data["LMER_NO"])
                index_bodys.append(data)
            insert_ids[relation_dict[key]] = id_list
            log.info(f"即将开始插入 {date_count}*{i} * 3 = {date_count* i * 3}条数据...")
            ret = self.es_client.bulk(body=index_bodys, index=relation_dict[key], doc_type=doc_type)
            log.info("插入结果：", {"took": ret.get("took"), "errors": ret.get("errors")})
        return insert_datas, insert_ids

    @keyword
    def _get_settle_quarter_list(self, start_settle_date: str, end_settle_date: str) -> Set[str]:
        """获取清结算季度
        如'2022-12-11', '2023-01-01'将返回['20224', '20231']
        如'2023-01-11', '2023-04-12'将返回['20231', '20232']
        """
        start_date = datetime.datetime.strptime(start_settle_date, "%Y-%m-%d")
        end_date = datetime.datetime.strptime(end_settle_date, "%Y-%m-%d")
        if start_date > end_date:
            raise ValueError("start_settle_date must be less than end_settle_date")

        date_list = []
        for year in range(start_date.year, end_date.year + 1):
            for month in range(1, 13):
                if year == start_date.year == end_date.year:
                    if month <= end_date.month:
                        date_list.append(datetime.date(year, month, 1))
                else:
                    if year == start_date.year:
                        if month >= start_date.month:
                            date_list.append(datetime.date(year, month, 1))
                    elif start_date.year < year < end_date.year:
                        date_list.append(datetime.date(year, month, 1))
                    else:
                        if month <= end_date.month:
                            date_list.append(datetime.date(year, month, 1))

        quarter_list = [f'{date.year}{math.ceil(date.month/ 3)}' for date in date_list]
        return set(quarter_list)

    @keyword
    def mock_data_to_es_fund(
        self,
        lmer_no: str = "84931015812A00N",
        start_trans_date: str = "2022-09-27",
        end_trans_date: str = "2022-09-28",
        delete_history: bool = False,
    ):
        """
        向es中批量插入资金账单相关数据
        - param lmer_no: 商户号
        - param start_trans_date: 开始日期
        - param end_trans_date: 结束日期
        - param delete_history: 插入前是否删除旧数据
        - return: 返回es中所插入的数据和ids
        """
        # 获取查询时间
        from JLTestLibrary import RequestLibrary

        request = RequestLibrary()
        # url = "http://172.20.20.82:35519/clearbill"
        url = "http://clear-settle-merch-bill-svc.manage:8080/clearbill"
        req_data = '{{"command_id":"query_clear_acc_date_new","end_busi_date":"{}","limit":999,"merch_no":"84931015812A00N","offset":0,"start_busi_date":"{}"}}'.format(
            end_trans_date, start_trans_date
        )

        resp = request.http_post_api(url, req_data=req_data)
        start_acc_date = resp["start_acc_date"]
        start_settle_date = resp["start_settle_date"]
        end_settle_date = resp["end_settle_date"]

        start_busi_date = resp["start_busi_date"]
        # 将其转换成datetime类型
        start_busi_date = datetime.datetime.strptime(start_busi_date, "%Y%m%d")
        end_busi_date = resp["end_busi_date"]
        # 将其转换成datetime类型
        end_busi_date = datetime.datetime.strptime(end_busi_date, "%Y%m%d")

        quarter_list = self._get_settle_quarter_list(start_settle_date, end_settle_date)
        es_index_list = []
        for quarter in quarter_list:
            es_index_list.append("t_clear_trans_list_" + quarter)

        log.info("这是获取到的start_settle_date与end_settle_date", start_settle_date, end_settle_date)
        log.info("开始向es中插入数据...")
        log.info("这是向es插入的表名", es_index_list)

        # 获取开始月的最后一天和获取结束月的第一天
        weekDay, monthCountDay = calendar.monthrange(start_busi_date.year, start_busi_date.month)

        # 获取当前月份最后一天
        lastDay = datetime.date(start_busi_date.year, start_busi_date.month, day=monthCountDay)
        lastDay = datetime.datetime.strptime(str(lastDay), "%Y-%m-%d")

        # 获取结束月份第一天
        firstDay = datetime.date(end_busi_date.year, end_busi_date.month, day=1)
        firstDay = datetime.datetime.strptime(str(firstDay), "%Y-%m-%d")

        delete_history_time_dict = dict()
        if start_busi_date.strftime("%Y%m") == end_busi_date.strftime("%Y%m"):
            delete_history_time_dict[start_busi_date] = end_busi_date + datetime.timedelta(
                hours=23, minutes=59, seconds=59
            )

        else:
            delete_history_time_dict[start_busi_date] = lastDay + datetime.timedelta(hours=23, minutes=59, seconds=59)

            delete_history_time_dict[firstDay] = end_busi_date + datetime.timedelta(hours=23, minutes=59, seconds=59)

        doc_type = "xdata"
        if delete_history:
            for i in range(len(es_index_list)):
                self.es_delete_history(
                    es_index_list[i],
                    doc_type,
                    {
                        "bool": {
                            "filter": {"term": {"MERCH_NO": lmer_no}},
                            "must": {
                                "range": {
                                    "BUSINESS_DATE": {
                                        "from": start_busi_date.strftime("%Y%m%d"),
                                        "to": end_busi_date.strftime("%Y%m%d"),
                                        "include_lower": "true",
                                        "include_upper": "true",
                                        "boost": 1,
                                    }
                                }
                            },
                        }
                    },
                )

        insert_datas = []
        insert_ids = []
        count = 0
        for key in delete_history_time_dict:
            tmp_date = key

            while tmp_date <= delete_history_time_dict[key]:
                count = count + 1
                es_index = count % len(es_index_list)

                mapping_keys = self._es_get_mappings(es_index_list[es_index])

                from .base_data.merch_trade_bill import (
                    fund_debit_credit_flag,
                    trade_busi_sub_type,
                )

                debit_credit_flag = fund_debit_credit_flag
                forward_list: List[str] = trade_busi_sub_type

                mock_datas = []
                id_list = []
                for hour in range(3):
                    tmp_date = tmp_date.replace(hour=hour)
                    i = 0
                    for credit_flag, busi_sub_type in product(debit_credit_flag, forward_list):
                        i += 1
                        tmp_date = tmp_date.replace(second=1)
                        ts = int(tmp_date.timestamp() * 1000) + i

                        amt = random.randint(1000, 1000000)
                        fee_amt = random.randint(1, 1000)
                        liquidation_amt = amt - fee_amt
                        base_temp = {
                            "ORDER_ID": f"411001{busi_sub_type}{ts}",
                            "BUSI_TYPE": "1001",
                            "BUSI_SUB_TYPE": busi_sub_type,
                            "AMT": str(amt),
                            "FEE_AMT": str(fee_amt),
                            "MERCH_NO": lmer_no,
                            "COLLECT_MERCH_NO": lmer_no,
                            "BUSINESS_DATE": tmp_date.strftime("%Y%m%d"),
                            "ACC_DATE": start_acc_date,
                            "LIQUIDATION_DATE": start_settle_date,
                            "MERCH_SHOW_MARK": "0",
                            "DEBIT_CREDIT_FLAG": credit_flag,
                            "LIQUIDATION_AMT": str(liquidation_amt),
                            "TRANS_TIME": tmp_date.strftime("%Y%m%d%H%M%S"),
                        }

                        data = {k: str(v) for k, v in base_temp.items() if k in mapping_keys and v}
                        mock_datas.append(data)

                index_bodys: List = []

                for data in mock_datas:
                    index_bodys.append({"index": {"_id": data["ORDER_ID"][::-1] + "_" + data["MERCH_NO"]}})
                    id_list.append(data["ORDER_ID"][::-1] + "_" + data["MERCH_NO"])
                    index_bodys.append(data)
                log.info(f"开始第{count}天插入,插入的日期是{tmp_date.strftime('%Y-%m-%d')},插入的es表名为{es_index_list[es_index]}")
                log.info(f"即将开始插入 {i} * 3 = {i * 3}条数据...")
                ret = self.es_client.bulk(body=index_bodys, index=es_index_list[es_index], doc_type=doc_type)
                log.info("插入结果：", {"took": ret.get("took"), "errors": ret.get("errors")})

                tmp_date = tmp_date + datetime.timedelta(days=1)
                insert_datas.extend(mock_datas)
                insert_ids.extend(id_list)
        return insert_datas, insert_ids

    def _es_get_mappings(self, index):
        if VERSION[0] <= 7:
            kwargs = {"params": {"include_type_name": "false"}}
        else:
            kwargs = {}
        ret = self.es_client.indices.get_mapping(index=index, **kwargs)
        # log.info(f"获取mappings定义: {ret}")
        first_mappings = list(ret.values())[0]["mappings"]["properties"]
        mapping_keys = first_mappings.keys()
        return mapping_keys

    @keyword
    def es_delete_history(self, index: str, doc_type: str, query_body: Union[str, dict]):
        """es 批量删除数据

        - index: 索引名称
        - doc_type: doc_type名称
        - querybody: 为查询条件，例如 {"bool": {filter": {"term": {"LMER_NO": "xxxx"}}}}
        """
        delete_bodys = []
        search_datas = self.es_search_datas(index, doc_type, query_body)
        log.info("index", index, "doc_type", doc_type, "query_body", query_body)
        delete_bodys.extend([{"delete": {"_index": index, "_id": item["_id"]}} for item in search_datas])
        if delete_bodys:
            log.info("开始批量删除...")
            ret = self.es_client.bulk(body=delete_bodys, index=index, doc_type=doc_type)

    @keyword
    def es_search_datas(self, index: str, doc_type: str, query_body: Union[str, dict]) -> List[dict]:
        """es搜索大量数据，目前为了加快搜索，只返回id和LMER_NO字段

        - index: _description_
        - doc_type: _description_
        - query_body: 查询条件query的值
        - return: 返回查询到的数据的列表
        """
        datas: List = []
        query_dict = UtilsMsg.str_to_dict(query_body)
        search_body: dict = {"from": 0, "size": 10000, "query": query_dict, "sort": [{"_id": "asc"}]}
        search_after: List = []
        hits = 0
        while True:
            if search_after:
                search_body.update({"search_after": search_after})

            try:
                ret = self.es_client.search(
                    index=index,
                    doc_type=doc_type,
                    body=search_body,
                    params={"_source": "MERCH_NO"},
                )
            except elasticsearch.exceptions.NotFoundError:
                log.warn(f"es索引[{index}]不存在，请检查索引名称是否正确")
                return datas
            total = ret["hits"]["total"]
            current_size = len(ret["hits"]["hits"])
            hits += current_size
            log.info(f"正在记录 {current_size}/{total} 条数据...")
            datas.extend([item for item in ret["hits"]["hits"]])
            if not datas:
                break
            search_after = [datas[-1]["_id"]]
            if hits >= total:
                break
        return datas
