import ftplib
import os
from ftplib import FTP
from io import BytesIO

from robot.api.deco import keyword

from . import log


class FtpLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self) -> None:
        self._ftp = FTP()

    @keyword
    def connect_to_ftp(self, ftp_host: str, ftp_port: int, username: str, password: str):
        """连接FTP

        - ftp_host: ftp_server的ip
        - ftp_port: ftp_server的端口
        - username: ftp连接的用户名
        - password: ftp连接的密码
        - raises RuntimeError: 连接异常时抛出
        """
        try:
            self._ftp.connect(ftp_host, ftp_port)
            self._ftp.login(username, password)
            log.info("FTP连接成功!")
        except Exception as e:
            raise RuntimeError(f"FTP连接异常! {e}")

    @keyword
    def close_to_ftp(self):
        """关闭FTP连接"""
        if self._ftp:
            self._ftp.quit()

    @keyword
    def download_file(self, remotepath: str, localpath: str = ""):
        """从FTP下载文件

        - remotepath: 本地存储路径
        - localpath: ftp存储路径 不传时默认下载当前目录
        """
        try:
            bufsize = 1024
            if localpath:
                if os.path.isdir(localpath):
                    localpath = os.path.join(localpath, os.path.basename(remotepath))
            else:
                localpath = os.path.basename(remotepath)
            fp = open(localpath, "wb")
            self._ftp.retrbinary("RETR " + remotepath, fp.write, bufsize)
            self._ftp.set_debuglevel(0)
            fp.close()
            log.info(remotepath, "文件下载成功！")
            log.info(localpath)
        except Exception as e:
            raise RuntimeError(f"下载文件失败! {e}")

    @keyword
    def upload_file(self, localpath: str, remotepath: str = ""):
        """上传文件到FTP

        - localpath:
        - remotepath: ftp上传路径，不传时默认上传到根目录
        - return:
        """
        try:
            bufsize = 1024
            if remotepath:
                if os.path.isdir(remotepath):
                    remotepath = os.path.join(remotepath, os.path.basename(localpath))
            else:
                remotepath = os.path.basename(localpath)
            fp = open(localpath, "rb")
            self._ftp.storbinary("STOR " + remotepath, fp, bufsize)
            self._ftp.set_debuglevel(0)
            fp.close()
            log.info(remotepath, "文件上传成功！")
        except Exception as e:
            raise RuntimeError(f"上传文件失败! {e}")

    @keyword
    def upload_content_to_file(self, content: str, remote_path: str = "tmp.txt"):
        """上传字符串到FTP文件中

        - content:
        - remote_path: ftp上传路径，不传时默认上传到根目录
        """
        try:
            bufsize = 1024
            remote_dir = os.path.dirname(remote_path)
            try:
                self._ftp.cwd(remote_dir)
            except ftplib.error_perm:
                # 如果目录不存在 创建目录
                self._ftp.mkd(remote_dir)
            fp = BytesIO(content.encode("utf-8"))
            self._ftp.storbinary("STOR " + remote_path, fp, bufsize)
            self._ftp.set_debuglevel(0)
            fp.close()
            log.info(remote_path, "文件上传成功！")
        except Exception as e:
            raise RuntimeError(f"上传文件失败! {e}")
