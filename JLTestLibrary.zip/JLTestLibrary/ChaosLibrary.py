import json
import time
import traceback

from robot.api.deco import keyword

from . import UtilsLibrary, UtilsMsg, log
from .SSHLibrary import SSHLibrary


class ChaosLibrary:
    """目前基本没用到，要用的话可以重构优化下"""

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.chaos_ssh_connect = SSHLibrary()

    @keyword
    def ssh_init(self, hostname="172.20.20.30", port=22, username="root", password="testk8s"):
        self.chaos_ssh_connect.login_ssh(hostname, int(port), username, password)

    @keyword
    def chaosblade_query_network(self, metadata):
        """查询当前混沌工程测试状态

        - param metadata: metadata = {"name":"ext-qrcode-api-pod-network"}
        - return:{"ret_code": "01","status":""}  --00:成功；01初始化中；02；文件执行ERROR
        """

        try:
            metadata_name = metadata["name"]
            cmd = "kubectl get blade " + metadata_name + " -o json"
            msg_result = self.chaos_ssh_connect.ssh_command(cmd)

            ret_msg = {"ret_code": "01", "phase": "", "remark": ""}
            phase = json.loads(msg_result)["status"]["phase"]

            if phase == "Running":
                ret_msg["ret_code"] = "00"
            elif phase == "Initialized":
                ret_msg["ret_code"] = "01"
            elif phase == "Error":
                ret_msg["ret_code"] = "02"
            else:
                ret_msg["ret_code"] = "03"
            ret_msg["phase"] = phase

            print(UtilsLibrary.time_strft(), "chaosblade_query响应消息体:", ret_msg)
            return ret_msg

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"混沌测试，查询节点状态失败!: {str(e)}")

    @keyword
    def chaosblade_create_network(self, metadata, experiments, matchers):
        """
        - metadata:
        - experiments: 基本参数
        - matchers: 扩展参数
        - return: {"ret_code":"00","metadata_name":"","pod_file_name":"file1.yaml"} --00:成功;01:失败
        """
        # 生成混沌测试操作文件
        # 获取到pod延迟队列脚本；只用一次，后期直接那该脚本进行数据处理
        # msg = UtilsMsg.os_path_output_yaml("chaosblade_network_pod_delay.yaml")
        # print (json.dumps(msg))
        ####默认值######
        chaosblade_delay = {
            "apiVersion": "chaosblade.io/v1alpha1",
            "kind": "ChaosBlade",
            "metadata": {"name": "delay-pod-network-by-names"},
            "spec": {
                "experiments": [
                    {
                        "scope": "pod default",
                        "target": "network default",
                        "action": "delay default",
                        "desc": "delay pod network by names default",
                        "matchers": []
                        # "matchers": [{"name": "names", "value": ["pod name"]},
                        #              {"name": "namespace", "value": ["default"]},
                        #              {"name": "interface", "value": ["eth0"]},
                        #              {"name": "time", "value": ["1000"]},
                        #              {"name": "offset", "value": ["0"]}]
                    }
                ]
            },
        }
        # 预设响应消息体
        ret_msg = {"ret_code": "01", "metadata_name": "", "remote_path": "", "remark": ""}

        # print ("metadata",type(metadata),metadata)
        # print ("experiments",type(experiments),experiments)
        # print ("matchers",type(matchers),matchers)

        try:
            chaosblade_delay["metadata"]["name"] = metadata["name"]
            # print ("chaosblade_delay metadata:",chaosblade_delay)

            # 对当前传入参数进行替换操作；如果传入key不存在，则进行增加操作
            cb_experiments = chaosblade_delay["spec"]["experiments"][0]
            cb_experiments = UtilsMsg.para_replace_add_key(cb_experiments, experiments)
            print("chaosblade_delay experiments:", cb_experiments)

            # 如果对pod有延迟；则需要知道当前处理那些pod节点信息；node不用考虑
            if cb_experiments["scope"] == "pod":
                # 获取该命令空间，对应的pod信息(还未考虑多个节点)
                pod_list = self.chaos_ssh_connect.query_namespace_pod(matchers["namespace"], matchers["names"])
                matchers["names"] = pod_list

            # cb_matchers = cb_experiments["matchers"]
            cb_experiments["matchers"] = UtilsMsg.para_replace_list_add_key(matchers)
            print(cb_experiments["matchers"])

            # 生成最终需要执行的文件,生成文件名
            chaosblade_name = chaosblade_delay["metadata"]["name"] + "_" + UtilsLibrary.trans_time_not_space() + ".yaml"
            chaosblade_local_path = UtilsMsg.os_path_input_yaml(chaosblade_name, chaosblade_delay)

            # 上传文件至执行目标地
            remote_path = "/data/chaosblade-0.0.3/autotest/" + chaosblade_name
            self.chaos_ssh_connect.sftp_connect(
                self.chaos_hostname, self.chaos_port, self.chaos_username, self.chaos_password
            )
            self.chaos_ssh_connect.sftp_file_upload(chaosblade_local_path, remote_path)
            # 删除本地生成文件信息
            self.chaos_ssh_connect.localpath_removefile(chaosblade_local_path)

            # 执行命令，并生效该策略
            str = "kubectl apply -f " + remote_path
            result = self.chaos_ssh_connect.ssh_command(str)
            # 先暂停15s,执行create命令后，状态还未生效，等待10s生效后，再发起查询
            time.sleep(15)

            # 查询，确认是否生效；返回状态为00，认为成功；
            # 返回状态为Initialized状态，则等待30秒，重新发起查询
            query_metadata = self.chaosblade_query_network(metadata)
            query_result, query_phase = query_metadata["ret_code"], query_metadata["phase"]
            if query_phase == "Initialized":
                time.sleep(15)
                print(UtilsLibrary.time_strft(), "暂停15s后，重新发起查询状态....")
                query_result = self.chaosblade_query_network(metadata)["ret_code"]

            # 执行命令不一定成功，以查询返回状态为准！
            # created：初始创建，unchanged：有变更且生效；configured：存在创建且配置生效中
            if (
                result.split(" ")[-1] == "created"
                or result.split(" ")[-1] == "unchanged"
                or result.split(" ")[-1] == "configured"
            ) and query_result == "00":
                ret_msg["ret_code"] = "00"
                ret_msg["metadata_name"] = metadata["name"]
                ret_msg["remote_path"] = remote_path
                ret_msg["remark"] = result
                # ret_msg["pod_file_name"] = pod_list
                # ret_msg["namespace"] = matchers["namespace"]

            print(UtilsLibrary.time_strft(), "chaosblade_create响应消息体:", ret_msg)

            return ret_msg

        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"生成混沌工程文件失败!: {str(e)}")

    @keyword
    def chaosblade_delete_network(self, remote_path):
        """
        - return: {"ret_code":"00"} --00:成功;01:失败
        """
        # 执行命令，并生效该策略
        # 预设响应消息体
        # sl = SSHLibrary()
        # sl.login_ssh(self.chaos_hostname,self.chaos_port,self.chaos_username,self.chaos_password)
        ret_msg = {"ret_code": "01"}
        str = "kubectl delete -f " + remote_path
        result = self.chaos_ssh_connect.ssh_command(str)
        if result.split(" ")[-1] == "deleted":
            ret_msg["ret_code"] = "00"
        print(UtilsLibrary.time_strft(), "Chaosblade_delete响应消息体:", ret_msg)
        return ret_msg
