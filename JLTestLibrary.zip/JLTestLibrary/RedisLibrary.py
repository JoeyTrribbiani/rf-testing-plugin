import json
from json import JSONDecodeError
from typing import Union

import redis
from redis import Sentinel
from redis.cluster import ClusterNode, RedisCluster
from robot.api.deco import keyword

from . import log
from .UtilsLibrary import UtilsLibrary


class RedisLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    @keyword
    def connect_redis_sentinels(
        self,
        sentinels: str,
        service_name: str,
        encoding: str = "utf-8",
        encoding_errors: str = "ignore",
        decode_responses: bool = True,
    ):
        """redis哨兵模式连接

        - sentinels: 例如 172.20.6.54:26379,172.20.6.55:26379,172.20.6.56:26379
        - service_name: 例如 shard1
        - encoding: _description_, defaults to "utf-8"
        - encoding_errors: _description_, defaults to "ignore"
        - decode_responses: _description_, defaults to True
        """
        addrs = sentinels.split(",")
        sentinels_nodes = [(addr.split(":")[0], int(addr.split(":")[1])) for addr in addrs]
        log.info("哨兵模式连接地址", sentinels_nodes)
        sentinel = Sentinel(
            sentinels_nodes,
            socket_timeout=0.1,
            encoding=encoding,
            encoding_errors=encoding_errors,
            decode_responses=decode_responses,
        )
        self.redis_client = master = sentinel.master_for(service_name, socket_timeout=0.1)

    @keyword
    def connect_redis_server(
        self,
        serverip: str,
        port: int = 6379,
        db: int = 0,
        password: str = "",
        encoding: str = "utf-8",
        encoding_errors: str = "ignore",
    ):
        """redis单机模式连接

        - serverip: _description_
        - port: _description_, defaults to 6379
        - db: _description_, defaults to 0
        - password: _description_, defaults to None
        - socket_timeout: _description_, defaults to 0.1
        - encoding: _description_, defaults to "utf-8"
        - encoding_errors: _description_, defaults to "ignore"
        - decode_responses: _description_, defaults to False
        """
        self.redis_client = redis.Redis(
            host=serverip,
            port=port,
            db=db,
            password=password,
            socket_timeout=0.1,
            encoding=encoding,
            encoding_errors=encoding_errors,
        )

    @keyword
    def connect_redis_server_Cluster(self, startup_node: str):
        """redis集群模式连接

        - startup_node: 例如 172.20.20.37:6379,172.20.20.38:6379,172.20.20.39:6379,172.20.20.37:6380,172.20.20.38:6380,172.20.20.39:6380
        """
        addrs = startup_node.split(",")

        startup_nodes = [ClusterNode(addr.split(":")[0], int(addr.split(":")[1])) for addr in addrs]
        log.info("redis集群模式连接地址:", startup_nodes)
        self.redis_client = RedisCluster(
            startup_nodes=startup_nodes, decode_responses=True, encoding="utf-8", encoding_errors="ignore"
        )

    @keyword
    def redis_get(self, key):
        value = self.redis_client.get(key)
        log.info(key, value)
        return value

    @keyword
    def redis_keys(self, pattern="*"):
        value = self.redis_client.keys(pattern)
        log.info(pattern, value)
        return value

    @keyword
    def redis_mget(self, keys, *args):
        return self.redis_client.mget(keys, *args)

    @keyword
    def redis_mset(self, *args, **kwargs):
        return self.redis_client.mset(*args, **kwargs)

    @keyword
    def redis_set(self, key, value, ex=None, px=None, nx=False, xx=False):
        return self.redis_client.set(key, value, ex, px, nx, xx)

    @keyword
    def redis_setex(self, key, time, value):
        return self.redis_client.setex(key, time, value)

    @keyword
    def redis_setnx(self, key, value):
        return self.redis_client.setnx(key, value)

    @keyword
    def redis_flushdb(self):
        return self.redis_client.flushdb()

    @keyword
    def redis_bgsave(self):
        return self.redis_client.bgsave()

    @keyword
    def redis_save(self):
        return self.redis_client.save()

    @keyword
    def redis_ping(self):
        return self.redis_client.ping()

    @keyword
    def redis_delete(self, key):
        print("redis_delete:", key)
        return self.redis_client.delete(key)

    @keyword
    def redis_hset(self, key, dictkey, dictvalue):
        return self.redis_client.hset(key, dictkey, dictvalue)

    @keyword
    def redis_hget(self, key, dictkey):
        return self.redis_client.hget(key, dictkey)

    @keyword
    def redis_hgetall(self, key):
        return self.redis_client.hgetall(key)

    @keyword
    def redis_hdel(self, key, *dictkeys):
        return self.redis_client.hdel(key, *dictkeys)

    @keyword
    def redis_lset(self, key, index, value):
        return self.redis_client.lset(key, index, value)

    @keyword
    def redis_lrange(self, key, start, end):
        return self.redis_client.lrange(key, start, end)

    @keyword
    def redis_expire(self, key, time):
        return self.redis_client.expire(key, time)

    @keyword
    def redis_ttl(self, key):
        return self.redis_client.ttl(key)

    @keyword
    def redis_scan(self, match):
        return [key for key in self.redis_client.scan_iter(match, count=1000)]

    @keyword
    def redis_judge_time_and_hget(self, key, field, ok, fail, start, end, time_format="%Y%m%d%H%M%S"):
        """判断是否在时间范围内，是的话返回json中某个的值，否则返回另一个值

        - key: redis key
        - field: redis field，值为json字符串格式
        - ok: 在时间范围内，json中要取值的key
        - fail: 不存在时间范围或不在时间范围内，json中要取值的key
        - start: json中开始时间的field
        - end: json中结束时间的field
        - time_format: 时间格式, defaults to "%Y%m%d%H%M%S"
        - return: json中要取值的值
        """
        value_string = self.redis_hget(key, field)
        log.info(value_string)
        try:
            values = json.loads(value_string)
        except JSONDecodeError:
            log.warn('json字符串解析异常')
            values = {}
        start_time = values.get(start, "")
        end_time = values.get(end, "")
        if UtilsLibrary.is_during(start_time, end_time, time_format):
            value = values.get(ok)
            log.info(f"在时间范围内,返回 {ok} 的值 {value}")
            return value
        value = values.get(fail)
        log.info(f"不存在时间范围或不在时间范围内,返回 {fail} 的值 {value}")
        return value

    @keyword
    def redis_sadd(self, key, value):
        """向集合添加一个或多个成员

        - key: _description_
        - value: _description_
        - return: _description_
        """
        return self.redis_client.sadd(key, value)

    @keyword
    def redis_smembers(self, key):
        """返回集合中的所有成员

        - key: _description_
        - return: _description_
        """
        return self.redis_client.smembers(key)

    @keyword
    def redis_scard(self, key):
        """获取集合的成员数

        - key: _description_
        - return: _description_
        """
        return self.redis_client.scard(key)

    @keyword
    def redis_spop(self, key):
        """移除并返回集合中的一个随机元素

        - key: _description_
        - return: _description_
        """
        return self.redis_client.spop(key)
