import datetime
from typing import Union
from uuid import uuid4

from robot.api.deco import keyword

from JLTestLibrary.FakeLibrary import FakeLibrary

from . import log
from .FtpLibrary import FtpLibrary
from .profit import agent_profit_cfg
from .UtilsMsg import UtilsMsg


class ProfitLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.pf_mpos_4_content = ""
        self.pf_mpos_deposit_content = ""
        self.pf_mpos_member_content = ""
        self.pf_posp_1_content = ""
        self.pf_posp_3_content = ""
        self.pf_posp_server_content = ""
        self.pf_mpos_4_path = "/accountfile/java/jlpay/{0}/00000000_{1}_4.txt"
        self.pf_mpos_deposit_path = "/accountfile/java/jlpay/{0}/00000000_{1}_deposit.txt"
        self.pf_mpos_member_path = "/accountfile/java/jlpay/{0}/00000000_{1}_member.txt"
        self.pf_posp_1_path = "/accountfile/java/jlpay/{0}/00000000_{1}_1.txt"
        self.pf_posp_3_path = "/accountfile/java/jlpay/{0}/00000000_{1}_3.txt"
        self.pf_posp_server_path = "/accountfile/java/jlpay/{0}/00000000_{1}_server.txt"
        self.pf_faker = FakeLibrary()

    def _format_line(self, line: str, separator: str, cfg_type: str) -> dict:
        """
        根据数据格式，校验格式是否正确，返回字典对象
        """
        fields = line.split(separator)
        length = len(fields)
        cfg = agent_profit_cfg.ProfitCfg[cfg_type]
        position = 0
        data_dict = {}
        for key in cfg.keys():
            if position + 1 <= length:
                data_dict[key] = fields[position]
            position += 1
        log.info(f"模板：{data_dict}")
        return data_dict

    def _build_line(self, data_dict: dict, separator: str, bill_type: str) -> str:
        cfg = agent_profit_cfg.ProfitCfg[bill_type]
        data_list = []
        for key in cfg:
            if key in data_dict:
                data_list.append(data_dict[key])
        line = separator.join(data_list)
        log.info(f"流水记录：{line}")
        self._cache_content(line, bill_type)
        return line

    def _cache_content(self, line: str, bill_type: str) -> None:
        name = f"pf_{bill_type}_content"
        content = getattr(self, name)
        if not content:
            setattr(self, name, line)
        else:
            content += "\r\n" + line
            setattr(self, name, content)

    def _update_dict(self, ori_dict: dict, replace_dict: dict):
        for replace, replace_value in replace_dict.items():
            replace_upper = replace.upper()
            if replace_upper in ori_dict:
                ori_dict[replace_upper] = replace_value

    def _replace_default_value(self, ori_dict: dict, date: str):
        """根据已提供的数据，计算和补充一些默认数据，简化用例内容"""
        log.info('默认参数替换.')
        ori_dict["LIST_ID"] = str(uuid4())
        ori_dict["CARD_NO"] = self.pf_faker.bankcard.credit_card_number("ccb")
        cur_date = datetime.datetime.strptime(date, "%Y%m%d")
        ori_dict["TRADE_TIME"] = str(cur_date)
        ori_dict["START_DATE"] = str(cur_date)
        ori_dict["WITHDRAW_TIME"] = str(cur_date)
        if "MONTHS" in ori_dict:
            months = ori_dict["MONTHS"]
            if not months.isdigit():
                raise ValueError(f"MONTHS应该为数字")
            end_date = cur_date + datetime.timedelta(days=int(months) * 31)
            ori_dict["END_DATE"] = str(end_date)

    @keyword
    def profit_ftp_init(
        self, ftp_host: str = "172.20.20.114", ftp_port: int = 21, username: str = "ftp_admin", password: str = "111111"
    ):
        self.pf_ftp = FtpLibrary()
        self.pf_ftp.connect_to_ftp(ftp_host, ftp_port, username, password)

    @keyword
    def profit_file(self, bill_type: str, date_time: str, template: str, param_replace: Union[str, dict] = {}) -> str:
        """
        - bill_type: 流水文件类型：
        | mpos_4 | mpos 交易/提现流水 |
        | mpos_deposit | mpos 押金流水 |
        | mpos_member | mpos 会员费流水 |
        | posp_1 | posp 交易流水 |
        | posp_3 | posp 提现流水 |
        | posp_server | posp 服务费流水 |
        - date_time: 流水文件日期,YYYYMMDD
        """
        bill_type = bill_type.lower()
        if bill_type == "mpos_4":
            separator = ","
            tmp_dict = self._format_line(template, separator, bill_type)
        elif bill_type in ["mpos_deposit", "mpos_member", "posp_1", "posp_3", "posp_server"]:
            separator = "|"
            tmp_dict = self._format_line(template, separator, bill_type)
        else:
            raise ValueError(f"bill_type: {bill_type} 类型错误")
        self._replace_default_value(tmp_dict, date_time)
        if param_replace:
            log.info(f"用户参数替换：{param_replace}")
            replace_dict = UtilsMsg.str_to_dict(param_replace)
            self._update_dict(tmp_dict, replace_dict)
        return self._build_line(tmp_dict, separator, bill_type)

    @keyword
    def upload_profit_file(self, bill_type: str, date: str):
        """
        根据生成的流水文件内容，开始上传对应类型的流水文件
        - bill_type:
        - date: ftp流水文件日期，YYYYMMDD
        """
        content_name = f"pf_{bill_type}_content"
        content = getattr(self, content_name)
        upload_path = getattr(self, f"pf_{bill_type}_path")
        upload_path = upload_path.format(date, date)
        log.info(f"开始上传 {bill_type} 类型流水文件到目录 {upload_path}")
        log.info(f"{bill_type} 类型流水文件内容:\n{content}")
        try:
            self.pf_ftp.upload_content_to_file(content, upload_path)
        except Exception as e:
            raise RuntimeError(e, f"上传 {bill_type} 类型流水文件到目录 {upload_path}异常")
        finally:
            # 上传文件后，清除该类型的流水内容缓存
            setattr(self, content_name, None)
