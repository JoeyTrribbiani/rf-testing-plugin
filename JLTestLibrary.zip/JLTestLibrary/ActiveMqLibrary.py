import json
import traceback
from typing import Union

import stomp,time
from robot.api.deco import keyword

from . import log
from .UtilsMsg import UtilsMsg


class ActiveMqLibrary:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self):
        self.amq_host: str = ""
        self.amq_port: str = ""
        self.amq_conn = None

    @keyword
    def activemq_init_host(self, mq_address: str) -> None:
        """配置activemq连接地址

        - mq_address: 例如172.20.20.37:61613
        """
        try:
            self.amq_host, self.amq_port = mq_address.split(":")
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"配置activemq连接地址失败: {str(e)}")

    @keyword
    def activemq_send_message(
        self, destination: str, msg: Union[str, dict], para_replace: Union[str, dict] = {}
    ) -> str:
        """发送activemq消息

        - destination: 例如 /queue/accp_record.posp
        - msg: 例如{"key":"value"}
        - para_replace: 对msg中某些键值对进行替换
        """
        try:
            # 判断para_replace参数,对传入参数进行替换操作
            if para_replace:
                msg = UtilsMsg.str_to_dict(msg)
                para_replace = UtilsMsg.str_to_dict(para_replace)
                msg = UtilsMsg.para_replace(msg, para_replace)

            if isinstance(msg, dict):
                # 对默认值进行替换操作
                msg = UtilsMsg.msg_default_para_replace(msg)
                msg = json.dumps(msg, ensure_ascii=False)
            log.info("发送消息体：", msg)

            self.amq_conn = stomp.Connection10([(self.amq_host, int(self.amq_port))], auto_content_length=False)
            self.amq_conn.connect()
            self.amq_conn.send(destination, msg)
            return msg
        except Exception as e:
            log.warn(traceback.format_exc())
            raise RuntimeError(f"发送activemq消息失败: {str(e)}")
        finally:
            if self.amq_conn:
                self.amq_conn.disconnect()

    def  activemq_consumer_message(self,queue_name):
        try:
            myliblistener  = ActiveMqLibrary()
            conn = stomp.Connection10([('172.20.4.51', 61613)],auto_content_length=False)
            conn.set_listener('ActiveMqLibrary', ActiveMqLibrary())
            conn.start()
            conn.connect(wait=True)
            cs = conn.subscribe(destination=queue_name,id=1)
            # 等待消费后，再关闭链接
            time.sleep(10)  # secs
            conn.disconnect()
            # message = str(self.get_message_redis("mock_active_mq_message_list"))
            # LoggerLibrary.log_INFO_Type(message)
            # return message
        except Exception as e:
            conn.disconnect()
            print(e)